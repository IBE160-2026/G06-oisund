# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: private-d1-remediation.spec.ts >> D1 explicit abandonment checks disappearance and preserves account notices
- Location: .v1followup-tests\private-d1-remediation.spec.ts:73:1

# Error details

```
Error: dialog.accept: Cannot accept dialog which is already handled!
```

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('region', { name: 'Bekreftet plan', exact: true })
Expected: 0
Received: 1

Call log:
  - Expect "toHaveCount" getByRole('region', { name: 'Bekreftet plan', exact: true }) with timeout 5000ms
  - waiting for getByRole('region', { name: 'Bekreftet plan', exact: true })
    5 × locator resolved to 1 element
      - unexpected value "1"
  - Test ended.

```

# Test source

```ts
  5   | for (const resource of ['selection', 'start']) test(`D1 canonical ${resource} rejection settles despite unavailable current read`, async ({ page, context }) => {
  6   |   const { plan } = await openedPlan(page, context);
  7   |   const path = '/workdays/' + plan.id + '/' + resource;
  8   |   const read = '/workdays/' + plan.id + '/' + (resource === 'start' ? 'lifecycle' : resource);
  9   |   let writes = 0;
  10  |   await page.route('**:18330' + path, route => {
  11  |     if (route.request().method() !== 'POST') return route.fulfill({ status: 503, json: { detail: 'Tjenesten er utilgjengelig.' } });
  12  |     writes++; return route.fulfill({ status: 429, json: { detail: { code: resource + '_receipt_capacity', message: 'For mange lagringsforsøk. Vent til tidligere planer utløper.' } } });
  13  |   });
  14  |   if (resource === 'start') await page.route('**:18330' + read, route => route.fulfill({ status: 503, json: { detail: 'Tjenesten er utilgjengelig.' } }));
  15  |   await page.getByRole('button', { name: resource === 'selection' ? 'Velg aktivitet 1' : 'Start skift', exact: true }).click();
  16  |   if (resource === 'start') await page.getByRole('button', { name: 'Bekreft skiftstart', exact: true }).click();
  17  |   const status = resource === 'selection' ? activityStatus(page) : shiftStatus(page);
  18  |   await expect(status).toContainText('avvist');
  19  |   await expect(page.getByRole('button', { name: resource === 'selection' ? 'Kontroller aktivitetsvalget' : 'Kontroller skiftstarten', exact: true })).toHaveCount(0);
  20  |   await expect(page.getByText(resource === 'selection' ? 'Lagret aktivitetsvalg kan ikke bekreftes.' : 'Skiftstatus er ukjent / utilgjengelig', { exact: true })).toBeVisible();
  21  |   await page.getByRole('button', { name: resource === 'selection' ? 'Avbryt avvist aktivitetsvalg' : 'Avbryt avvist skiftstart', exact: true }).click();
  22  |   await expect.poll(() => beforeUnload(page)).toBe(false); expect(writes).toBe(1);
  23  | });
  24  | 
  25  | test('D1 wrong identity conflict comparison preserves local proposal without B facts', async ({ page, context }) => {
  26  |   const { draft } = await openedPlan(page, context);
  27  |   await page.getByRole('button', { name: 'Lukk planen', exact: true }).click();
  28  |   await page.getByRole('button', { name: 'Oppdater listen', exact: true }).click();
  29  |   await page.getByRole('button', { name: 'Åpne 2031-01-02 · versjon 1', exact: true }).click(); await editor(page);
  30  |   await page.getByLabel('Vognløp', { exact: true }).fill('local-proposal-A');
  31  |   const path = '/drafts/' + draft.id;
  32  |   await page.route('**:18330' + path, route => route.request().method() === 'POST'
  33  |     ? route.fulfill({ status: 409, json: { detail: 'Utkastet er endret. Sammenlign med lagret versjon før du fortsetter.' } })
  34  |     : route.fulfill({ status: 200, json: { ...draft, id: randomUUID(), revision: 2, draft: { ...draft.draft, vehicle_duty: 'PRIVATE-B-FACT' } } }));
  35  |   await page.getByRole('button', { name: 'Lagre utkast', exact: true }).click();
  36  |   await expect(page.getByRole('status', { name: 'Lagringsstatus', exact: true })).toContainText('Konflikt');
  37  |   await expect(page.getByText('PRIVATE-B-FACT', { exact: true })).toHaveCount(0);
  38  |   await expect(page.getByRole('region', { name: 'Sammenlign versjoner' })).toHaveCount(0);
  39  |   await expect(page.getByLabel('Vognløp', { exact: true })).toHaveValue('local-proposal-A');
  40  | });
  41  | 
  42  | test('D1 source folds display authoritative supplied offsets', async ({ page, context }) => {
  43  |   await openedPlan(page, context, false, undefined, undefined, false, content => {
  44  |     content.service_date = '2030-10-27';
  45  |     for (const activity of content.activities) for (const field of ['start', 'end'] as const)
  46  |       activity[field] = activity[field]?.replace('2031-01-02', '2030-10-27').replace('2031-01-03', '2030-10-28') ?? null;
  47  |   });
  48  |   const originals: any[] = [];
  49  |   for (const [offset, title] of [['+02:00', 'First fold'], ['+01:00', 'Second fold']]) {
  50  |     const operation = (await post(context, '/notice-operations', {})).operation_id;
  51  |     const receipt = await post(context, '/notices', { operation_id: operation, expected_revision: 0,
  52  |       content: { title, line_scope: 'all', line_tags: [], source_updated_at: '2030-10-27T02:30:00' + offset, valid_from: '2030-10-27T02:30:00+02:00', valid_until: '2030-10-27T02:30:00+01:00', source_url: null } });
  53  |     originals.push({ operation, receipt });
  54  |   }
  55  |   await page.getByRole('button', { name: 'Manuelt vedlikeholdte avvik', exact: true }).click();
  56  |   for (const view of ['maintenance', 'reader']) {
  57  |     if (view === 'reader') {
  58  |       await page.getByRole('button', { name: 'Tilbake til dagen', exact: true }).click();
  59  |       await page.getByRole('button', { name: 'Les avvik for linjer og datoer', exact: true }).click();
  60  |     }
  61  |     for (const [offset, title] of [['+02:00', 'First fold'], ['+01:00', 'Second fold']]) {
  62  |       const item = page.locator('.notice-list li:visible').filter({ hasText: title }); await item.locator('summary').click();
  63  |       await expect(item).toContainText('Kilden oppdatert: 27.10.2030, 02:30:00 (UTC' + offset + ')');
  64  |       await expect(item).toContainText('Gyldighet: fra 27.10.2030, 02:30:00 (UTC+02:00) til 27.10.2030, 02:30:00 (UTC+01:00)');
  65  |     }
  66  |   }
  67  |   for (const { operation, receipt } of originals) {
  68  |     expect(await (await context.request.get(API + '/notices/' + receipt.result.id)).json()).toEqual(receipt.result);
  69  |     expect(await (await context.request.get(API + '/workday-notice-operations/' + operation)).json()).toEqual(receipt);
  70  |   }
  71  | });
  72  | 
  73  | test('D1 explicit abandonment checks disappearance and preserves account notices', async ({ page, context }) => {
  74  |   const { plan } = await openedPlan(page, context); const path = '/workdays/' + plan.id + '/selection'; let writes = 0, original: any;
  75  |   await post(context, '/notices', { operation_id: (await post(context, '/notice-operations', {})).operation_id, expected_revision: 0,
  76  |     content: { title: 'Independent retained notice', line_scope: 'all', line_tags: [], source_updated_at: null, valid_from: null, valid_until: '2031-01-04T23:59:59+01:00', source_url: null } });
  77  |   await page.route('**:18330' + path, async route => { if (route.request().method() !== 'POST') return route.continue(); writes++; original = route.request().postDataJSON(); await route.fetch(); await route.abort(); });
  78  |   await page.getByRole('button', { name: 'Velg aktivitet 1', exact: true }).click();
  79  |   await expect(page.getByRole('button', { name: 'Kontroller aktivitetsvalget', exact: true })).toBeEnabled();
  80  |   const abandon = page.getByRole('button', { name: 'Oppgi uavklart forsøk og lukk planen', exact: true });
  81  |   let prematureDialogs = 0;
  82  |   const denyDialog = async (dialog: any) => { prematureDialogs++; await dialog.dismiss(); };
  83  |   page.on('dialog', denyDialog);
  84  |   // A transient current read must retain the uncertain operation and locks.
  85  |   for (const response of [
  86  |     { status: 503, json: { detail: 'Tjenesten er utilgjengelig.' } },
  87  |     { status: 200, contentType: 'text/html', body: '<html>unavailable</html>' },
  88  |     { status: 404, contentType: 'text/html', body: '<html>unavailable</html>' },
  89  |     { status: 404, json: { detail: 'wrong detail' } },
  90  |   ]) {
  91  |     await page.route('**:18330/workdays/' + plan.id, route => route.fulfill(response));
  92  |     await abandon.click(); await expect.poll(() => beforeUnload(page)).toBe(true);
  93  |     await expect(page.getByRole('button', { name: 'Kontroller aktivitetsvalget', exact: true })).toBeEnabled();
  94  |     await page.unroute('**:18330/workdays/' + plan.id);
  95  |     expect(prematureDialogs).toBe(0);
  96  |   }
  97  |   page.off('dialog', denyDialog);
  98  |   await post(context, '/workdays/' + plan.id + '/delete', { operation_id: randomUUID(), source_revision: 1 });
  99  |   page.once('dialog', dialog => dialog.dismiss()); await abandon.click();
  100 |   await expect.poll(() => beforeUnload(page)).toBe(true);
  101 |   const lookup = page.waitForRequest(request => request.url().endsWith('/workday-selection-operations/' + original.operation_id));
  102 |   await page.getByRole('button', { name: 'Kontroller aktivitetsvalget', exact: true }).click(); await lookup;
  103 |   await expect(page.getByRole('button', { name: 'Kontroller aktivitetsvalget', exact: true })).toBeEnabled();
  104 |   page.once('dialog', dialog => dialog.accept()); await abandon.click();
> 105 |   await expect(page.getByRole('region', { name: 'Bekreftet plan', exact: true })).toHaveCount(0);
      |                                                                                   ^ Error: expect(locator).toHaveCount(expected) failed
  106 |   await expect.poll(() => beforeUnload(page)).toBe(false); expect(writes).toBe(1);
  107 |   expect((await (await context.request.get(API + '/notices')).json()).notices.map((n: any) => n.title)).toContain('Independent retained notice');
  108 | });
  109 | 
```