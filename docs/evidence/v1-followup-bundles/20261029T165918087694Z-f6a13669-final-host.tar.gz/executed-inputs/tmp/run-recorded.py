import importlib.util
import os
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('followup', root/'scripts/verify-v1followup.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
runner = module.load_runner()
inputs = [root/'scripts/verify-v1followup.py', Path(__file__)]
for argument in sys.argv[2:]:
    path = root/argument
    if path.is_file() and (path.suffix in ('.py', '.ps1', '.mjs', '.ts', '.yaml', '.json') or path.name.startswith('Dockerfile')):
        inputs.append(path)
runner['execute'](sys.argv[2:], env=os.environ.copy(), inputs=inputs)
