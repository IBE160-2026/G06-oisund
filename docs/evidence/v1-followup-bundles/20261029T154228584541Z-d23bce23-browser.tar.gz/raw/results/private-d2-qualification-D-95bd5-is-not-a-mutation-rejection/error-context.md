# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: private-d2-qualification.spec.ts >> D2 A8 accepted draft deletion lookup 410 is not a mutation rejection
- Location: .v1followup-tests\private-d2-qualification.spec.ts:86:127

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('status', { name: 'Lagringsstatus', exact: true })
Expected substring: "Sletting er ikke bekreftet."
Received string:    "Sletting kunne ikke bekreftes fordi utkastet eller slettingsforsøket er utløpt. Du kan opprette et nytt utkast."
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByRole('status', { name: 'Lagringsstatus', exact: true }) with timeout 5000ms
  - waiting for getByRole('status', { name: 'Lagringsstatus', exact: true })
    - locator resolved to <p role="status" aria-label="Lagringsstatus">Kontrollerer sletting …</p>
    - unexpected value "Kontrollerer sletting …"
    13 × locator resolved to <p role="status" aria-label="Lagringsstatus">Sletting kunne ikke bekreftes fordi utkastet elle…</p>
       - unexpected value "Sletting kunne ikke bekreftes fordi utkastet eller slettingsforsøket er utløpt. Du kan opprette et nytt utkast."

```

```yaml
- status "Lagringsstatus": Sletting kunne ikke bekreftes fordi utkastet eller slettingsforsøket er utløpt. Du kan opprette et nytt utkast.
```

# Test source

```ts
  1   | import { test, expect, openedPlan, post, API, setup, python, randomUUID, beforeUnload } from './private-activity-helpers';
  2   | import { editor } from './private-screen-helpers';
  3   | import { writeFileSync } from 'node:fs';
  4   | setup();
  5   | test.use({ actionTimeout: 15000 });
  6   | const feedback = (page: any) => page.getByRole('status', { name: 'Avviksstatus', exact: true });
  7   | const examples = [
  8   |   { title: 'Syntetisk SMS om midlertidig holdeplass', summary: 'Bruk midlertidig holdeplass ved kaia.', description: 'Mandag: Linje 20 mot nord bruker kaia.\nTirsdag: Linje 24 mot sør bruker biblioteket.\nDette er et uavhengig syntetisk aksepteksempel.', source_note: 'Syntetisk SMS fra trafikkleder; ingen nettadresse.', source_url: null, line_scope: 'selected', line_tags: ['20', '24'] },
  9   |   { title: 'Syntetisk delt lenke med lang instruksjon', summary: 'Felles melding for alle linjer.', description: 'Uavhengig skrevet norsk instruksjon: gå gjennom skilting mens bussen står stille.\n'.repeat(24), source_note: 'Syntetisk eksempel med delt lenke.', source_url: 'https://example.invalid/delt-melding', line_scope: 'all', line_tags: [] },
  10  | ];
  11  | async function open(page: any) {
  12  |   await page.getByRole('button', { name: 'Manuelt vedlikeholdte avvik', exact: true }).click();
  13  |   await expect(page.getByRole('button', { name: 'Hent lagrede avvik', exact: true })).toBeEnabled();
  14  | }
  15  | async function fill(page: any, item: typeof examples[number]) {
  16  |   await page.getByRole('button', { name: 'Registrer avvik', exact: true }).click();
  17  |   await page.getByLabel('Gyldig tildato', { exact: true }).fill('2031-01-04');
  18  |   await page.getByLabel('Tittel', { exact: true }).fill(item.title);
  19  |   await page.getByLabel('Kort forklaring', { exact: true }).fill(item.summary);
  20  |   await page.getByLabel('Detaljert forklaring', { exact: true }).fill(item.description);
  21  |   await page.getByLabel('Kildebeskrivelse', { exact: true }).fill(item.source_note);
  22  |   await page.getByLabel('Originalkilde (HTTP eller HTTPS)', { exact: true }).fill(item.source_url ?? '');
  23  |   await page.getByLabel('Linjeomfang', { exact: true }).selectOption(item.line_scope);
  24  |   if (item.line_scope === 'selected') await page.getByLabel('Linjer fra kilden (kommaseparert)', { exact: true }).fill(item.line_tags.join(', '));
  25  | }
  26  | 
  27  | test('D2 A7 independent synthetic source shapes survive cross-day reading and parent removal/expiry', async ({ page, context }) => {
  28  |   const { plan: a } = await openedPlan(page, context);
  29  |   const original = await (await context.request.get(API + '/drafts/' + a.source_draft_id)).json();
  30  |   const content = structuredClone(original.draft); content.service_date = '2031-01-03';
  31  |   for (const activity of content.activities) for (const field of ['start', 'end']) activity[field] = activity[field].replace('2031-01-03', '2031-01-04').replace('2031-01-02', '2031-01-03');
  32  |   const draft = await post(context, '/drafts', { operation_id: (await post(context, '/draft-operations', {})).operation_id, expected_revision: 0, draft: content });
  33  |   const review = await post(context, '/workday-reviews', { draft_id: draft.id, expected_revision: 1 });
  34  |   const b = await post(context, '/drafts/' + draft.id + '/confirm', { operation_id: review.operation_id, expected_revision: 1, acknowledgements: review.unknowns.map((u: any) => u.id), classifications: {} });
  35  |   const commands: any[] = [];
  36  |   page.on('request', request => { if (request.method() === 'POST' && new URL(request.url()).pathname === '/notices') commands.push(request.postDataJSON()); });
  37  |   await open(page);
  38  |   for (const item of examples) { await fill(page, item); await page.getByRole('button', { name: 'Lagre avvik', exact: true }).click(); await expect(feedback(page)).toHaveText('Avviket er lagret.'); }
  39  |   const saved = (await (await context.request.get(API + '/notices')).json()).notices;
  40  |   for (const item of examples) {
  41  |     const row = saved.find((n: any) => n.title === item.title);
  42  |     expect(row).toMatchObject({ ...item, valid_from: null, source_updated_at: null, checked_at: null, workday_id: null, revision: 1, valid_until: '2031-01-04T23:59:59+01:00' });
  43  |   }
  44  |   const receipts = await Promise.all(commands.map(async command => (await context.request.get(API + '/workday-notice-operations/' + command.operation_id)).json()));
  45  |   await page.getByRole('button', { name: 'Forberedelse og planlister', exact: true }).click();
  46  |   await page.getByRole('button', { name: 'Oppdater planlisten', exact: true }).click();
  47  |   await page.getByRole('button', { name: 'Åpne plan 2031-01-03 · versjon 1', exact: true }).click();
  48  |   await page.getByRole('button', { name: 'Les avvik for linjer og datoer', exact: true }).click();
  49  |   const reader = page.getByRole('region', { name: 'Avvik for linjer og datoer', exact: true });
  50  |   await expect(reader.locator('summary')).toHaveCount(2);
  51  |   for (const item of examples) await expect(reader).toContainText(item.title);
  52  |   await post(context, '/workdays/' + a.id + '/delete', { operation_id: randomUUID(), source_revision: 1 });
  53  |   expect((await (await context.request.get(API + '/notices')).json()).notices).toEqual(saved);
  54  |   // Controlled expiry changes only this synthetic parent; notices/receipts are independent.
  55  |   python(`with database() as conn:\n conn.execute("UPDATE workdays SET expires_at=clock_timestamp()-interval '1 second' WHERE id=%s", (${JSON.stringify(b.id)},))\n`);
  56  |   expect([404, 410]).toContain((await context.request.get(API + '/workdays/' + b.id)).status());
  57  |   expect((await (await context.request.get(API + '/notices')).json()).notices).toEqual(saved);
  58  |   for (let i = 0; i < commands.length; i++) expect(await (await context.request.get(API + '/workday-notice-operations/' + commands[i].operation_id)).json()).toEqual(receipts[i]);
  59  |   writeFileSync('../tmp/v1followup-a7-result.json', JSON.stringify({ synthetic: true, examples, parentADeleted: a.id, parentBControlledExpiry: b.id, saved, receipts }, null, 2));
  60  | });
  61  | 
  62  | test('D2 A8 accepted notice update retains identity through proxy and failed lookup to one revision', async ({ page, context }) => {
  63  |   await openedPlan(page, context);
  64  |   const item = examples[0];
  65  |   const initial = await post(context, '/notices', { operation_id: (await post(context, '/notice-operations', {})).operation_id, expected_revision: 0, content: { ...item, valid_until: '2031-01-04T23:59:59+01:00', source_updated_at: null, valid_from: null } });
  66  |   await open(page); await page.locator('.notice-list summary').click();
  67  |   await page.getByRole('button', { name: 'Rediger ' + item.title, exact: true }).click();
  68  |   await page.getByLabel('Tittel', { exact: true }).fill('Syntetisk endret etter faktisk lagring');
  69  |   const writes: any[] = [];
  70  |   await page.route('**:18330/notices/' + initial.result.id, async route => { if (route.request().method() !== 'POST') return route.continue(); writes.push(route.request().postDataJSON()); await route.fetch(); await route.fulfill({ status: 502, contentType: 'text/html', body: '<html>synthetic lost accepted update</html>' }); });
  71  |   await page.getByRole('button', { name: 'Lagre avvik', exact: true }).click();
  72  |   await expect(feedback(page)).toContainText('uavklart');
  73  |   await page.route('**:18330/workday-notice-operations/*', route => route.fulfill({ status: 503, json: { detail: 'Synthetic lookup unavailable' } }));
  74  |   await page.getByRole('button', { name: 'Prøv samme avvikslagring igjen', exact: true }).click();
  75  |   await expect(feedback(page)).toContainText('uavklart'); expect(writes).toHaveLength(1);
  76  |   await expect(page.getByLabel('Tittel', { exact: true })).toHaveValue('Syntetisk endret etter faktisk lagring');
  77  |   await page.unroute('**:18330/workday-notice-operations/*');
  78  |   await page.getByRole('button', { name: 'Kontroller avvikslagringen', exact: true }).click();
  79  |   await expect(feedback(page)).toHaveText('Avviket er lagret.'); expect(writes).toHaveLength(1);
  80  |   const current = await (await context.request.get(API + '/notices/' + initial.result.id)).json();
  81  |   expect(current.revision).toBe(2); expect(current.title).toBe('Syntetisk endret etter faktisk lagring');
  82  |   const receipt = await (await context.request.get(API + '/workday-notice-operations/' + writes[0].operation_id)).json();
  83  |   expect(receipt.result).toEqual(current); expect(receipt.operation_id).toBe(writes[0].operation_id);
  84  | });
  85  | 
  86  | for (const [code, detail] of [[409, 'Slettingsforsøket har annet innhold.'], [410, 'Slettingsforsøket er utløpt.']] as const) test(`D2 A8 accepted draft deletion lookup ${code} is not a mutation rejection`, async ({ page, context }) => {
  87  |   const { draft } = await openedPlan(page, context);
  88  |   await page.getByRole('button', { name: 'Lukk planen', exact: true }).click();
  89  |   await page.getByRole('button', { name: 'Oppdater listen', exact: true }).click();
  90  |   await page.getByRole('button', { name: 'Åpne 2031-01-02 · versjon 1', exact: true }).click(); await editor(page);
  91  |   const writes: any[] = [];
  92  |   await page.route('**:18330/drafts/' + draft.id + '/delete', async route => { writes.push(route.request().postDataJSON()); await route.fetch(); await route.abort(); });
  93  |   page.once('dialog', dialog => dialog.accept()); await page.getByRole('button', { name: 'Slett utkast', exact: true }).click();
  94  |   const status = page.getByRole('status', { name: 'Lagringsstatus', exact: true });
  95  |   await expect(status).toContainText('Sletting er ikke bekreftet.');
  96  |   await page.route('**:18330/draft-deletions/*', route => route.fulfill({ status: code, json: { detail } }));
  97  |   await page.getByRole('button', { name: 'Kontroller slettingen', exact: true }).click();
> 98  |   await expect(status).toContainText('Sletting er ikke bekreftet.');
      |                        ^ Error: expect(locator).toContainText(expected) failed
  99  |   await expect(page.getByRole('button', { name: 'Kontroller slettingen', exact: true })).toBeEnabled();
  100 |   await expect.poll(() => beforeUnload(page)).toBe(true); expect(writes).toHaveLength(1);
  101 |   await page.unroute('**:18330/draft-deletions/*');
  102 |   await page.getByRole('button', { name: 'Kontroller slettingen', exact: true }).click();
  103 |   await expect(status).toHaveText('Utkastet er slettet.'); expect(writes).toHaveLength(1);
  104 |   expect(await (await context.request.get(API + '/draft-deletions/' + writes[0].operation_id)).json()).toEqual({ deleted_id: draft.id });
  105 | });
  106 | 
```