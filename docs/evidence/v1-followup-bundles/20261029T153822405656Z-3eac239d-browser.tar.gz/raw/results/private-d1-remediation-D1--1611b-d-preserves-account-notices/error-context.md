# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: private-d1-remediation.spec.ts >> D1 explicit abandonment checks disappearance and preserves account notices
- Location: .v1followup-tests\private-d1-remediation.spec.ts:55:1

# Error details

```
Test timeout of 120000ms exceeded.
```

```
Error: locator.click: Test timeout of 120000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Kontroller bortfalt plan og forkast lokalt forsøk', exact: true })

```

# Test source

```ts
  1  | import { test, expect, openedPlan, API, post, randomUUID, beforeUnload, setup, activityStatus, shiftStatus } from './private-activity-helpers';
  2  | import { editor } from './private-screen-helpers';
  3  | setup();
  4  | 
  5  | for (const resource of ['selection', 'start']) test(`D1 canonical ${resource} rejection settles despite unavailable current read`, async ({ page, context }) => {
  6  |   const { plan } = await openedPlan(page, context);
  7  |   const path = '/workdays/' + plan.id + '/' + resource;
  8  |   const read = '/workdays/' + plan.id + '/' + (resource === 'start' ? 'lifecycle' : resource);
  9  |   let writes = 0;
  10 |   await page.route('**:18330' + path, route => {
  11 |     if (route.request().method() !== 'POST') return route.fulfill({ status: 503, json: { detail: 'Tjenesten er utilgjengelig.' } });
  12 |     writes++; return route.fulfill({ status: 429, json: { detail: { code: resource + '_receipt_capacity', message: 'For mange lagringsforsøk. Vent til tidligere planer utløper.' } } });
  13 |   });
  14 |   if (resource === 'start') await page.route('**:18330' + read, route => route.fulfill({ status: 503, json: { detail: 'Tjenesten er utilgjengelig.' } }));
  15 |   await page.getByRole('button', { name: resource === 'selection' ? 'Velg aktivitet 1' : 'Start skift', exact: true }).click();
  16 |   if (resource === 'start') await page.getByRole('button', { name: 'Bekreft skiftstart', exact: true }).click();
  17 |   const status = resource === 'selection' ? activityStatus(page) : shiftStatus(page);
  18 |   await expect(status).toContainText('avvist');
  19 |   await expect(page.getByRole('button', { name: resource === 'selection' ? 'Kontroller aktivitetsvalget' : 'Kontroller skiftstarten', exact: true })).toHaveCount(0);
  20 |   await expect(page.getByText(resource === 'selection' ? 'Lagret aktivitetsvalg kan ikke bekreftes.' : 'Skiftstatus er ukjent / utilgjengelig', { exact: true })).toBeVisible();
  21 |   await page.getByRole('button', { name: resource === 'selection' ? 'Avbryt avvist aktivitetsvalg' : 'Avbryt avvist skiftstart', exact: true }).click();
  22 |   await expect.poll(() => beforeUnload(page)).toBe(false); expect(writes).toBe(1);
  23 | });
  24 | 
  25 | test('D1 wrong identity conflict comparison preserves local proposal without B facts', async ({ page, context }) => {
  26 |   const { draft } = await openedPlan(page, context);
  27 |   await page.getByRole('button', { name: 'Lukk planen', exact: true }).click();
  28 |   await page.getByRole('button', { name: 'Oppdater listen', exact: true }).click();
  29 |   await page.getByRole('button', { name: 'Åpne 2031-01-02 · versjon 1', exact: true }).click(); await editor(page);
  30 |   await page.getByLabel('Vognløp', { exact: true }).fill('local-proposal-A');
  31 |   const path = '/drafts/' + draft.id;
  32 |   await page.route('**:18330' + path, route => route.request().method() === 'POST'
  33 |     ? route.fulfill({ status: 409, json: { detail: 'Utkastet er endret. Sammenlign med lagret versjon før du fortsetter.' } })
  34 |     : route.fulfill({ status: 200, json: { ...draft, id: randomUUID(), revision: 2, draft: { ...draft.draft, vehicle_duty: 'PRIVATE-B-FACT' } } }));
  35 |   await page.getByRole('button', { name: 'Lagre utkast', exact: true }).click();
  36 |   await expect(page.getByRole('status', { name: 'Lagringsstatus', exact: true })).toContainText('Konflikt');
  37 |   await expect(page.getByText('PRIVATE-B-FACT', { exact: true })).toHaveCount(0);
  38 |   await expect(page.getByRole('region', { name: 'Sammenlign versjoner' })).toHaveCount(0);
  39 |   await expect(page.getByLabel('Vognløp', { exact: true })).toHaveValue('local-proposal-A');
  40 | });
  41 | 
  42 | test('D1 source folds display authoritative supplied offsets', async ({ page, context }) => {
  43 |   await openedPlan(page, context);
  44 |   for (const [offset, title] of [['+02:00', 'First fold'], ['+01:00', 'Second fold']]) {
  45 |     await post(context, '/notices', { operation_id: (await post(context, '/notice-operations', {})).operation_id, expected_revision: 0,
  46 |       content: { title, line_scope: 'all', line_tags: [], source_updated_at: '2030-10-27T02:30:00' + offset, valid_from: null, valid_until: '2031-01-04T23:59:59+01:00', source_url: null } });
  47 |   }
  48 |   await page.getByRole('button', { name: 'Manuelt vedlikeholdte avvik', exact: true }).click();
  49 |   for (const [offset, title] of [['+02:00', 'First fold'], ['+01:00', 'Second fold']]) {
  50 |     const item = page.locator('.notice-list li').filter({ hasText: title }); await item.locator('summary').click();
  51 |     await expect(item).toContainText('02:30:00 (UTC' + offset + ')');
  52 |   }
  53 | });
  54 | 
  55 | test('D1 explicit abandonment checks disappearance and preserves account notices', async ({ page, context }) => {
  56 |   const { plan } = await openedPlan(page, context); const path = '/workdays/' + plan.id + '/selection'; let writes = 0;
  57 |   await post(context, '/notices', { operation_id: (await post(context, '/notice-operations', {})).operation_id, expected_revision: 0,
  58 |     content: { title: 'Independent retained notice', line_scope: 'all', line_tags: [], source_updated_at: null, valid_from: null, valid_until: '2031-01-04T23:59:59+01:00', source_url: null } });
  59 |   await page.route('**:18330' + path, async route => { if (route.request().method() !== 'POST') return route.continue(); writes++; await route.fetch(); await route.abort(); });
  60 |   await page.getByRole('button', { name: 'Velg aktivitet 1', exact: true }).click();
  61 |   await expect(page.getByRole('button', { name: 'Kontroller aktivitetsvalget', exact: true })).toBeEnabled();
  62 |   const abandon = page.getByRole('button', { name: 'Kontroller bortfalt plan og forkast lokalt forsøk', exact: true });
  63 |   // A transient current read must retain the uncertain operation and locks.
  64 |   await page.route('**:18330/workdays/' + plan.id, route => route.fulfill({ status: 503, json: { detail: 'Tjenesten er utilgjengelig.' } }));
> 65 |   await abandon.click(); await expect.poll(() => beforeUnload(page)).toBe(true);
     |                 ^ Error: locator.click: Test timeout of 120000ms exceeded.
  66 |   await page.unroute('**:18330/workdays/' + plan.id);
  67 |   await post(context, '/workdays/' + plan.id + '/delete', { operation_id: randomUUID(), source_revision: 1 });
  68 |   page.once('dialog', dialog => dialog.accept()); await abandon.click();
  69 |   await expect(page.getByRole('region', { name: 'Bekreftet plan', exact: true })).toHaveCount(0);
  70 |   await expect.poll(() => beforeUnload(page)).toBe(false); expect(writes).toBe(1);
  71 |   expect((await (await context.request.get(API + '/notices')).json()).notices.map((n: any) => n.title)).toContain('Independent retained notice');
  72 | });
  73 | 
```