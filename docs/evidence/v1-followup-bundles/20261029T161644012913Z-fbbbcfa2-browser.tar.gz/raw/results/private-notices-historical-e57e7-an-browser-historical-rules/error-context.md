# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: private-notices.spec.ts >> historical source clock roundtrip uses authoritative Oslo facts rather than browser historical rules
- Location: .v1followup-tests\private-notices.spec.ts:64:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Kilden oppdatert: 01.01.1894, 12:00:00 (Oslo-tid)', { exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('Kilden oppdatert: 01.01.1894, 12:00:00 (Oslo-tid)', { exact: true }) with timeout 5000ms
  - waiting for getByText('Kilden oppdatert: 01.01.1894, 12:00:00 (Oslo-tid)', { exact: true })

```

```yaml
- main:
  - button "Nattmodus"
  - text: "Visning: Dag"
  - paragraph: Privat tilgang
  - heading "Privat arbeidsrom" [level=1]
  - status "Tilgangsstatus": Du er logget inn.
  - region "Privat arbeidsrom":
    - region "Private utkast":
      - navigation "Plan og forberedelse":
        - button "Forberedelse og planlister"
        - button "Kontroller og rediger utkast"
        - button "Til den åpne planen"
    - region "Bekreft plan":
      - status "Bekreftelsesstatus": Bekreftet plan åpnet. Fristen er uendret.
      - region "Avviksvedlikehold":
        - heading "Manuelt vedlikeholdte avvik" [level=2]
        - paragraph: Forlengelse må lagres før gjeldende sluttid. Utløpte og manuelt avsluttede avvik er skrivebeskyttet historikk. Ingen av delene bekrefter at veien er klar eller at kilden er kontrollert.
        - paragraph: Felles avviksregister for kontoen. Avvik brukes automatisk på alle relevante bekreftede dager frem til sluttdatoen.
        - status "Avviksstatus": Avviket er lagret.
        - button "Tilbake til dagen"
        - button "Hent lagrede avvik"
        - button "Registrer avvik"
        - list:
          - listitem:
            - group:
              - text: Historisk klokkeslett beholdt · Registrert
              - paragraph: "Tittel: Historisk klokkeslett beholdt"
              - paragraph: "Linjer fra kilden: 020, 24"
              - paragraph: "Status: Registrert"
              - paragraph:
                - link "https://example.org/originalkilde":
                  - /url: https://example.org/originalkilde
              - paragraph: "Kilden oppdatert: 01.01.1894, 12:00:00 (UTC+00:43)"
              - paragraph: "Gyldighet: fra 01.01.1894, 12:00:00 (UTC+00:43) til 04.01.2031, 23:59:59 (UTC+01:00)"
              - paragraph: "Registrert: 29.10.2026, 17:20"
              - paragraph: "Sist endret: 29.10.2026, 17:20"
              - paragraph: Ikke kontrollert
              - button "Rediger Historisk klokkeslett beholdt"
              - button "Kontrollerte kilden nå"
              - button "Avslutt avvik manuelt"
              - paragraph: Kildekontroll registrerer ditt uttrykkelige kontrolltidspunkt. Det er ingen automatisk kontroll eller garanti for dekning.
      - region "Bekreftet plan":
        - button "Les avvik for linjer og datoer"
    - paragraph: Økten utløper 12.11.2026, 17:20.
    - button "Logg ut"
  - paragraph: Tilgang opprettes av den som drifter løsningen. Bruk arbeidsrommet mens du står stille.
  - link "Åpne fiktiv demo":
    - /url: /
```

# Test source

```ts
  1   | import { test, expect, openedPlan, API, post, randomUUID, beforeUnload, setup, dayScreen, activityScreen, selected, python, account } from './private-activity-helpers';
  2   | import { writeFileSync } from 'node:fs';
  3   | setup();
  4   | const status = (page: any) => page.getByRole('status', { name: 'Avviksstatus', exact: true });
  5   | const fields = { title: 'Fiktivt veiarbeid ved svært langt norsk stedsnavn', line_tags: ['020', '24'], source_url: 'https://example.org/originalkilde', source_updated_at: null, valid_from: null, valid_until: '2031-01-04T23:59:59+01:00' };
  6   | async function open(page: any) { await page.getByRole('button', { name: 'Manuelt vedlikeholdte avvik', exact: true }).click(); await expect(page.getByRole('heading', { name: 'Manuelt vedlikeholdte avvik', exact: true })).toBeVisible(); await expect(page.getByRole('button', { name: 'Hent lagrede avvik', exact: true })).toBeEnabled(); }
  7   | async function newNotice(page: any, title = fields.title) {
  8   |   await page.getByRole('button', { name: 'Registrer avvik', exact: true }).click(); await expect(page.getByRole('heading', { name: 'Rediger avvik', exact: true })).toBeFocused();
  9   |   await page.getByLabel('Gyldig tildato', { exact: true }).fill('2031-01-04'); await expect(page.getByRole('region', { name: 'Lagringskrav' })).not.toContainText('ufullstendig'); await page.getByLabel('Tittel', { exact: true }).fill(title); await page.getByLabel('Linjer fra kilden (kommaseparert)', { exact: true }).fill('020, 24, 020'); await page.getByLabel('Originalkilde (HTTP eller HTTPS)', { exact: true }).fill(fields.source_url);
  10  | }
  11  | async function save(page: any) { if (!await page.getByLabel('Gyldig tildato', { exact: true }).inputValue()) { await page.getByLabel('Gyldig tildato', { exact: true }).fill('2031-01-04'); await expect(page.getByRole('region', { name: 'Lagringskrav' })).not.toContainText('ufullstendig'); } await page.getByRole('button', { name: 'Lagre avvik', exact: true }).click(); await expect(status(page)).toHaveText('Avviket er lagret.'); }
  12  | async function list(context: any, plan: any) { return (await context.request.get(API + '/notices')).json(); }
  13  | async function seed(context: any, plan: any, title = fields.title) { return (await post(context, '/notices', { operation_id: (await post(context, '/notice-operations', {})).operation_id, expected_revision: 0, content: { ...fields, title } })).result; }
  14  | 
  15  | async function textFacts(scope: any, summary: string, description: string, sourceNote: string) {
  16  |   await expect(scope.getByText('Kort forklaring: ' + summary, { exact: true })).toBeVisible();
  17  |   const detail = scope.locator('p').filter({ hasText: 'Detaljert forklaring:' });
  18  |   await expect(detail).toBeVisible();
  19  |   await expect(detail).toHaveJSProperty('textContent', 'Detaljert forklaring: ' + description);
  20  |   await expect(detail).toHaveCSS('white-space', 'pre-wrap');
  21  |   await expect(scope.getByText('Kildebeskrivelse: ' + sourceNote, { exact: true })).toBeVisible();
  22  | }
  23  | 
  24  | test('notice feedback explains invalid optional source URL beside save and preserves the correction through navigation', async ({ page, context }) => {
  25  |   const { plan } = await openedPlan(page, context); await open(page); await newNotice(page, 'Omkjøring');
  26  |   await page.getByLabel('Linjer fra kilden (kommaseparert)', { exact: true }).fill('24');
  27  |   await page.getByLabel('Originalkilde (HTTP eller HTTPS)', { exact: true }).fill('svipper.no');
  28  |   await page.getByRole('button', { name: 'Lagre avvik', exact: true }).click();
  29  |   await expect(status(page)).toContainText('Ikke lagret. Kildelenken må være');
  30  |   await expect(page.getByRole('region', { name: 'Lagringskrav' })).toContainText('https://svipper.no/');
  31  |   expect((await list(context, plan)).notices).toHaveLength(0);
  32  |   await page.getByLabel('Originalkilde (HTTP eller HTTPS)', { exact: true }).fill('https://example.org/ugyldig lenke');
  33  |   await expect(status(page)).toContainText('uten mellomrom');
  34  |   await page.getByLabel('Originalkilde (HTTP eller HTTPS)', { exact: true }).fill('svipper.no');
  35  |   await page.getByRole('button', { name: 'Tilbake til avvik', exact: true }).click();
  36  |   await page.getByRole('button', { name: 'Tilbake til ulagret avvik', exact: true }).click();
  37  |   await expect(page.getByLabel('Tittel', { exact: true })).toHaveValue('Omkjøring');
  38  |   await expect(page.getByLabel('Originalkilde (HTTP eller HTTPS)', { exact: true })).toHaveValue('svipper.no');
  39  |   await page.getByLabel('Originalkilde (HTTP eller HTTPS)', { exact: true }).fill('https://example.org/trafikkmelding');
  40  |   await expect(page.getByRole('region', { name: 'Lagringskrav' })).not.toContainText('Kildelenken må være');
  41  |   await expect(status(page)).not.toContainText('Kildelenken må være');
  42  |   await save(page); const saved = (await list(context, plan)).notices;
  43  |   expect(saved).toHaveLength(1); expect(saved[0].line_tags).toEqual(['24']); expect(saved[0].valid_from).toBeNull(); expect(saved[0].valid_until).toBe('2031-01-04T23:59:59+01:00');
  44  | });
  45  | 
  46  | test('notice feedback names incomplete optional clock beside disabled save and clears when emptied', async ({ page, context }) => {
  47  |   const { plan } = await openedPlan(page, context); await open(page);
  48  |   await page.getByRole('button', { name: 'Registrer avvik', exact: true }).click();
  49  |   const requirements = page.getByRole('region', { name: 'Lagringskrav' });
  50  |   await expect(requirements).toContainText('Tittel er påkrevd'); await expect(requirements).toContainText('Linjer er påkrevd');
  51  |   await page.getByLabel('Tittel', { exact: true }).fill('Flyttet holdeplass');
  52  |   await page.getByLabel('Linjer fra kilden (kommaseparert)', { exact: true }).fill('24');
  53  |   await page.getByLabel('Originalkilde (HTTP eller HTTPS)', { exact: true }).fill(fields.source_url);
  54  |   await page.getByLabel('Gyldig fradato', { exact: true }).fill('2031-01-02');
  55  |   await expect(requirements).toContainText('Gyldig fra er ufullstendig eller uavklart');
  56  |   await expect(page.getByRole('button', { name: 'Lagre avvik', exact: true })).toBeDisabled();
  57  |   expect((await list(context, plan)).notices).toHaveLength(0);
  58  |   await page.getByRole('button', { name: 'Lagre avvik', exact: true }).scrollIntoViewIfNeeded();
  59  |   await page.screenshot({ path: '../tmp/v1followup/20261029T161644012913Z-fbbbcfa2/captures/11-5-crossday-real-feedback-required.png', fullPage: true });
  60  |   await page.getByLabel('Gyldig fradato', { exact: true }).fill('');
  61  |   await expect(requirements).not.toContainText('ufullstendig'); await save(page);
  62  | });
  63  | 
  64  | test('historical source clock roundtrip uses authoritative Oslo facts rather than browser historical rules', async ({ page, context }) => {
  65  |   const { plan } = await openedPlan(page, context);
  66  |   const source = '1894-01-01T12:00+00:43';
  67  |   const n = (await post(context, '/notices', { operation_id: (await post(context, '/notice-operations', {})).operation_id, expected_revision: 0, content: { ...fields, source_updated_at: source, valid_from: source, valid_until: fields.valid_until } })).result;
  68  |   await open(page); await page.locator('.notice-list summary').click(); await page.getByRole('button', { name: 'Rediger ' + n.title, exact: true }).click();
  69  |   await expect(page.getByLabel('Kilden oppdatert: klokkeslett', { exact: true })).toHaveValue('12:00:00');
  70  |   await page.route('**:18330/notices/' + n.id, async route => {
  71  |     const response = await route.fetch(), value = await response.json();
  72  |     for (const field of ['source_updated_at', 'valid_from', 'valid_until']) value.result[field] = new Date(value.result[field]).toISOString();
  73  |     await route.fulfill({ json: value }); // An older accepted UTC representation must still reconcile.
  74  |   });
  75  |   await page.getByLabel('Tittel', { exact: true }).fill('Historisk klokkeslett beholdt'); await save(page);
  76  |   const saved = (await list(context, plan)).notices[0]; expect(Date.parse(saved.source_updated_at)).toBe(Date.parse(source)); expect(Date.parse(saved.valid_from)).toBe(Date.parse(source)); expect(Date.parse(saved.valid_until)).toBe(Date.parse(fields.valid_until));
> 77  |   await expect(page.getByText('Kilden oppdatert: 01.01.1894, 12:00:00 (Oslo-tid)', { exact: true })).toBeVisible();
      |                                                                                                      ^ Error: expect(locator).toBeVisible() failed
  78  | });
  79  | 
  80  | test('quoted CSV tags preserve exact API tag boundaries on title-only edit', async ({ page, context }) => {
  81  |   const { plan } = await openedPlan(page, context); const tags = ['020', '20,24', 'Route "A"', 'a,"b,c"', 'H'.repeat(300)];
  82  |   const n = (await post(context, '/notices', { operation_id: (await post(context, '/notice-operations', {})).operation_id, expected_revision: 0, content: { ...fields, line_tags: tags } })).result;
  83  |   await open(page); await page.locator('.notice-list summary').click(); await page.getByRole('button', { name: 'Rediger ' + n.title, exact: true }).click();
  84  |   await expect(page.getByLabel('Linjer fra kilden (kommaseparert)', { exact: true })).toHaveValue('020, "20,24", "Route ""A""", "a,""b,c""", ' + 'H'.repeat(300));
  85  |   await page.getByLabel('Tittel', { exact: true }).fill('Bare tittel endret'); await save(page); expect((await list(context, plan)).notices[0].line_tags).toEqual(tags);
  86  |   await page.getByRole('button', { name: 'Rediger Bare tittel endret', exact: true }).click(); await page.getByLabel('Linjer fra kilden (kommaseparert)', { exact: true }).fill('20, "unfinished'); await expect(page.getByRole('alert')).toContainText('mangler avsluttende anførselstegn'); await expect(page.getByRole('button', { name: 'Lagre avvik', exact: true })).toBeDisabled();
  87  | });
  88  | 
  89  | test('reversed known validity gives a relation error, preserves clocks and makes no request until corrected', async ({ page, context }) => {
  90  |   const { plan } = await openedPlan(page, context); await open(page); await newNotice(page); let posts = 0;
  91  |   page.on('request', req => { if (req.method() === 'POST' && req.url().endsWith('/notices')) posts++; });
  92  |   await page.getByLabel('Gyldig fradato', { exact: true }).fill('2031-01-02'); await page.getByLabel('Gyldig fra: klokkeslett', { exact: true }).fill('12:00'); await page.getByLabel('Gyldig tildato', { exact: true }).fill('2031-01-02'); await page.getByLabel('Gyldig til: klokkeslett', { exact: true }).fill('11:00');
  93  |   await expect(page.getByRole('alert')).toContainText('Gyldig til må være samtidig med eller etter Gyldig fra.'); await expect(page.getByRole('button', { name: 'Lagre avvik', exact: true })).toBeDisabled(); expect(posts).toBe(0); expect((await list(context, plan)).notices).toHaveLength(0); await expect(page.getByLabel('Gyldig fra: klokkeslett', { exact: true })).toHaveValue('12:00');
  94  |   await page.getByLabel('Gyldig til: klokkeslett', { exact: true }).fill('13:00'); await expect(page.getByRole('alert')).toHaveCount(0); await save(page); expect(posts).toBe(1);
  95  | });
  96  | 
  97  | for (const code of ['notice_capacity', 'notice_receipt_capacity']) test(`known ${code} rejection retains specific guidance and the cancellable proposal`, async ({ page, context }) => {
  98  |   const { plan } = await openedPlan(page, context); await open(page); await newNotice(page);
  99  |   const message = code === 'notice_capacity' ? 'Registeret har allerede 200 avvik.' : 'For mange lagringsforsøk. Vent til tidligere avvik utløper.';
  100 |   await page.route('**:18330/notices', route => route.request().method() === 'POST' ? route.fulfill({ status: 429, json: { detail: { code, message } } }) : route.continue());
  101 |   await page.getByRole('button', { name: 'Lagre avvik', exact: true }).click(); await expect(status(page)).toContainText(message); await expect(status(page)).not.toContainText('sammenlign'); await expect(page.getByLabel('Tittel', { exact: true })).toHaveValue(fields.title); expect((await list(context, plan)).notices).toHaveLength(0); await page.getByRole('button', { name: 'Forkast ulagrede endringer', exact: true }).click(); await expect.poll(() => beforeUnload(page)).toBe(false);
  102 | });
  103 | 
  104 | for (const oldReply of ['success', 'unavailable']) test(`held superseded ${oldReply} load cannot overwrite newer success`, async ({ page, context }) => {
  105 |   const { plan } = await openedPlan(page, context); await seed(context, plan); let release!: () => void, received!: () => void, count = 0;
  106 |   const gate = new Promise<void>(r => release = r), entered = new Promise<void>(r => received = r);
  107 |   await page.route('**:18330/notices', async route => { count++; if (count !== 1) return route.continue(); const response = await route.fetch(); received(); await gate; if (oldReply === 'success') await route.fulfill({ response }); else await route.fulfill({ status: 503, json: { detail: 'superseded unavailable' } }); });
  108 |   try {
  109 |     await page.getByRole('button', { name: 'Manuelt vedlikeholdte avvik', exact: true }).click(); await entered; await page.getByRole('button', { name: 'Tilbake til dagen', exact: true }).click(); await open(page); await expect(status(page)).toHaveText('Lagrede avvik er hentet.');
  110 |     const returned = page.waitForResponse(r => r.url().endsWith('/notices')); release(); await (await returned).finished(); await expect(status(page)).toHaveText('Lagrede avvik er hentet.'); await expect(page.getByRole('button', { name: 'Registrer avvik', exact: true })).toBeEnabled(); await expect(page.locator('.notice-list summary')).toHaveCount(1);
  111 |   } finally { release(); }
  112 | });
  113 | 
  114 | for (const surface of ['current', 'acknowledgement']) for (const invalid of ['2031-01-02T12:00:00', '2031-02-30T12:00:00Z']) test(`${surface} rejects non-explicit or normalized-invalid timestamp ${invalid}`, async ({ page, context }) => {
  115 |   const { plan } = await openedPlan(page, context);
  116 |   if (surface === 'current') {
  117 |     await seed(context, plan); await page.route('**:18330/notices', async route => { const response = await route.fetch(), value = await response.json(); value.notices[0].source_updated_at = invalid; await route.fulfill({ json: value }); });
  118 |     await page.getByRole('button', { name: 'Manuelt vedlikeholdte avvik', exact: true }).click(); await expect(status(page)).toContainText('Avvikslisten er utilgjengelig.'); await expect(page.locator('.notice-list summary')).toHaveCount(0); await expect(page.getByRole('button', { name: 'Registrer avvik', exact: true })).toBeDisabled();
  119 |   } else {
  120 |     await open(page); await newNotice(page); await page.route('**:18330/notices', async route => { if (route.request().method() !== 'POST') return route.continue(); const response = await route.fetch(), value = await response.json(); value.result.source_updated_at = invalid; await route.fulfill({ json: value }); });
  121 |     await page.getByRole('button', { name: 'Lagre avvik', exact: true }).click(); await expect(page.getByRole('button', { name: 'Kontroller avvikslagringen', exact: true })).toBeEnabled(); await expect(status(page)).toContainText('uavklart'); await expect(page.getByLabel('Tittel', { exact: true })).toHaveValue(fields.title); await page.getByRole('button', { name: 'Kontroller avvikslagringen', exact: true }).click(); await expect(status(page)).toHaveText('Avviket er lagret.');
  122 |   }
  123 | });
  124 | 
  125 | test('complete multipage controller keeps all51 discoverable, edits page2, and rejects partial later-page success', async ({ page, context }) => {
  126 |   const { plan } = await openedPlan(page, context); const n = await seed(context, plan);
  127 |   python(`with database() as conn:\n conn.execute("INSERT INTO workday_notices(id,workday_id,revision,title,line_tags,source_url,source_updated_at,valid_from,valid_until,status,entered_at,edited_at,checked_at,checked_revision,summary,description,source_note,line_scope,owner,expires_at,ended_at) SELECT gen_random_uuid(),workday_id,revision,'Syntetisk avvik '||g.n,title_tags.line_tags,source_url,source_updated_at,valid_from,valid_until,status,entered_at,edited_at,checked_at,checked_revision,summary,description,source_note,line_scope,owner,expires_at,ended_at FROM workday_notices title_tags CROSS JOIN generate_series(1,50) g(n) WHERE id=%s", (${JSON.stringify(n.id)},))\n`);
  128 |   const first = await list(context, plan); const second = await (await context.request.get(API + '/notices?cursor=' + first.next_cursor)).json(); expect(second.notices).toHaveLength(1); const target = second.notices[0];
  129 |   await page.route('**:18330/notices?cursor=*', route => route.fulfill({ status: 503, json: { detail: 'synthetic page2 unavailable' } })); await page.getByRole('button', { name: 'Manuelt vedlikeholdte avvik', exact: true }).click(); await expect(status(page)).toContainText('Avvikslisten er utilgjengelig.'); await expect(page.locator('.notice-list summary')).toHaveCount(0); await expect(page.getByRole('button', { name: 'Registrer avvik', exact: true })).toBeDisabled();
  130 |   await page.unroute('**:18330/notices?cursor=*'); await page.getByRole('button', { name: 'Hent lagrede avvik', exact: true }).click(); await expect(status(page)).toHaveText('Lagrede avvik er hentet.'); await expect(page.locator('.notice-list summary')).toHaveCount(51); await page.locator('.notice-list summary').filter({ hasText: target.title + ' ·' }).click(); await page.getByRole('button', { name: 'Rediger ' + target.title, exact: true }).click(); await page.getByLabel('Tittel', { exact: true }).fill('Endret avvik fra side2'); await save(page); await expect(page.locator('.notice-list summary')).toHaveCount(51);
  131 |   const saved = await (await context.request.get(API + '/notices/' + target.id)).json(); expect(saved.title).toBe('Endret avvik fra side2'); expect(saved.revision).toBe(2);
  132 | });
  133 | 
  134 | for (const kind of ['check', 'end']) for (const recovery of ['lookup', 'retry']) test(`lost accepted ${kind} ${recovery} retains original action through day navigation with one effect`, async ({ page, context }) => {
  135 |   const { plan } = await openedPlan(page, context); const n = await seed(context, plan); await open(page); await page.locator('.notice-list summary').click(); const path = '/notices/' + n.id + '/' + kind; const writes: any[] = [];
  136 |   await page.route('**:18330' + path, async route => { writes.push(route.request().postDataJSON()); await route.fetch(); await route.fulfill({ status: 200, contentType: 'text/html', body: '<html>lost action</html>' }); });
  137 |   if (kind === 'end') page.once('dialog', d => d.accept()); await page.getByRole('button', { name: kind === 'check' ? 'Kontrollerte kilden nå' : 'Avslutt avvik manuelt', exact: true }).click(); await expect(page.getByRole('button', { name: 'Kontroller avvikslagringen', exact: true })).toBeEnabled(); const accepted = (await list(context, plan)).notices[0]; expect(accepted.revision).toBe(2);
  138 |   await page.getByRole('button', { name: 'Tilbake til dagen', exact: true }).click(); await expect(page.getByRole('button', { name: 'Lukk planen', exact: true })).toBeEnabled(); await open(page); await page.unroute('**:18330' + path); page.on('request', req => { if (req.method() === 'POST' && req.url().endsWith(path)) writes.push(req.postDataJSON()); });
  139 |   await page.getByRole('button', { name: recovery === 'lookup' ? 'Kontroller avvikslagringen' : 'Prøv samme avvikslagring igjen', exact: true }).click(); await expect(status(page)).toHaveText(kind === 'check' ? 'Kildekontrollen er lagret.' : 'Avviket er avsluttet manuelt.'); expect((await list(context, plan)).notices).toEqual([accepted]); expect(writes).toHaveLength(1); await expect.poll(() => beforeUnload(page)).toBe(false);
  140 | });
  141 | 
  142 | for (const boundary of ['deleted', 'expired']) test(`notice ${boundary} after known rejection preserves proposal without exposing historical facts as active`, async ({ page, context }) => {
  143 |   const { plan } = await openedPlan(page, context); const n = await seed(context, plan); await open(page); await page.locator('.notice-list summary').click();
  144 |   await page.getByRole('button', { name: 'Rediger ' + n.title, exact: true }).click(); await page.getByLabel('Tittel', { exact: true }).fill('Beholdt lokalt forslag');
  145 |   await page.route('**:18330/notices/' + n.id, async route => {
  146 |     python(`with database() as conn:\n conn.execute(${JSON.stringify(boundary === 'deleted' ? 'DELETE FROM workday_notices WHERE id=%s' : 'UPDATE workday_notices SET expires_at=clock_timestamp() WHERE id=%s')}, (${JSON.stringify(n.id)},))\n`);
  147 |     await route.fulfill({ status: 409, json: { detail: 'Lagret avvik er endret. Hent og gjennomgå på nytt.' } });
  148 |   });
  149 |   await page.getByRole('button', { name: 'Lagre avvik', exact: true }).click(); await expect(status(page)).toContainText('Forsøket ble avvist.');
  150 |   await expect(page.getByLabel('Tittel', { exact: true })).toHaveValue('Beholdt lokalt forslag'); expect(await beforeUnload(page)).toBe(true);
  151 |   await page.getByRole('button', { name: 'Tilbake til avvik', exact: true }).click(); await expect(page.locator('.notice-list summary')).toHaveCount(0);
  152 |   await page.getByRole('button', { name: 'Tilbake til ulagret avvik', exact: true }).click(); await page.getByRole('button', { name: 'Forkast ulagrede endringer', exact: true }).click();
  153 |   await expect.poll(() => beforeUnload(page)).toBe(false);
  154 | });
  155 | async function measure(page: any) {
  156 |   const scope = page.getByRole('region', { name: 'Avviksvedlikehold', exact: true });
  157 |   const detail = scope.getByLabel('Detaljert forklaring', { exact: true });
  158 |   const control = await detail.isVisible() && await detail.isEnabled() ? detail : scope.getByRole('button', { name: 'Tilbake til dagen', exact: true }); await control.focus(); await page.keyboard.press('Tab'); await page.keyboard.press('Shift+Tab'); await expect(control).toBeFocused(); await control.scrollIntoViewIfNeeded();
  159 |   const metrics = await scope.evaluate((region: Element) => {
  160 |     const light = (v: string) => (v.match(/[\d.]+/g) ?? []).slice(0, 3).map(Number).map(c => { c /= 255; return c <= .04045 ? c / 12.92 : ((c + .055) / 1.055) ** 2.4; }).reduce((sum, c, i) => sum + c * [.2126, .7152, .0722][i], 0);
  161 |     const ratio = (a: string, b: string) => (Math.max(light(a), light(b)) + .05) / (Math.min(light(a), light(b)) + .05);
  162 |     const bg = (node: Element): string => { const value = getComputedStyle(node).backgroundColor; return value === 'rgba(0, 0, 0, 0)' || value === 'transparent' ? node.parentElement ? bg(node.parentElement) : 'rgb(255,255,255)' : value; };
  163 |     const visible = [...region.querySelectorAll('h2,h3,p,label,legend,a,button,input,textarea,select,summary')].filter(node => node.getBoundingClientRect().height > 0);
  164 |     const focused = document.activeElement!, style = getComputedStyle(focused), rect = focused.getBoundingClientRect();
  165 |     const controls = visible.filter(node => ['BUTTON', 'INPUT', 'TEXTAREA', 'SELECT', 'SUMMARY'].includes(node.tagName)).map(node => { const s = getComputedStyle(node); return { tag: node.tagName, disabled: (node as HTMLInputElement).disabled, height: node.getBoundingClientRect().height, text: ratio(s.color, bg(node)), boundary: ratio(s.borderTopColor, bg(node.parentElement!)) }; });
  166 |     return { overflow: document.documentElement.scrollWidth > innerWidth, text: Math.min(...visible.map(node => ratio(getComputedStyle(node).color, bg(node)))), focus: ratio(style.outlineColor, bg(focused.parentElement!)), focusWidth: parseFloat(style.outlineWidth), focusVisible: focused.matches(':focus-visible'), focusNotObscured: rect.bottom > 0 && rect.top < innerHeight && focused.contains(document.elementFromPoint(Math.max(1, Math.min(innerWidth - 1, rect.x + rect.width / 2)), Math.max(1, Math.min(innerHeight - 1, rect.y + rect.height / 2)))) , controls };
  167 |   });
  168 |   expect(metrics.overflow).toBe(false); expect(metrics.text).toBeGreaterThanOrEqual(4.5); expect(metrics.focus).toBeGreaterThanOrEqual(3); expect(metrics.focusWidth).toBeGreaterThanOrEqual(2); expect(metrics.focusVisible).toBe(true); expect(metrics.focusNotObscured).toBe(true);
  169 |   for (const c of metrics.controls) { expect(c.height).toBeGreaterThanOrEqual(58); expect(c.text).toBeGreaterThanOrEqual(4.5); expect(c.boundary).toBeGreaterThanOrEqual(3); }
  170 |   return metrics;
  171 | }
  172 | 
  173 | test('source-linked prestart journey saves exact stable metadata, checks explicitly, qualifies edit, ends deliberately and retains selection', async ({ page, context }) => {
  174 |   const { plan, activities } = await openedPlan(page, context);
  175 |   await page.getByRole('button', { name: 'Velg aktivitet 2', exact: true }).click(); await activityScreen(page); await dayScreen(page);
  176 |   const initial = await (await context.request.get(API + '/workdays/' + plan.id + '/recap')).json(); let selections = 0, starts = 0, checks = 0, ends = 0;
  177 |   page.on('request', req => { if (req.method() === 'POST') { if (req.url().endsWith('/selection')) selections++; if (req.url().endsWith('/start')) starts++; if (req.url().endsWith('/check')) checks++; if (req.url().endsWith('/end')) ends++; } });
```