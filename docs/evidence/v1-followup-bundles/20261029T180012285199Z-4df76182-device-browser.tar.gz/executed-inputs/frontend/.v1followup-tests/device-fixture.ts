
import {test as base,chromium} from '@playwright/test';
export * from '@playwright/test';
export const test=base.extend({
 browser:[async({},use)=>{const browser=await chromium.connectOverCDP(process.env.V1_DEVICE_ENDPOINT!);await use(browser);await browser.close();},{scope:'worker'}],
 context:async({browser},use)=>{const context=await browser.newContext({viewport:null});await use(context);await context.close();},
 page:async({context},use)=>{const page=await context.newPage();await page.bringToFront();await use(page);await page.close();}
});
