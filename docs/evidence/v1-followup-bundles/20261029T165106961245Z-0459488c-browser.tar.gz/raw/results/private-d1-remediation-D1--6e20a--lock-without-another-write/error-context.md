# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: private-d1-remediation.spec.ts >> D1 server410 abandonment releases distinct physical-bus parent lock without another write
- Location: .v1followup-tests\private-d1-remediation.spec.ts:235:71

# Error details

```
Error: locator.fill: Error: strict mode violation: getByLabel('Fysisk buss', { exact: true }) resolved to 2 elements:
    1) <section class="private-bus" aria-label="Fysisk buss">…</section> aka getByRole('region', { name: 'Fysisk buss' })
    2) <input value="" autocomplete="off" aria-invalid="false"/> aka getByRole('textbox', { name: 'Fysisk buss' })

Call log:
  - waiting for getByLabel('Fysisk buss', { exact: true })

```

# Test source

```ts
  1   | import { test, expect, openedPlan, API, post, randomUUID, beforeUnload, setup, activityStatus, shiftStatus, activityScreen, python } from './private-activity-helpers';
  2   | import { editor } from './private-screen-helpers';
  3   | setup();
  4   | 
  5   | async function uncertainCommand(page: any, context: any, resource: 'selection' | 'start' | 'physical-bus' | 'outcome') {
  6   |   const { plan } = await openedPlan(page, context);
  7   |   if (resource === 'outcome') {
  8   |     await page.getByRole('button', { name: 'Start skift', exact: true }).click();
  9   |     await page.getByRole('button', { name: 'Bekreft skiftstart', exact: true }).click();
  10  |     await expect(shiftStatus(page)).toHaveText('Skiftstart er lagret.');
  11  |     await page.getByRole('button', { name: 'Velg aktivitet 1', exact: true }).click();
  12  |     await activityScreen(page);
  13  |   }
  14  |   const path = '/workdays/' + plan.id + '/' + resource;
  15  |   let original: any, writes = 0;
  16  |   await page.route('**:18330' + path, async (route: any) => {
  17  |     if (route.request().method() !== 'POST') return route.continue();
  18  |     writes++; original = route.request().postDataJSON(); await route.fetch(); await route.abort();
  19  |   });
  20  |   if (resource === 'physical-bus') {
> 21  |     await page.getByLabel('Fysisk buss', { exact: true }).fill('Synthetic uncertain bus');
      |                                                           ^ Error: locator.fill: Error: strict mode violation: getByLabel('Fysisk buss', { exact: true }) resolved to 2 elements:
  22  |     await page.getByRole('button', { name: 'Lagre fysisk buss', exact: true }).click();
  23  |   } else if (resource === 'outcome') {
  24  |     await page.getByLabel('Manuell aktivitetsstatus', { exact: true }).selectOption('interrupted');
  25  |     await page.getByRole('button', { name: 'Lagre aktivitetsstatus', exact: true }).click();
  26  |   } else {
  27  |     await page.getByRole('button', { name: resource === 'selection' ? 'Velg aktivitet 1' : 'Start skift', exact: true }).click();
  28  |     if (resource === 'start') await page.getByRole('button', { name: 'Bekreft skiftstart', exact: true }).click();
  29  |   }
  30  |   const check = page.getByRole('button', { name: { selection: 'Kontroller aktivitetsvalget', start: 'Kontroller skiftstarten', 'physical-bus': 'Kontroller busslagringen', outcome: 'Kontroller aktivitetsstatusen' }[resource], exact: true });
  31  |   await expect(check).toBeEnabled();
  32  |   return { plan, check, original, writes: () => writes, lookup: '/workday-' + (resource === 'physical-bus' ? 'bus' : resource) + '-operations/' + original.operation_id };
  33  | }
  34  | 
  35  | for (const resource of ['selection', 'start']) for (const automaticRead of ['failed', 'successful']) test(`D1 canonical ${resource} rejection retains cancellation through repeated failed refreshes after ${automaticRead} automatic read`, async ({ page, context }, testInfo) => {
  36  |   const { plan } = await openedPlan(page, context);
  37  |   const path = '/workdays/' + plan.id + '/' + resource;
  38  |   const read = '/workdays/' + plan.id + '/' + (resource === 'start' ? 'lifecycle' : resource);
  39  |   let writes = 0, failCurrent = automaticRead === 'failed';
  40  |   await page.route('**:18330' + path, route => {
  41  |     if (route.request().method() !== 'POST') return failCurrent ? route.fulfill({ status: 503, json: { detail: 'Tjenesten er utilgjengelig.' } }) : route.continue();
  42  |     writes++; return route.fulfill({ status: 429, json: { detail: { code: resource + '_receipt_capacity', message: 'For mange lagringsforsøk. Vent til tidligere planer utløper.' } } });
  43  |   });
  44  |   if (resource === 'start') await page.route('**:18330' + read, route => failCurrent ? route.fulfill({ status: 503, json: { detail: 'Tjenesten er utilgjengelig.' } }) : route.continue());
  45  |   await page.getByRole('button', { name: resource === 'selection' ? 'Velg aktivitet 1' : 'Start skift', exact: true }).click();
  46  |   if (resource === 'start') await page.getByRole('button', { name: 'Bekreft skiftstart', exact: true }).click();
  47  |   const status = resource === 'selection' ? activityStatus(page) : shiftStatus(page);
  48  |   await expect(status).toContainText('avvist');
  49  |   await expect(page.getByRole('button', { name: resource === 'selection' ? 'Kontroller aktivitetsvalget' : 'Kontroller skiftstarten', exact: true })).toHaveCount(0);
  50  |   const cancel = page.getByRole('button', { name: resource === 'selection' ? 'Avbryt avvist aktivitetsvalg' : 'Avbryt avvist skiftstart', exact: true });
  51  |   const retry = page.getByRole('button', { name: resource === 'selection' ? 'Prøv avvist aktivitetsvalg igjen' : 'Prøv avvist skiftstart igjen', exact: true });
  52  |   const refresh = page.getByRole('button', { name: resource === 'selection' ? 'Kontroller plantilgang og aktivitetsvalg' : 'Hent skiftstatus igjen', exact: true });
  53  |   await expect(cancel).toBeEnabled();
  54  |   failCurrent = true;
  55  |   for (let attempt = 0; attempt < 2; attempt++) {
  56  |     const response = page.waitForResponse(reply => reply.url().endsWith(read) && reply.request().method() === 'GET');
  57  |     await refresh.click(); await (await response).finished(); await expect(refresh).toBeEnabled();
  58  |     await expect(cancel).toBeEnabled(); await expect(retry).toBeDisabled();
  59  |     await expect(page.getByText(resource === 'selection' ? 'Lagret aktivitetsvalg kan ikke bekreftes.' : 'Skiftstatus er ukjent / utilgjengelig', { exact: true })).toBeVisible();
  60  |     await expect.poll(() => beforeUnload(page)).toBe(true);
  61  |   }
  62  |   await page.screenshot({ path: testInfo.outputPath(resource + '-rejected-unavailable.png'), fullPage: true });
  63  |   failCurrent = false;
  64  |   await refresh.click(); await expect(status).toContainText('Det avviste forslaget er beholdt');
  65  |   await expect(cancel).toBeEnabled(); await expect.poll(() => beforeUnload(page)).toBe(true);
  66  |   if (resource === 'selection') await expect(page.getByText(/^Lokalt forslag/)).toBeVisible();
  67  |   await cancel.click();
  68  |   await expect.poll(() => beforeUnload(page)).toBe(false); expect(writes).toBe(1);
  69  | });
  70  | 
  71  | for (const resource of ['selection', 'start']) for (const refusal of [429, 409]) test(`D1 accepted ${resource} lost reply retains original after typed lookup ${refusal}`, async ({ page, context }) => {
  72  |   const { plan } = await openedPlan(page, context);
  73  |   const path = '/workdays/' + plan.id + '/' + resource;
  74  |   let original: any, writes = 0;
  75  |   await page.route('**:18330' + path, async route => {
  76  |     if (route.request().method() !== 'POST') return route.continue();
  77  |     writes++; original = route.request().postDataJSON(); await route.fetch(); await route.abort();
  78  |   });
  79  |   await page.getByRole('button', { name: resource === 'selection' ? 'Velg aktivitet 1' : 'Start skift', exact: true }).click();
  80  |   if (resource === 'start') await page.getByRole('button', { name: 'Bekreft skiftstart', exact: true }).click();
  81  |   const check = page.getByRole('button', { name: resource === 'selection' ? 'Kontroller aktivitetsvalget' : 'Kontroller skiftstarten', exact: true });
  82  |   await expect(check).toBeEnabled();
  83  |   const lookupPath = '/workday-' + resource + '-operations/' + original.operation_id;
  84  |   await page.route('**:18330' + lookupPath, route => route.fulfill({ status: refusal, json: { detail: refusal === 429
  85  |     ? { code: resource + '_receipt_capacity', message: 'For mange lagringsforsøk. Vent til tidligere planer utløper.' }
  86  |     : resource === 'selection' ? 'Aktivitetsvalget er endret. Sammenlign med lagret verdi.' : 'Skiftstatusen er endret. Last inn lagret status.' } }));
  87  |   const lookup = page.waitForResponse(reply => reply.url().endsWith(lookupPath));
  88  |   await page.getByRole('button', { name: resource === 'selection' ? 'Prøv samme aktivitetsvalg igjen' : 'Prøv samme skiftstart igjen', exact: true }).click();
  89  |   await (await lookup).finished(); await expect(check).toBeEnabled();
  90  |   await expect(page.getByRole('button', { name: resource === 'selection' ? 'Avbryt avvist aktivitetsvalg' : 'Avbryt avvist skiftstart', exact: true })).toHaveCount(0);
  91  |   await expect(page.getByRole('button', { name: 'Last inn lagret aktivitetsvalg', exact: true })).toHaveCount(0);
  92  |   await expect.poll(() => beforeUnload(page)).toBe(true); expect(writes).toBe(1);
  93  |   await page.unroute('**:18330' + lookupPath);
  94  |   const recovered = page.waitForRequest(request => request.url().endsWith(lookupPath));
  95  |   await check.click(); await recovered;
  96  |   await expect(resource === 'selection' ? activityStatus(page) : shiftStatus(page)).toHaveText(resource === 'selection' ? 'Aktivitetsvalget er lagret.' : 'Skiftstart er lagret.');
  97  |   await expect.poll(() => beforeUnload(page)).toBe(false); expect(writes).toBe(1);
  98  |   expect((await (await context.request.get(API + lookupPath)).json()).operation_id).toBe(original.operation_id);
  99  | });
  100 | 
  101 | test('D1 wrong identity conflict comparison preserves local proposal without B facts', async ({ page, context }) => {
  102 |   const { draft } = await openedPlan(page, context);
  103 |   await page.getByRole('button', { name: 'Lukk planen', exact: true }).click();
  104 |   await page.getByRole('button', { name: 'Oppdater listen', exact: true }).click();
  105 |   await page.getByRole('button', { name: 'Åpne 2031-01-02 · versjon 1', exact: true }).click(); await editor(page);
  106 |   await page.getByLabel('Vognløp', { exact: true }).fill('local-proposal-A');
  107 |   const path = '/drafts/' + draft.id;
  108 |   await page.route('**:18330' + path, route => route.request().method() === 'POST'
  109 |     ? route.fulfill({ status: 409, json: { detail: 'Utkastet er endret. Sammenlign med lagret versjon før du fortsetter.' } })
  110 |     : route.fulfill({ status: 200, json: { ...draft, id: randomUUID(), revision: 2, draft: { ...draft.draft, vehicle_duty: 'PRIVATE-B-FACT' } } }));
  111 |   await page.getByRole('button', { name: 'Lagre utkast', exact: true }).click();
  112 |   await expect(page.getByRole('status', { name: 'Lagringsstatus', exact: true })).toContainText('Konflikt');
  113 |   await expect(page.getByText('PRIVATE-B-FACT', { exact: true })).toHaveCount(0);
  114 |   await expect(page.getByRole('region', { name: 'Sammenlign versjoner' })).toHaveCount(0);
  115 |   await expect(page.getByLabel('Vognløp', { exact: true })).toHaveValue('local-proposal-A');
  116 | });
  117 | 
  118 | test('D1 source folds display authoritative supplied offsets', async ({ page, context }, testInfo) => {
  119 |   await openedPlan(page, context, false, undefined, undefined, false, content => {
  120 |     content.service_date = '2030-10-27';
  121 |     content.activities = [{ ...content.activities[0], start: '2030-10-27T02:00:00+02:00', end: '2030-10-27T03:00:00+01:00' }];
```