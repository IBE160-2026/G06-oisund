# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: private-d2-qualification.spec.ts >> D2 A7 independent synthetic source shapes survive cross-day reading and parent removal/expiry
- Location: .v1followup-tests\private-d2-qualification.spec.ts:27:1

# Error details

```
Error: expect(received).toMatchObject(expected)

- Expected  - 2
+ Received  + 1

@@ -21,12 +21,11 @@
  Uavhengig skrevet norsk instruksjon: gå gjennom skilting mens bussen står stille.
  Uavhengig skrevet norsk instruksjon: gå gjennom skilting mens bussen står stille.
  Uavhengig skrevet norsk instruksjon: gå gjennom skilting mens bussen står stille.
  Uavhengig skrevet norsk instruksjon: gå gjennom skilting mens bussen står stille.
  Uavhengig skrevet norsk instruksjon: gå gjennom skilting mens bussen står stille.
- Uavhengig skrevet norsk instruksjon: gå gjennom skilting mens bussen står stille.
- ",
+ Uavhengig skrevet norsk instruksjon: gå gjennom skilting mens bussen står stille.",
    "line_scope": "all",
    "line_tags": Array [],
    "revision": 1,
    "source_note": "Syntetisk eksempel med delt lenke.",
    "source_updated_at": null,
```

# Test source

```ts
  1   | import { test, expect, openedPlan, post, API, setup, python, randomUUID, beforeUnload } from './private-activity-helpers';
  2   | import { editor } from './private-screen-helpers';
  3   | import { writeFileSync } from 'node:fs';
  4   | setup();
  5   | test.use({ actionTimeout: 15000 });
  6   | const feedback = (page: any) => page.getByRole('status', { name: 'Avviksstatus', exact: true });
  7   | const examples = [
  8   |   { title: 'Syntetisk SMS om midlertidig holdeplass', summary: 'Bruk midlertidig holdeplass ved kaia.', description: '2. januar 2031: Linje 20 mot nord bruker kaia.\n3. januar 2031: Linje 24 mot sør bruker biblioteket.\nDette er et uavhengig syntetisk aksepteksempel.', source_note: 'Syntetisk SMS fra trafikkleder; ingen nettadresse.', source_url: null, line_scope: 'selected', line_tags: ['20', '24'] },
  9   |   { title: 'Syntetisk delt lenke med lang instruksjon', summary: 'Felles melding for alle linjer.', description: 'Uavhengig skrevet norsk instruksjon: gå gjennom skilting mens bussen står stille.\n'.repeat(24), source_note: 'Syntetisk eksempel med delt lenke.', source_url: 'https://example.invalid/delt-melding', line_scope: 'all', line_tags: [] },
  10  | ];
  11  | async function open(page: any) {
  12  |   await page.getByRole('button', { name: 'Manuelt vedlikeholdte avvik', exact: true }).click();
  13  |   await expect(page.getByRole('button', { name: 'Hent lagrede avvik', exact: true })).toBeEnabled();
  14  | }
  15  | async function fill(page: any, item: typeof examples[number]) {
  16  |   await page.getByRole('button', { name: 'Registrer avvik', exact: true }).click();
  17  |   await page.getByLabel('Gyldig tildato', { exact: true }).fill('2031-01-04');
  18  |   await page.getByLabel('Tittel', { exact: true }).fill(item.title);
  19  |   await page.getByLabel('Kort forklaring', { exact: true }).fill(item.summary);
  20  |   await page.getByLabel('Detaljert forklaring', { exact: true }).fill(item.description);
  21  |   await page.getByLabel('Kildebeskrivelse', { exact: true }).fill(item.source_note);
  22  |   await page.getByLabel('Originalkilde (HTTP eller HTTPS)', { exact: true }).fill(item.source_url ?? '');
  23  |   await page.getByLabel('Linjeomfang', { exact: true }).selectOption(item.line_scope);
  24  |   if (item.line_scope === 'selected') await page.getByLabel('Linjer fra kilden (kommaseparert)', { exact: true }).fill(item.line_tags.join(', '));
  25  | }
  26  | 
  27  | test('D2 A7 independent synthetic source shapes survive cross-day reading and parent removal/expiry', async ({ page, context }, testInfo) => {
  28  |   const { plan: a } = await openedPlan(page, context);
  29  |   const original = await (await context.request.get(API + '/drafts/' + a.source_draft_id)).json();
  30  |   const content = structuredClone(original.draft); content.service_date = '2031-01-03';
  31  |   for (const activity of content.activities) for (const field of ['start', 'end']) activity[field] = activity[field].replace('2031-01-03', '2031-01-04').replace('2031-01-02', '2031-01-03');
  32  |   const draft = await post(context, '/drafts', { operation_id: (await post(context, '/draft-operations', {})).operation_id, expected_revision: 0, draft: content });
  33  |   const review = await post(context, '/workday-reviews', { draft_id: draft.id, expected_revision: 1 });
  34  |   const b = await post(context, '/drafts/' + draft.id + '/confirm', { operation_id: review.operation_id, expected_revision: 1, acknowledgements: review.unknowns.map((u: any) => u.id), classifications: {} });
  35  |   const commands: any[] = [];
  36  |   page.on('request', request => { if (request.method() === 'POST' && new URL(request.url()).pathname === '/notices') commands.push(request.postDataJSON()); });
  37  |   await open(page);
  38  |   for (const item of examples) {
  39  |     await fill(page, item);
  40  |     const response = page.waitForResponse(reply => reply.request().method() === 'POST' && new URL(reply.url()).pathname === '/notices' && reply.status() === 200);
  41  |     await page.getByRole('button', { name: 'Lagre avvik', exact: true }).click(); await response;
  42  |     await expect(feedback(page)).toHaveText('Avviket er lagret.');
  43  |     await expect(page.getByRole('button', { name: 'Registrer avvik', exact: true })).toBeEnabled();
  44  |   }
  45  |   const saved = (await (await context.request.get(API + '/notices')).json()).notices;
  46  |   for (const item of examples) {
  47  |     const row = saved.find((n: any) => n.title === item.title);
> 48  |     expect(row).toMatchObject({ ...item, valid_from: null, source_updated_at: null, checked_at: null, workday_id: null, revision: 1, valid_until: '2031-01-04T23:59:59+01:00' });
      |                 ^ Error: expect(received).toMatchObject(expected)
  49  |   }
  50  |   const receipts = await Promise.all(commands.map(async command => (await context.request.get(API + '/workday-notice-operations/' + command.operation_id)).json()));
  51  |   await page.getByRole('button', { name: 'Forberedelse og planlister', exact: true }).click();
  52  |   await page.getByRole('button', { name: 'Oppdater planlisten', exact: true }).click();
  53  |   await page.getByRole('button', { name: 'Åpne plan 2031-01-03 · versjon 1', exact: true }).click();
  54  |   await page.getByRole('button', { name: 'Les avvik for linjer og datoer', exact: true }).click();
  55  |   const reader = page.getByRole('region', { name: 'Avvik for linjer og datoer', exact: true });
  56  |   await expect(reader.locator('summary')).toHaveCount(2);
  57  |   for (const item of examples) await expect(reader).toContainText(item.title);
  58  |   await post(context, '/workdays/' + a.id + '/delete', { operation_id: randomUUID(), source_revision: 1 });
  59  |   expect((await (await context.request.get(API + '/notices')).json()).notices).toEqual(saved);
  60  |   // Controlled expiry changes only this synthetic parent; notices/receipts are independent.
  61  |   python(`with database() as conn:\n conn.execute("UPDATE workdays SET expires_at=clock_timestamp()-interval '1 second' WHERE id=%s", (${JSON.stringify(b.id)},))\n`);
  62  |   expect([404, 410]).toContain((await context.request.get(API + '/workdays/' + b.id)).status());
  63  |   expect((await (await context.request.get(API + '/notices')).json()).notices).toEqual(saved);
  64  |   for (let i = 0; i < commands.length; i++) expect(await (await context.request.get(API + '/workday-notice-operations/' + commands[i].operation_id)).json()).toEqual(receipts[i]);
  65  |   writeFileSync(testInfo.outputPath('a7-result.json'), JSON.stringify({ synthetic: true, examples, parentADeleted: a.id, parentBControlledExpiry: b.id, saved, receipts }, null, 2));
  66  | });
  67  | 
  68  | for (const concurrent of [false, true]) test(`D2 A8 accepted notice update retains identity through proxy and failed lookup concurrent=${concurrent}`, async ({ page, context }) => {
  69  |   await openedPlan(page, context);
  70  |   const item = examples[0];
  71  |   const initial = await post(context, '/notices', { operation_id: (await post(context, '/notice-operations', {})).operation_id, expected_revision: 0, content: { ...item, valid_until: '2031-01-04T23:59:59+01:00', source_updated_at: null, valid_from: null } });
  72  |   await open(page); await page.locator('.notice-list summary').click();
  73  |   await page.getByRole('button', { name: 'Rediger ' + item.title, exact: true }).click();
  74  |   await page.getByLabel('Tittel', { exact: true }).fill('Syntetisk endret etter faktisk lagring');
  75  |   const writes: any[] = [];
  76  |   await page.route('**:18330/notices/' + initial.result.id, async route => { if (route.request().method() !== 'POST') return route.continue(); writes.push(route.request().postDataJSON()); await route.fetch(); await route.fulfill({ status: 502, contentType: 'text/html', body: '<html>synthetic lost accepted update</html>' }); });
  77  |   await page.getByRole('button', { name: 'Lagre avvik', exact: true }).click();
  78  |   await expect(feedback(page)).toContainText('uavklart');
  79  |   await page.route('**:18330/workday-notice-operations/*', route => route.fulfill({ status: 503, json: { detail: 'Synthetic lookup unavailable' } }));
  80  |   const failedLookup = page.waitForResponse(reply => new URL(reply.url()).pathname.startsWith('/workday-notice-operations/') && reply.status() === 503);
  81  |   await page.getByRole('button', { name: 'Prøv samme avvikslagring igjen', exact: true }).click(); await failedLookup;
  82  |   await expect(page.getByRole('button', { name: 'Prøv samme avvikslagring igjen', exact: true })).toBeEnabled();
  83  |   await expect(feedback(page)).toContainText('uavklart'); expect(writes).toHaveLength(1);
  84  |   await expect(page.getByLabel('Tittel', { exact: true })).toHaveValue('Syntetisk endret etter faktisk lagring');
  85  |   const third = concurrent ? await post(context, '/notices/' + initial.result.id, { operation_id: randomUUID(), expected_revision: 2, content: { ...item, title: 'Nyere uavhengig endring i annet vindu', valid_until: '2031-01-04T23:59:59+01:00', source_updated_at: null, valid_from: null } }) : null;
  86  |   await page.unroute('**:18330/workday-notice-operations/*');
  87  |   await page.getByRole('button', { name: 'Kontroller avvikslagringen', exact: true }).click();
  88  |   if (concurrent) {
  89  |     await expect(feedback(page)).toContainText('Et nyere avvik finnes.');
  90  |     await expect(page.getByLabel('Tittel', { exact: true })).toHaveValue('Syntetisk endret etter faktisk lagring');
  91  |     await expect(page.getByText('Nyere lagret avvik', { exact: true })).toBeVisible();
  92  |   } else await expect(feedback(page)).toHaveText('Avviket er lagret.');
  93  |   expect(writes).toHaveLength(1);
  94  |   const current = await (await context.request.get(API + '/notices/' + initial.result.id)).json();
  95  |   expect(current.revision).toBe(concurrent ? 3 : 2); expect(current.title).toBe(concurrent ? 'Nyere uavhengig endring i annet vindu' : 'Syntetisk endret etter faktisk lagring');
  96  |   if (concurrent) expect(current).toEqual(third.result);
  97  |   const receipt = await (await context.request.get(API + '/workday-notice-operations/' + writes[0].operation_id)).json();
  98  |   expect(receipt.result.revision).toBe(2); expect(receipt.result.title).toBe('Syntetisk endret etter faktisk lagring');
  99  |   if (!concurrent) expect(receipt.result).toEqual(current);
  100 |   expect(receipt.operation_id).toBe(writes[0].operation_id);
  101 | });
  102 | 
  103 | for (const [code, detail] of [[409, 'Slettingsforsøket har annet innhold.'], [410, 'Slettingsforsøket er utløpt.']] as const) test(`D2 A8 accepted draft deletion lookup ${code} is not a mutation rejection`, async ({ page, context }) => {
  104 |   const { draft } = await openedPlan(page, context);
  105 |   await page.getByRole('button', { name: 'Lukk planen', exact: true }).click();
  106 |   await page.getByRole('button', { name: 'Oppdater listen', exact: true }).click();
  107 |   await page.getByRole('button', { name: 'Åpne 2031-01-02 · versjon 1', exact: true }).click(); await editor(page);
  108 |   const writes: any[] = [];
  109 |   await page.route('**:18330/drafts/' + draft.id + '/delete', async route => { writes.push(route.request().postDataJSON()); await route.fetch(); await route.abort(); });
  110 |   page.once('dialog', dialog => dialog.accept()); await page.getByRole('button', { name: 'Slett utkast', exact: true }).click();
  111 |   const status = page.getByRole('status', { name: 'Lagringsstatus', exact: true });
  112 |   await expect(status).toContainText('Sletting er ikke bekreftet.');
  113 |   await page.route('**:18330/draft-deletions/*', route => route.fulfill({ status: code, json: { detail } }));
  114 |   await page.getByRole('button', { name: 'Kontroller slettingen', exact: true }).click();
  115 |   await expect(status).toContainText('Sletting er ikke bekreftet.');
  116 |   await expect(page.getByRole('button', { name: 'Kontroller slettingen', exact: true })).toBeEnabled();
  117 |   await expect.poll(() => beforeUnload(page)).toBe(true); expect(writes).toHaveLength(1);
  118 |   await page.unroute('**:18330/draft-deletions/*');
  119 |   await page.getByRole('button', { name: 'Kontroller slettingen', exact: true }).click();
  120 |   await expect(status).toHaveText('Utkastet er slettet.'); expect(writes).toHaveLength(1);
  121 |   expect(await (await context.request.get(API + '/draft-deletions/' + writes[0].operation_id)).json()).toEqual({ deleted_id: draft.id });
  122 | });
  123 | 
```