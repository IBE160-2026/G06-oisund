import { expect, type Page, type TestInfo } from '@playwright/test';

// Measure rendered text nodes, including mixed labels, against their effective
// ancestor background. Never infer success from CSS token names alone.
export async function measure(page: Page, info: TestInfo, state: string) {
  const result = await page.evaluate(() => {
    const rgb = (s: string) => s.match(/[\d.]+/g)!.slice(0, 3).map(Number);
    const lum = (s: string) => rgb(s).map(n => { n /= 255; return n <= .04045 ? n / 12.92 : ((n + .055) / 1.055) ** 2.4; }).reduce((sum, n, i) => sum + n * [.2126, .7152, .0722][i], 0);
    const ratio = (a: string, b: string) => (Math.max(lum(a), lum(b)) + .05) / (Math.min(lum(a), lum(b)) + .05);
    const background = (e: Element | null): string => {
      if (!e) return 'rgb(255, 255, 255)';
      const c = getComputedStyle(e).backgroundColor;
      return c === 'rgba(0, 0, 0, 0)' ? background(e.parentElement) : c;
    };
    const visible = (e: Element) => e.checkVisibility({ contentVisibilityAuto: true }) && e.getClientRects().length > 0 && getComputedStyle(e).visibility !== 'hidden' && !e.closest('[hidden],dialog:not([open])');
    const text: { label: string; ratio: number; color: string; background: string }[] = [];
    const walker = document.createTreeWalker(document.querySelector('main')!, NodeFilter.SHOW_TEXT);
    let node: Node | null;
    while ((node = walker.nextNode())) {
      const e = node.parentElement!;
      if (!node.textContent?.trim() || !visible(e) || e.closest('script,style,option')) continue;
      const range = document.createRange(); range.selectNodeContents(node);
      if (!range.getClientRects().length) continue;
      text.push({ label: node.textContent.trim().slice(0, 100), ratio: ratio(getComputedStyle(e).color, background(e)), color: getComputedStyle(e).color, background: background(e) });
    }
    for (const e of Array.from(document.querySelectorAll('input,textarea,select')).filter(visible)) {
      if (e.matches('input[type=checkbox],input[type=radio]')) continue;
      const css = getComputedStyle(e);
      text.push({ label: 'control value: ' + (e.getAttribute('aria-label') || e.tagName), ratio: ratio(css.color, background(e)), color: css.color, background: background(e) });
      if (e.getAttribute('placeholder')) { const placeholder = getComputedStyle(e, '::placeholder'); text.push({ label: 'placeholder', ratio: ratio(placeholder.color, background(e)), color: placeholder.color, background: background(e) }); }
    }
    const nativeChoices = Array.from(document.querySelectorAll('input[type=checkbox],input[type=radio]')).filter(visible).map(e => ({ label: e.parentElement?.textContent, status: 'Native indicator pixels require manual screenshot/device inspection; computed color is insufficient.' }));
    const boundaries = Array.from(document.querySelectorAll('button,input,select,textarea,summary')).filter(visible).filter(e => !e.matches('input[type=checkbox],input[type=radio]')).map(e => {
      const css = getComputedStyle(e);
      const outside = background(e.parentElement);
      return { label: e.textContent?.trim().slice(0, 80) || e.getAttribute('aria-label') || e.tagName, ratio: Math.max(parseFloat(css.borderTopWidth) > 0 && css.borderTopStyle !== 'none' ? ratio(css.borderTopColor, outside) : 0, ratio(background(e), outside), e.matches('summary') ? ratio(css.color, outside) : 0), insideBorder: parseFloat(css.borderTopWidth) > 0 ? ratio(css.borderTopColor, background(e)) : null, outsideBorder: parseFloat(css.borderTopWidth) > 0 ? ratio(css.borderTopColor, outside) : null, height: e.getBoundingClientRect().height };
    });
    return { environment: { userAgent: navigator.userAgent, viewport: { width: innerWidth, height: innerHeight }, rootFontSize: getComputedStyle(document.documentElement).fontSize, themeClass: document.documentElement.className, theme: document.documentElement.dataset.theme }, text, boundaries, nativeChoices, overflow: document.documentElement.scrollWidth - innerWidth };
  });
  await info.attach(state, { body: JSON.stringify(result, null, 2), contentType: 'application/json' });
  const requestedScale = info.title.match(/(100|200)% text/)?.[1];
  if (requestedScale) expect(result.environment.rootFontSize, state + ' actual text scale').toBe(requestedScale === '200' ? '32px' : '16px');
  expect(result.text.length, state).toBeGreaterThan(5);
  expect(result.text.filter(v => v.ratio < 4.5), state + ' text').toEqual([]);
  expect(result.boundaries.filter(v => v.ratio < 3), state + ' boundaries').toEqual([]);
  expect(result.overflow, state + ' page overflow').toBeLessThanOrEqual(1);
}

export async function measureFocus(page: Page, info: TestInfo, state: string) {
  // Census actual Tab candidates in the modal or document. A native date/time
  // host can consume several Tab presses; count controls only when their host
  // is reached, then require a complete traversal cycle and every census item.
  const census = await page.evaluate(() => {
    document.querySelectorAll<HTMLElement>('[data-focus-census]').forEach(e => delete e.dataset.focusCensus);
    const scope = document.querySelector('dialog[open]') ?? document.querySelector('main')!;
    return Array.from(scope.querySelectorAll<HTMLElement>('button,input,textarea,select,a[href],summary,[tabindex]')).filter(e => e.tabIndex >= 0 && !e.matches(':disabled') && e.checkVisibility({ contentVisibilityAuto: true }) && e.getClientRects().length > 0 && !e.closest('[hidden],dialog:not([open])') && getComputedStyle(e).visibility !== 'hidden').map((e, index) => {
      const id = String(index); e.dataset.focusCensus = id;
      return { id, label: e.getAttribute('aria-label') || e.textContent?.slice(0, 80) || e.tagName };
    });
  });
  const results = [], seen = new Set<string>();
  let first: string | undefined, leftFirst = false, completedCycle = false;
  for (let i = 0; i < (census.length + 1) * 12 + 40; i++) {
    // Returning from browser chrome revalidates private access and briefly
    // disables controls. Wait for the censused ready state before the next Tab.
    await page.waitForFunction(ids => ids.every(id => { const e = document.querySelector(`[data-focus-census="${id}"]`); return !e || !e.getClientRects().length || !e.matches(':disabled'); }), census.map(control => control.id));
    await page.keyboard.press('Tab');
    // Native subfield focus and browser scrolling settle on the next paint.
    await page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
    const value = await page.evaluate(() => {
      const e = document.activeElement!;
      if (e === document.body) return null;
      const css = getComputedStyle(e), box = e.getBoundingClientRect();
      const rgb = (s: string) => s.match(/[\d.]+/g)!.slice(0, 3).map(Number);
      const lum = (s: string) => rgb(s).map(n => { n /= 255; return n <= .04045 ? n / 12.92 : ((n + .055) / 1.055) ** 2.4; }).reduce((sum, n, i) => sum + n * [.2126, .7152, .0722][i], 0);
      let parent = e.parentElement; let bg = 'rgb(255,255,255)';
      while (parent) { const c = getComputedStyle(parent).backgroundColor; if (c !== 'rgba(0, 0, 0, 0)') { bg = c; break; } parent = parent.parentElement; }
      const ratio = (Math.max(lum(css.outlineColor), lum(bg)) + .05) / (Math.min(lum(css.outlineColor), lum(bg)) + .05);
      const x = Math.max(0, Math.min(innerWidth - 1, box.left + box.width / 2)), y = Math.max(0, Math.min(innerHeight - 1, box.top + box.height / 2));
      const hit = document.elementFromPoint(x, y);
      const exposed = Math.max(0, Math.min(box.right, innerWidth) - Math.max(box.left, 0)) * (Number(box.top >= 0 && box.top <= innerHeight) + Number(box.bottom >= 0 && box.bottom <= innerHeight)) + Math.max(0, Math.min(box.bottom, innerHeight) - Math.max(box.top, 0)) * (Number(box.left >= 0 && box.left <= innerWidth) + Number(box.right >= 0 && box.right <= innerWidth));
      const visibleOutlineArea = exposed * parseFloat(css.outlineWidth);
      return { censusId: (e as HTMLElement).dataset.focusCensus, rect: { top: box.top, bottom: box.bottom, left: box.left, right: box.right }, visibleOutlineArea, requiredOutlineArea: 2 * (2 * (box.width + box.height)), label: e.textContent?.slice(0, 70) || e.tagName, ratio, width: parseFloat(css.outlineWidth), visible: css.outlineStyle !== 'none' && (e.matches(':focus-visible') || e.matches(':focus-within')), inModal: !document.querySelector('dialog[open]') || !!e.closest('dialog[open]'), onscreen: box.bottom > 0 && box.top < innerHeight && box.right > 0 && box.left < innerWidth && !!hit && (e.contains(hit) || hit.contains(e)) };
    });
    if (value) {
      results.push(value);
      if (value.censusId !== undefined) {
        if (first === undefined) first = value.censusId;
        else if (value.censusId !== first) leftFirst = true;
        else if (leftFirst || census.length === 1 && results.length > 1) { completedCycle = true; break; }
        seen.add(value.censusId);
      }
    }
  }
  const missing = census.filter(control => !seen.has(control.id));
  await info.attach(state + '-focus', { body: JSON.stringify({ census, visited: [...seen], missing, completedCycle, results }, null, 2), contentType: 'application/json' });
  expect(completedCycle, state + ' bounded keyboard traversal completed a cycle').toBe(true);
  expect(missing, state + ' all reachable controls visited').toEqual([]);
  expect(results.filter(v => !v.visible || v.width < 2 || v.ratio < 3 || !v.inModal || !v.onscreen || v.visibleOutlineArea < v.requiredOutlineArea), state).toEqual([]);
}
