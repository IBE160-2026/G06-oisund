from pathlib import Path
import importlib.util,sys,shutil
root=Path.cwd()
spec=importlib.util.spec_from_file_location("story123_aux",root/"scripts/verify-story123.py")
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
mode=sys.argv[1];r.MODE=mode
image="ibe160-story123-gateway:main-sync-74849ff"
pyimage="ibe160-tablet-access-gate-tests:11-6"
pwsh=shutil.which("pwsh") or shutil.which("powershell")
commands={
"gateway-build":["docker","build","--progress=plain","-t",image,"-f","deploy/tablet/Dockerfile","."],
"gate-check":["docker","run","--rm","--network","none","--read-only","--tmpfs","/tmp","-e","PYTHONDONTWRITEBYTECODE=1","--mount",f"type=bind,source={root}/deploy/tablet/access_gate,target=/app,readonly","--entrypoint","python",pyimage,"-m","pytest","-p","no:cacheprovider","-q","test_gate.py"],
"gateway-config":[pwsh,"-NoProfile","-File","scripts/test-tablet-config.ps1","-EnvironmentFile","deploy/tablet/.env.tablet.example"],
"gateway-proxy":[pwsh,"-NoProfile","-File","scripts/verify-tablet-proxy.ps1","-PythonImage",pyimage,"-GatewayImage",image],
}
inputs=[Path(__file__),root/".dockerignore",root/"compose.tablet.yaml",*(root/"deploy/tablet").rglob("*"),root/"scripts/test-tablet-config.ps1",root/"scripts/verify-tablet-proxy.ps1",root/"scripts/tablet-proxy-probe.py"]
r.execute(commands[mode],inputs=inputs,timeout=600)
