import os,subprocess,sys,time
from pathlib import Path
child=subprocess.Popen([sys.executable,'-c','import time; time.sleep(90)'])
Path('D:\\IBE160\\tmp\\story-12-3\\tmp\\story123\\20261027T094501317932Z-99a785b8-parent-exit-input\\child.pid').write_text(str(child.pid))
Path('D:\\IBE160\\tmp\\story-12-3\\tmp\\story123\\20261027T094501317932Z-99a785b8-parent-exit-input\\parent.pid').write_text(str(os.getpid()))
print('Owned child alive; parent waits for cleanup signal',flush=True)
while not Path('D:\\IBE160\\tmp\\story-12-3\\tmp\\story123\\20261027T094501317932Z-99a785b8-parent-exit-input\\parent-exit.signal').exists(): time.sleep(.01)
print('Parent exits during cleanup',flush=True)
