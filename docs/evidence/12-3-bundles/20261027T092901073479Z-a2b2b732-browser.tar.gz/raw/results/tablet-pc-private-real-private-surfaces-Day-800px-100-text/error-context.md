# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tablet-pc-private.spec.ts >> real private surfaces Day 800px 100% text
- Location: .story123-tests\tablet-pc-private.spec.ts:6:101

# Error details

```
Error: draft-editor actual same-pixel focus change

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 9

- Array []
+ Array [
+   Object {
+     "cacheHit": false,
+     "changedArea": 1059,
+     "coverage": "actual same-pixel focused/unfocused perimeter change at >=3:1",
+     "representative": "draft-editor-122",
+     "requiredArea": 1095.25,
+   },
+ ]
```

# Test source

```ts
  38  |       if (e.closest('input,textarea,select')) return; // Native field content intentionally scrolls.
  39  |       for (let p: Element | null = includeSelf ? e : e.parentElement; p && p !== document.documentElement; p = p.parentElement) {
  40  |         const css = getComputedStyle(p), box = p.getBoundingClientRect();
  41  |         const intentionalDialogScroll = p === modal && ['auto', 'scroll'].includes(css.overflowY);
  42  |         for (const axis of ['x', 'y']) {
  43  |           const overflow = axis === 'x' ? css.overflowX : css.overflowY;
  44  |           if (!['hidden', 'clip', 'auto', 'scroll'].includes(overflow) || intentionalDialogScroll && axis === 'y') continue;
  45  |           const start = axis === 'x' ? box.left + (p as HTMLElement).clientLeft : box.top + (p as HTMLElement).clientTop;
  46  |           const end = start + (axis === 'x' ? (p as HTMLElement).clientWidth : (p as HTMLElement).clientHeight);
  47  |           if (rects.some(r => (axis === 'x' ? r.left : r.top) < start - 1 || (axis === 'x' ? r.right : r.bottom) > end + 1)) clipping.push({ label, ancestor: p.tagName + '.' + p.className, axis });
  48  |         }
  49  |       }
  50  |       if (getComputedStyle(e).textOverflow === 'ellipsis' && e.scrollWidth > e.clientWidth + 1) clipping.push({ label, ancestor: e.tagName, axis: 'ellipsis' });
  51  |     };
  52  |     const addText = (e: Element, colorValue: string, label: string) => { const bg = background(e, label), color = parse(colorValue); if (bg && color) text.push({ label, ratio: ratio(over(color, bg), bg), color: over(color, bg), background: bg }); else if (!color) unmeasured.push({ label, reason: 'unsupported foreground ' + colorValue }); };
  53  |     const walker = document.createTreeWalker(scope, NodeFilter.SHOW_TEXT); let node: Node | null;
  54  |     while ((node = walker.nextNode())) {
  55  |       const e = node.parentElement!, label = node.textContent?.trim().slice(0, 100);
  56  |       if (!label || !visible(e) || e.closest('script,style,option,textarea')) continue;
  57  |       const range = document.createRange(); range.selectNodeContents(node); const rects = Array.from(range.getClientRects());
  58  |       if (!rects.length) continue;
  59  |       addText(e, getComputedStyle(e).color, label); inspectClip(e, rects, label);
  60  |     }
  61  |     for (const e of Array.from(scope.querySelectorAll('input,textarea,select')).filter(visible)) {
  62  |       if (e.matches('input[type=checkbox],input[type=radio]')) continue;
  63  |       addText(e, getComputedStyle(e).color, 'control value: ' + (e.getAttribute('aria-label') || e.tagName));
  64  |       if (e.getAttribute('placeholder')) addText(e, getComputedStyle(e, '::placeholder').color, 'placeholder');
  65  |     }
  66  |     const boundaries = Array.from(scope.querySelectorAll('button,input,select,textarea,summary')).filter(visible).filter(e => !e.matches('input[type=checkbox],input[type=radio]')).flatMap(e => {
  67  |       const label = e.textContent?.trim().slice(0, 80) || e.getAttribute('aria-label') || e.tagName;
  68  |       inspectClip(e, [e.getBoundingClientRect()], label, false);
  69  |       const css = getComputedStyle(e), outside = background(e.parentElement, label), inside = background(e, label), border = parse(css.borderTopColor), color = parse(css.color);
  70  |       if (!outside || !inside || !border || !color) return [];
  71  |       return [{ label, ratio: Math.max(parseFloat(css.borderTopWidth) > 0 && css.borderTopStyle !== 'none' ? ratio(over(border, outside), outside) : 0, ratio(inside, outside), e.matches('summary') ? ratio(over(color, outside), outside) : 0), height: e.getBoundingClientRect().height }];
  72  |     });
  73  |     return { environment: { userAgent: navigator.userAgent, viewport: { width: innerWidth, height: innerHeight }, rootFontSize: getComputedStyle(document.documentElement).fontSize, themeClass: document.documentElement.className, theme: document.documentElement.dataset.theme, scope: modal ? 'active native modal only; underlying backdrop/page excluded' : 'main' }, text, boundaries, clipping, unmeasured, overflow: document.documentElement.scrollWidth - innerWidth };
  74  |   });
  75  |   await info.attach(state, { body: JSON.stringify(result, null, 2), contentType: 'application/json' });
  76  |   const requestedScale = info.title.match(/(100|200)% text/)?.[1];
  77  |   if (requestedScale) expect(result.environment.rootFontSize, state + ' actual text scale').toBe(requestedScale === '200' ? '32px' : '16px');
  78  |   if (!allowUnmeasured) expect(result.unmeasured, state + ' unsupported layers explicitly unmeasured').toEqual([]);
  79  |   if (!result.unmeasured.length) expect(result.text.length, state).toBeGreaterThan(0);
  80  |   expect(result.text.filter(v => v.ratio < 4.5), state + ' measured text').toEqual([]);
  81  |   expect(result.boundaries.filter(v => v.ratio < 3), state + ' measured boundaries').toEqual([]);
  82  |   expect(result.clipping, state + ' critical content clipping').toEqual([]);
  83  |   expect(result.overflow, state + ' page overflow').toBeLessThanOrEqual(1);
  84  |   return result; // Unsupported layers are explicitly unmeasured, never a pass.
  85  | }
  86  | 
  87  | export async function measureFocus(page: Page, info: TestInfo, state: string) {
  88  |   // Census actual Tab candidates in the modal or document. A native date/time
  89  |   // host can consume several Tab presses; count controls only when their host
  90  |   // is reached, then require a complete traversal cycle and every census item.
  91  |   const census = await page.evaluate(() => {
  92  |     document.querySelectorAll<HTMLElement>('[data-focus-census]').forEach(e => delete e.dataset.focusCensus);
  93  |     const scope = document.querySelector('dialog[open]') ?? document.querySelector('main')!;
  94  |     return Array.from(scope.querySelectorAll<HTMLElement>('button,input,textarea,select,a[href],summary,[tabindex]')).filter(e => e.tabIndex >= 0 && !e.matches(':disabled') && e.checkVisibility({ contentVisibilityAuto: true }) && e.getClientRects().length > 0 && !e.closest('[hidden],dialog:not([open])') && getComputedStyle(e).visibility !== 'hidden').map((e, index) => {
  95  |       const id = String(index); e.dataset.focusCensus = id;
  96  |       return { id, label: e.getAttribute('aria-label') || e.textContent?.slice(0, 80) || e.tagName };
  97  |     });
  98  |   });
  99  |   const results = [], seen = new Set<string>(), pixelSeen = new Set<string>(), pixelResults = [];
  100 |   let first: string | undefined, leftFirst = false, completedCycle = false;
  101 |   for (let i = 0; i < (census.length + 1) * 12 + 40; i++) {
  102 |     // Returning from browser chrome revalidates private access and briefly
  103 |     // disables controls. Wait for the censused ready state before the next Tab.
  104 |     await page.waitForFunction(ids => ids.every(id => { const e = document.querySelector(`[data-focus-census="${id}"]`); return !e || !e.getClientRects().length || !e.matches(':disabled'); }), census.map(control => control.id));
  105 |     await page.keyboard.press('Tab');
  106 |     // Native subfield focus and browser scrolling settle on the next paint.
  107 |     await page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  108 |     const value = await page.evaluate(() => {
  109 |       const e = document.activeElement!;
  110 |       if (e === document.body) return null;
  111 |       const css = getComputedStyle(e), box = e.getBoundingClientRect();
  112 |       const rgb = (s: string) => s.match(/[\d.]+/g)!.slice(0, 3).map(Number);
  113 |       const lum = (s: string) => rgb(s).map(n => { n /= 255; return n <= .04045 ? n / 12.92 : ((n + .055) / 1.055) ** 2.4; }).reduce((sum, n, i) => sum + n * [.2126, .7152, .0722][i], 0);
  114 |       let parent = e.parentElement; let bg = 'rgb(255,255,255)';
  115 |       while (parent) { const c = getComputedStyle(parent).backgroundColor; if (c !== 'rgba(0, 0, 0, 0)') { bg = c; break; } parent = parent.parentElement; }
  116 |       const ratio = (Math.max(lum(css.outlineColor), lum(bg)) + .05) / (Math.min(lum(css.outlineColor), lum(bg)) + .05);
  117 |       const x = Math.max(0, Math.min(innerWidth - 1, box.left + box.width / 2)), y = Math.max(0, Math.min(innerHeight - 1, box.top + box.height / 2));
  118 |       const hit = document.elementFromPoint(x, y);
  119 |       const exposed = Math.max(0, Math.min(box.right, innerWidth) - Math.max(box.left, 0)) * (Number(box.top >= 0 && box.top <= innerHeight) + Number(box.bottom >= 0 && box.bottom <= innerHeight)) + Math.max(0, Math.min(box.bottom, innerHeight) - Math.max(box.top, 0)) * (Number(box.left >= 0 && box.left <= innerWidth) + Number(box.right >= 0 && box.right <= innerWidth));
  120 |       const visibleOutlineArea = exposed * parseFloat(css.outlineWidth);
  121 |       return { censusId: (e as HTMLElement).dataset.focusCensus, rect: { top: box.top, bottom: box.bottom, left: box.left, right: box.right }, visibleOutlineArea, requiredOutlineArea: 2 * (2 * (box.width + box.height)), label: e.textContent?.slice(0, 70) || e.tagName, ratio, width: parseFloat(css.outlineWidth), visible: css.outlineStyle !== 'none' && (e.matches(':focus-visible') || e.matches(':focus-within')), inModal: !document.querySelector('dialog[open]') || !!e.closest('dialog[open]'), onscreen: box.bottom > 0 && box.top < innerHeight && box.right > 0 && box.left < innerWidth && !!hit && (e.contains(hit) || hit.contains(e)) };
  122 |     });
  123 |     if (value) {
  124 |       results.push(value);
  125 |       if (value.censusId !== undefined && !pixelSeen.has(value.censusId)) {
  126 |         pixelResults.push(await focusPixelChange(page, info, state, value.censusId)); pixelSeen.add(value.censusId);
  127 |       }
  128 |       if (value.censusId !== undefined) {
  129 |         if (first === undefined) first = value.censusId;
  130 |         else if (value.censusId !== first) leftFirst = true;
  131 |         else if (leftFirst || census.length === 1 && results.length > 1) { completedCycle = true; break; }
  132 |         seen.add(value.censusId);
  133 |       }
  134 |     }
  135 |   }
  136 |   const missing = census.filter(control => !seen.has(control.id));
  137 |   await info.attach(state + '-focus', { body: JSON.stringify({ pixelResults, census, visited: [...seen], missing, completedCycle, results }, null, 2), contentType: 'application/json' });
> 138 |   expect(pixelResults.filter(result => result.changedArea < result.requiredArea), state + ' actual same-pixel focus change').toEqual([]);
      |                                                                                                                              ^ Error: draft-editor actual same-pixel focus change
  139 |   expect(completedCycle, state + ' bounded keyboard traversal completed a cycle').toBe(true);
  140 |   expect(missing, state + ' all reachable controls visited').toEqual([]);
  141 |   expect(results.filter(v => !v.visible || v.width < 2 || v.ratio < 3 || !v.inModal || !v.onscreen || v.visibleOutlineArea < v.requiredOutlineArea), state).toEqual([]);
  142 | }
  143 | 
```