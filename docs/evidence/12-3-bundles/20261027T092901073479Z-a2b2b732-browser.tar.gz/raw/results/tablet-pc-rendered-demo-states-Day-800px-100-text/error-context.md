# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tablet-pc.spec.ts >> rendered demo states Day 800px 100% text
- Location: .story123-tests\tablet-pc.spec.ts:37:101

# Error details

```
Error: conflict unsupported layers explicitly unmeasured

expect(received).toEqual(expected) // deep equality

- Expected  -  1
+ Received  + 10

- Array []
+ Array [
+   Object {
+     "label": "control value: Utfall",
+     "reason": "unsupported opacity/filter/blending/image background: SELECT",
+   },
+   Object {
+     "label": "VanligUtilgjengeligNyere revisjon / konfliktMistet svar etter lagring",
+     "reason": "unsupported opacity/filter/blending/image background: SELECT",
+   },
+ ]
```

# Page snapshot

```yaml
- main [ref=e3]:
  - generic [ref=e4]:
    - button "Bytt til nattvisning" [ref=e5] [cursor=pointer]
    - generic [ref=e6]: "Visning: Dag"
  - paragraph [ref=e7]: SIMULERING · bare fiktive data
  - heading "Prøv en fiktiv arbeidsdag" [level=1] [ref=e8]
  - paragraph [ref=e9]: Ingen innlogging, GPS eller kildehenting. Bare dag-/nattvalget lagres i nettleseren. Simulerte data forsvinner ved omlasting. Bruk mens du står stille.
  - paragraph [ref=e10]: Dette viser bare simulerte kvitteringer. Ingen data lagres i en virkelig database.
  - status [ref=e11]: Konflikt. Forslaget er ikke lagret. Sammenlign med gjeldende revisjon.
  - navigation "Demoskjermer" [ref=e12]:
    - button "Import" [disabled] [ref=e13]
    - button "Utkast" [disabled] [ref=e14]
    - button "Arbeidsdag" [disabled] [ref=e15]
    - button "Kontomeldinger" [disabled] [ref=e16]
  - group [ref=e17]:
    - generic "Simuler feil ved neste lagring" [ref=e18]
    - generic [ref=e19]:
      - text: Utfall
      - combobox "Utfall" [disabled] [ref=e20]:
        - option "Vanlig" [selected]
        - option "Utilgjengelig"
        - option "Nyere revisjon / konflikt"
        - option "Mistet svar etter lagring"
  - region "Konflikt" [ref=e21]:
    - heading "Gjeldende versus foreslått" [level=2] [ref=e22]
    - heading "Gjeldende revisjon 1" [level=3] [ref=e23]
    - generic [ref=e24]: "{ \"duty\": \"F-99\", \"bus\": \"\", \"source\": \"Simulert delvis tekst-PDF, side 1: vognløp og planlagte tider tolket. Side 2: fysisk buss og sted for pause kunne ikke tolkes. Kildens oppdateringstid er ukjent.\" }"
    - heading "Ditt ulagrede forslag" [level=3] [ref=e25]
    - generic [ref=e26]: "{ \"duty\": \"Et svært langt norsk vognløpsnavn med æ ø å og mange ord Et svært langt norsk vognløpsnavn med æ ø å og mange ord Et svært langt norsk vognløpsnavn med æ ø å og mange ord Et svært langt norsk vognløpsnavn med æ ø å og mange ord Et svært langt norsk vognløpsnavn med æ ø å og mange ord Et svært langt norsk vognløpsnavn med æ ø å og mange ord Et svært langt norsk vognløpsnavn med æ ø å og mange ord Et svært langt norsk vognløpsnavn med æ ø å og mange ord \", \"bus\": \"\", \"source\": \"Simulert delvis tekst-PDF, side 1: vognløp og planlagte tider tolket. Side 2: fysisk buss og sted for pause kunne ikke tolkes. Kildens oppdateringstid er ukjent.\" }"
    - button "Ta i bruk gjeldende" [ref=e27] [cursor=pointer]
    - button "Avbryt konflikt" [ref=e28] [cursor=pointer]
  - generic [ref=e29]:
    - heading "2. Rediger forslag" [level=2] [ref=e30]
    - paragraph [ref=e31]: Vognløp og buss kan redigeres for et fast fiktivt aktivitetseksempel. Aktivitetene kan ikke opprettes eller endres her. Endringer her er et ulagret forslag. Kvittering gjelder bare siste bekreftede øyeblikksbilde.
    - generic [ref=e32]:
      - text: Vognløp
      - textbox "Vognløp" [disabled] [ref=e33]: Et svært langt norsk vognløpsnavn med æ ø å og mange ord Et svært langt norsk vognløpsnavn med æ ø å og mange ord Et svært langt norsk vognløpsnavn med æ ø å og mange ord Et svært langt norsk vognløpsnavn med æ ø å og mange ord Et svært langt norsk vognløpsnavn med æ ø å og mange ord Et svært langt norsk vognløpsnavn med æ ø å og mange ord Et svært langt norsk vognløpsnavn med æ ø å og mange ord Et svært langt norsk vognløpsnavn med æ ø å og mange ord
    - generic [ref=e34]:
      - text: Fysisk buss (tom = ukjent)
      - textbox "Fysisk buss (tom = ukjent)" [disabled] [ref=e35]
    - paragraph [ref=e36]: "Kilde: Simulert delvis tekst-PDF, side 1: vognløp og planlagte tider tolket. Side 2: fysisk buss og sted for pause kunne ikke tolkes. Kildens oppdateringstid er ukjent."
    - paragraph [ref=e37]: Tjenestedato 26.10.2026 · Europe/Oslo. Planlagt arbeid krysser midnatt.
    - button "Lagre forslag i simuleringen" [disabled] [ref=e38]
    - button "Åpne lagret øyeblikksbilde" [disabled] [ref=e39]
    - button "Se lagret dag før start" [disabled] [ref=e40]
  - separator [ref=e41]
  - button "Nullstill simuleringen" [ref=e42] [cursor=pointer]
  - paragraph [ref=e43]: Den separate vurderingen med faktisk API/PostgreSQL startes med den isolerte testoppskriften i dokumentasjonen.
```

# Test source

```ts
  1   | import { expect, type Page, type TestInfo } from '@playwright/test';
  2   | import { focusPixelChange } from './tablet-pc-focus-pixels';
  3   | 
  4   | export async function measure(page: Page, info: TestInfo, state: string, allowUnmeasured = false) {
  5   |   const result = await page.evaluate(() => {
  6   |     type Color = [number, number, number, number];
  7   |     const unmeasured: { label: string; reason: string }[] = [];
  8   |     const parse = (s: string): Color | null => {
  9   |       const values = s.match(/^rgba?\(([^)]+)\)$/)?.[1].split(/[, /]+/).filter(Boolean).map(Number);
  10  |       return values && values.length >= 3 && values.every(Number.isFinite) ? [values[0], values[1], values[2], values[3] ?? 1] : null;
  11  |     };
  12  |     const over = (top: Color, bottom: Color): Color => { const a = top[3] + bottom[3] * (1 - top[3]); return [0, 1, 2].map(i => (top[i] * top[3] + bottom[i] * bottom[3] * (1 - top[3])) / (a || 1)).concat(a) as Color; };
  13  |     const lum = (c: Color) => c.slice(0, 3).map(v => { v /= 255; return v <= .04045 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4; }).reduce((sum, v, i) => sum + v * [.2126, .7152, .0722][i], 0);
  14  |     const ratio = (a: Color, b: Color) => (Math.max(lum(a), lum(b)) + .05) / (Math.min(lum(a), lum(b)) + .05);
  15  |     const modal = document.querySelector('dialog[open]');
  16  |     const scope = modal ?? document.querySelector('main')!;
  17  |     const visible = (e: Element) => e.checkVisibility({ contentVisibilityAuto: true }) && e.getClientRects().length > 0 && getComputedStyle(e).visibility !== 'hidden' && !e.closest('[hidden],dialog:not([open])');
  18  |     const background = (e: Element | null, label: string): Color | null => {
  19  |       const layers: Color[] = []; let opaque = false;
  20  |       for (let p = e; p; p = p.parentElement) {
  21  |         const css = getComputedStyle(p);
  22  |         if (Number(css.opacity) !== 1 || css.filter !== 'none' || css.mixBlendMode !== 'normal' || css.backgroundImage !== 'none' || css.backdropFilter !== 'none') { unmeasured.push({ label, reason: 'unsupported opacity/filter/blending/image background: ' + p.tagName }); return null; }
  23  |         const color = parse(css.backgroundColor);
  24  |         if (!color) { unmeasured.push({ label, reason: 'unsupported background color ' + css.backgroundColor }); return null; }
  25  |         layers.push(color);
  26  |         if (color[3] === 1) { opaque = true; break; }
  27  |         if (p === modal) { unmeasured.push({ label, reason: 'translucent modal over spatially varying page/backdrop is not inferred from CSS' }); return null; }
  28  |       }
  29  |       // Ancestor group opacity affects even an opaque child, so inspect it too.
  30  |       for (let p = e; p; p = p.parentElement) { const css = getComputedStyle(p); if (Number(css.opacity) !== 1 || css.filter !== 'none' || css.mixBlendMode !== 'normal') { unmeasured.push({ label, reason: 'unsupported ancestor group opacity/filter/blending' }); return null; } }
  31  |       let value: Color = [255, 255, 255, 1];
  32  |       for (const layer of layers.reverse()) value = over(layer, value);
  33  |       return opaque || !modal ? value : null;
  34  |     };
  35  |     const text: { label: string; ratio: number; color: Color; background: Color }[] = [];
  36  |     const clipping: { label: string; ancestor: string; axis: string }[] = [];
  37  |     const inspectClip = (e: Element, rects: DOMRect[], label: string, includeSelf = true) => {
  38  |       if (e.closest('input,textarea,select')) return; // Native field content intentionally scrolls.
  39  |       for (let p: Element | null = includeSelf ? e : e.parentElement; p && p !== document.documentElement; p = p.parentElement) {
  40  |         const css = getComputedStyle(p), box = p.getBoundingClientRect();
  41  |         const intentionalDialogScroll = p === modal && ['auto', 'scroll'].includes(css.overflowY);
  42  |         for (const axis of ['x', 'y']) {
  43  |           const overflow = axis === 'x' ? css.overflowX : css.overflowY;
  44  |           if (!['hidden', 'clip', 'auto', 'scroll'].includes(overflow) || intentionalDialogScroll && axis === 'y') continue;
  45  |           const start = axis === 'x' ? box.left + (p as HTMLElement).clientLeft : box.top + (p as HTMLElement).clientTop;
  46  |           const end = start + (axis === 'x' ? (p as HTMLElement).clientWidth : (p as HTMLElement).clientHeight);
  47  |           if (rects.some(r => (axis === 'x' ? r.left : r.top) < start - 1 || (axis === 'x' ? r.right : r.bottom) > end + 1)) clipping.push({ label, ancestor: p.tagName + '.' + p.className, axis });
  48  |         }
  49  |       }
  50  |       if (getComputedStyle(e).textOverflow === 'ellipsis' && e.scrollWidth > e.clientWidth + 1) clipping.push({ label, ancestor: e.tagName, axis: 'ellipsis' });
  51  |     };
  52  |     const addText = (e: Element, colorValue: string, label: string) => { const bg = background(e, label), color = parse(colorValue); if (bg && color) text.push({ label, ratio: ratio(over(color, bg), bg), color: over(color, bg), background: bg }); else if (!color) unmeasured.push({ label, reason: 'unsupported foreground ' + colorValue }); };
  53  |     const walker = document.createTreeWalker(scope, NodeFilter.SHOW_TEXT); let node: Node | null;
  54  |     while ((node = walker.nextNode())) {
  55  |       const e = node.parentElement!, label = node.textContent?.trim().slice(0, 100);
  56  |       if (!label || !visible(e) || e.closest('script,style,option,textarea')) continue;
  57  |       const range = document.createRange(); range.selectNodeContents(node); const rects = Array.from(range.getClientRects());
  58  |       if (!rects.length) continue;
  59  |       addText(e, getComputedStyle(e).color, label); inspectClip(e, rects, label);
  60  |     }
  61  |     for (const e of Array.from(scope.querySelectorAll('input,textarea,select')).filter(visible)) {
  62  |       if (e.matches('input[type=checkbox],input[type=radio]')) continue;
  63  |       addText(e, getComputedStyle(e).color, 'control value: ' + (e.getAttribute('aria-label') || e.tagName));
  64  |       if (e.getAttribute('placeholder')) addText(e, getComputedStyle(e, '::placeholder').color, 'placeholder');
  65  |     }
  66  |     const boundaries = Array.from(scope.querySelectorAll('button,input,select,textarea,summary')).filter(visible).filter(e => !e.matches('input[type=checkbox],input[type=radio]')).flatMap(e => {
  67  |       const label = e.textContent?.trim().slice(0, 80) || e.getAttribute('aria-label') || e.tagName;
  68  |       inspectClip(e, [e.getBoundingClientRect()], label, false);
  69  |       const css = getComputedStyle(e), outside = background(e.parentElement, label), inside = background(e, label), border = parse(css.borderTopColor), color = parse(css.color);
  70  |       if (!outside || !inside || !border || !color) return [];
  71  |       return [{ label, ratio: Math.max(parseFloat(css.borderTopWidth) > 0 && css.borderTopStyle !== 'none' ? ratio(over(border, outside), outside) : 0, ratio(inside, outside), e.matches('summary') ? ratio(over(color, outside), outside) : 0), height: e.getBoundingClientRect().height }];
  72  |     });
  73  |     return { environment: { userAgent: navigator.userAgent, viewport: { width: innerWidth, height: innerHeight }, rootFontSize: getComputedStyle(document.documentElement).fontSize, themeClass: document.documentElement.className, theme: document.documentElement.dataset.theme, scope: modal ? 'active native modal only; underlying backdrop/page excluded' : 'main' }, text, boundaries, clipping, unmeasured, overflow: document.documentElement.scrollWidth - innerWidth };
  74  |   });
  75  |   await info.attach(state, { body: JSON.stringify(result, null, 2), contentType: 'application/json' });
  76  |   const requestedScale = info.title.match(/(100|200)% text/)?.[1];
  77  |   if (requestedScale) expect(result.environment.rootFontSize, state + ' actual text scale').toBe(requestedScale === '200' ? '32px' : '16px');
> 78  |   if (!allowUnmeasured) expect(result.unmeasured, state + ' unsupported layers explicitly unmeasured').toEqual([]);
      |                                                                                                        ^ Error: conflict unsupported layers explicitly unmeasured
  79  |   if (!result.unmeasured.length) expect(result.text.length, state).toBeGreaterThan(0);
  80  |   expect(result.text.filter(v => v.ratio < 4.5), state + ' measured text').toEqual([]);
  81  |   expect(result.boundaries.filter(v => v.ratio < 3), state + ' measured boundaries').toEqual([]);
  82  |   expect(result.clipping, state + ' critical content clipping').toEqual([]);
  83  |   expect(result.overflow, state + ' page overflow').toBeLessThanOrEqual(1);
  84  |   return result; // Unsupported layers are explicitly unmeasured, never a pass.
  85  | }
  86  | 
  87  | export async function measureFocus(page: Page, info: TestInfo, state: string) {
  88  |   // Census actual Tab candidates in the modal or document. A native date/time
  89  |   // host can consume several Tab presses; count controls only when their host
  90  |   // is reached, then require a complete traversal cycle and every census item.
  91  |   const census = await page.evaluate(() => {
  92  |     document.querySelectorAll<HTMLElement>('[data-focus-census]').forEach(e => delete e.dataset.focusCensus);
  93  |     const scope = document.querySelector('dialog[open]') ?? document.querySelector('main')!;
  94  |     return Array.from(scope.querySelectorAll<HTMLElement>('button,input,textarea,select,a[href],summary,[tabindex]')).filter(e => e.tabIndex >= 0 && !e.matches(':disabled') && e.checkVisibility({ contentVisibilityAuto: true }) && e.getClientRects().length > 0 && !e.closest('[hidden],dialog:not([open])') && getComputedStyle(e).visibility !== 'hidden').map((e, index) => {
  95  |       const id = String(index); e.dataset.focusCensus = id;
  96  |       return { id, label: e.getAttribute('aria-label') || e.textContent?.slice(0, 80) || e.tagName };
  97  |     });
  98  |   });
  99  |   const results = [], seen = new Set<string>(), pixelSeen = new Set<string>(), pixelResults = [];
  100 |   let first: string | undefined, leftFirst = false, completedCycle = false;
  101 |   for (let i = 0; i < (census.length + 1) * 12 + 40; i++) {
  102 |     // Returning from browser chrome revalidates private access and briefly
  103 |     // disables controls. Wait for the censused ready state before the next Tab.
  104 |     await page.waitForFunction(ids => ids.every(id => { const e = document.querySelector(`[data-focus-census="${id}"]`); return !e || !e.getClientRects().length || !e.matches(':disabled'); }), census.map(control => control.id));
  105 |     await page.keyboard.press('Tab');
  106 |     // Native subfield focus and browser scrolling settle on the next paint.
  107 |     await page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  108 |     const value = await page.evaluate(() => {
  109 |       const e = document.activeElement!;
  110 |       if (e === document.body) return null;
  111 |       const css = getComputedStyle(e), box = e.getBoundingClientRect();
  112 |       const rgb = (s: string) => s.match(/[\d.]+/g)!.slice(0, 3).map(Number);
  113 |       const lum = (s: string) => rgb(s).map(n => { n /= 255; return n <= .04045 ? n / 12.92 : ((n + .055) / 1.055) ** 2.4; }).reduce((sum, n, i) => sum + n * [.2126, .7152, .0722][i], 0);
  114 |       let parent = e.parentElement; let bg = 'rgb(255,255,255)';
  115 |       while (parent) { const c = getComputedStyle(parent).backgroundColor; if (c !== 'rgba(0, 0, 0, 0)') { bg = c; break; } parent = parent.parentElement; }
  116 |       const ratio = (Math.max(lum(css.outlineColor), lum(bg)) + .05) / (Math.min(lum(css.outlineColor), lum(bg)) + .05);
  117 |       const x = Math.max(0, Math.min(innerWidth - 1, box.left + box.width / 2)), y = Math.max(0, Math.min(innerHeight - 1, box.top + box.height / 2));
  118 |       const hit = document.elementFromPoint(x, y);
  119 |       const exposed = Math.max(0, Math.min(box.right, innerWidth) - Math.max(box.left, 0)) * (Number(box.top >= 0 && box.top <= innerHeight) + Number(box.bottom >= 0 && box.bottom <= innerHeight)) + Math.max(0, Math.min(box.bottom, innerHeight) - Math.max(box.top, 0)) * (Number(box.left >= 0 && box.left <= innerWidth) + Number(box.right >= 0 && box.right <= innerWidth));
  120 |       const visibleOutlineArea = exposed * parseFloat(css.outlineWidth);
  121 |       return { censusId: (e as HTMLElement).dataset.focusCensus, rect: { top: box.top, bottom: box.bottom, left: box.left, right: box.right }, visibleOutlineArea, requiredOutlineArea: 2 * (2 * (box.width + box.height)), label: e.textContent?.slice(0, 70) || e.tagName, ratio, width: parseFloat(css.outlineWidth), visible: css.outlineStyle !== 'none' && (e.matches(':focus-visible') || e.matches(':focus-within')), inModal: !document.querySelector('dialog[open]') || !!e.closest('dialog[open]'), onscreen: box.bottom > 0 && box.top < innerHeight && box.right > 0 && box.left < innerWidth && !!hit && (e.contains(hit) || hit.contains(e)) };
  122 |     });
  123 |     if (value) {
  124 |       results.push(value);
  125 |       if (value.censusId !== undefined && !pixelSeen.has(value.censusId)) {
  126 |         pixelResults.push(await focusPixelChange(page, info, state, value.censusId)); pixelSeen.add(value.censusId);
  127 |       }
  128 |       if (value.censusId !== undefined) {
  129 |         if (first === undefined) first = value.censusId;
  130 |         else if (value.censusId !== first) leftFirst = true;
  131 |         else if (leftFirst || census.length === 1 && results.length > 1) { completedCycle = true; break; }
  132 |         seen.add(value.censusId);
  133 |       }
  134 |     }
  135 |   }
  136 |   const missing = census.filter(control => !seen.has(control.id));
  137 |   await info.attach(state + '-focus', { body: JSON.stringify({ pixelResults, census, visited: [...seen], missing, completedCycle, results }, null, 2), contentType: 'application/json' });
  138 |   expect(pixelResults.filter(result => result.changedArea < result.requiredArea), state + ' actual same-pixel focus change').toEqual([]);
  139 |   expect(completedCycle, state + ' bounded keyboard traversal completed a cycle').toBe(true);
  140 |   expect(missing, state + ' all reachable controls visited').toEqual([]);
  141 |   expect(results.filter(v => !v.visible || v.width < 2 || v.ratio < 3 || !v.inModal || !v.onscreen || v.visibleOutlineArea < v.requiredOutlineArea), state).toEqual([]);
  142 | }
  143 | 
```