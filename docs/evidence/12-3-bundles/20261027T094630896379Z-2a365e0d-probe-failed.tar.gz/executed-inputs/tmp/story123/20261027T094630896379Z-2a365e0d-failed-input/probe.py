print('Feil med æ ø å', flush=True)
raise SystemExit(7)
