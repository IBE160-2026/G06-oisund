import subprocess,sys,time
from pathlib import Path
child=subprocess.Popen([sys.executable,'-c','import time; time.sleep(90)'])
Path('D:\\IBE160\\tmp\\story-12-3\\tmp\\story123\\20261027T190157277595Z-aa5a619f-timeout-input\\child.pid').write_text(str(child.pid))
print('Owned child started',flush=True)
time.sleep(90)
