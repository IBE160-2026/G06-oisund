# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: tablet-pc-measurement-probes.spec.ts >> actual native checkmark passes and a checked appearance-none fill without glyph fails
- Location: .story123-tests\tablet-pc-measurement-probes.spec.ts:31:1

# Error details

```
Error: actual checked fill matches declared accent  Consent

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- main [ref=e2]:
  - generic [ref=e3]:
    - checkbox "Consent" [checked] [active] [ref=e4]
    - text: Consent
```

# Test source

```ts
  1  | import { createRequire } from 'node:module';
  2  | import { expect, type Page, type TestInfo } from '@playwright/test';
  3  | const require = createRequire(import.meta.url);
  4  | // PNG is bundled in the exact locked Playwright version; no downloaded helper.
  5  | const { PNG } = require(require.resolve('playwright-core/package.json').replace('package.json', 'lib/utilsBundle.js'));
  6  | const lum = (rgb: number[]) => rgb.map(n => { n /= 255; return n <= .04045 ? n / 12.92 : ((n + .055) / 1.055) ** 2.4; }).reduce((s, n, i) => s + n * [.2126, .7152, .0722][i], 0);
  7  | const contrast = (a: number[], b: number[]) => (Math.max(lum(a), lum(b)) + .05) / (Math.min(lum(a), lum(b)) + .05);
  8  | 
  9  | // Inspect actual rendered indicator pixels, including both checked states. The
  10 | // input's original value is restored; this never sends a confirmation or save.
  11 | export async function measureChoices(page: Page, info: TestInfo, state: string) {
  12 |   const controls = page.locator('input[type=checkbox]:visible');
  13 |   const results = [];
  14 |   for (let i = 0; i < await controls.count(); i++) {
  15 |     const input = controls.nth(i), original = await input.isChecked();
  16 |     for (const checked of [false, true]) {
  17 |       await input.setChecked(checked);
  18 |       const context = await input.evaluate(e => {
  19 |         let parent = e.parentElement; let bg = 'rgb(255,255,255)';
  20 |         while (parent) { const c = getComputedStyle(parent).backgroundColor; if (c !== 'rgba(0, 0, 0, 0)') { bg = c; break; } parent = parent.parentElement; }
  21 |         return { accent: getComputedStyle(e).accentColor.match(/[\d.]+/g)?.slice(0, 3).map(Number), appearance: getComputedStyle(e).appearance, background: bg.match(/[\d.]+/g)!.slice(0, 3).map(Number), label: e.closest('label')?.textContent, labelHeight: e.closest('label')?.getBoundingClientRect().height };
  22 |       });
  23 |       const screenshot = await input.screenshot();
  24 |       await info.attach(`${state}-checkbox-${i}-${checked}.png`, { body: screenshot, contentType: 'image/png' });
  25 |       const png = PNG.sync.read(screenshot);
  26 |       const pixel = (x: number, y: number) => Array.from(png.data.subarray((y * png.width + x) * 4, (y * png.width + x) * 4 + 3)) as number[];
  27 |       // Sample the straight central portion of all four edges. For each edge,
  28 |       // find its rendered stroke/fill within a shallow strip; rounded corner
  29 |       // antialiasing is outside the sample. Use the weakest of the four edges.
  30 |       const edgeRatios = [];
  31 |       const depth = Math.max(4, Math.floor(Math.min(png.width, png.height) * .15));
  32 |       for (const edge of ['left', 'right', 'top', 'bottom']) {
  33 |         let strongest = 0;
  34 |         for (let d = 0; d < depth; d++) {
  35 |           const values = [];
  36 |           const length = ['left', 'right'].includes(edge) ? png.height : png.width;
  37 |           for (let n = Math.floor(length * .3); n < length * .7; n++) {
  38 |             const x = edge === 'left' ? d : edge === 'right' ? png.width - 1 - d : n;
  39 |             const y = edge === 'top' ? d : edge === 'bottom' ? png.height - 1 - d : n;
  40 |             values.push(contrast(pixel(x, y), context.background));
  41 |           }
  42 |           values.sort((a, b) => a - b); strongest = Math.max(strongest, values[Math.floor(values.length / 2)]);
  43 |         }
  44 |         edgeRatios.push(strongest);
  45 |       }
  46 |       const histogram = new Map<string, number>();
  47 |       for (let y = depth; y < png.height - depth; y++) for (let x = depth; x < png.width - depth; x++) { const key = pixel(x, y).join(','); histogram.set(key, (histogram.get(key) ?? 0) + 1); }
  48 |       const palette = [...histogram].sort((a, b) => b[1] - a[1]).filter(([, count]) => count >= 3).slice(0, 4);
  49 |       const fill = palette[0]?.[0].split(',').map(Number) ?? [0, 0, 0];
  50 |       const fillMatchesAccent = !!context.accent && fill.every((value, channel) => Math.abs(value - context.accent![channel]) <= 12);
  51 |       // Classify the dominant checked fill, then find an actual connected,
  52 |       // non-boundary glyph component against it. Arbitrary color pairs and
  53 |       // the author stroke cannot count as a checkmark.
  54 |       const candidates = new Set<string>();
  55 |       if (checked) for (let y = depth; y < png.height - depth; y++) for (let x = depth; x < png.width - depth; x++) if (contrast(pixel(x, y), fill) >= 3) candidates.add(x + ',' + y);
  56 |       const components = [];
  57 |       while (candidates.size) {
  58 |         const first = candidates.values().next().value!; candidates.delete(first);
  59 |         const queue = [first], points: number[][] = [];
  60 |         for (let n = 0; n < queue.length; n++) { const [x, y] = queue[n].split(',').map(Number); points.push([x, y]); for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const key = (x + dx) + ',' + (y + dy); if (candidates.delete(key)) queue.push(key); } }
  61 |         components.push({ area: points.length, width: Math.max(...points.map(p => p[0])) - Math.min(...points.map(p => p[0])) + 1, height: Math.max(...points.map(p => p[1])) - Math.min(...points.map(p => p[1])) + 1, points });
  62 |       }
  63 |       const glyph = components.filter(c => c.area >= 3 && c.width >= (png.width - 2 * depth) * .2 && c.height >= (png.height - 2 * depth) * .2).sort((a, b) => b.area - a.area)[0] ?? null;
  64 |       results.push({ ...context, checked, size: [png.width, png.height], edgeRatios, palette, fill, fillMatchesAccent, glyph });
  65 |       await info.attach(`${state}-checkbox-${i}-${checked}-pixels`, { body: JSON.stringify(results[results.length - 1], null, 2), contentType: 'application/json' });
  66 |       expect(Math.min(...edgeRatios), 'actual checkbox edge ' + context.label).toBeGreaterThanOrEqual(3);
> 67 |       if (checked) { expect(fillMatchesAccent, 'actual checked fill matches declared accent ' + context.label).toBe(true); expect(glyph, 'actual non-boundary checkmark component ' + context.label).not.toBeNull(); }
     |                                                                                                                ^ Error: actual checked fill matches declared accent  Consent
  68 |       expect(context.labelHeight, 'forgiving checkbox label').toBeGreaterThanOrEqual(58);
  69 |     }
  70 |     await input.setChecked(original);
  71 |   }
  72 |   await info.attach(state + '-native-indicators', { body: JSON.stringify(results, null, 2), contentType: 'application/json' });
  73 | }
  74 | 
```