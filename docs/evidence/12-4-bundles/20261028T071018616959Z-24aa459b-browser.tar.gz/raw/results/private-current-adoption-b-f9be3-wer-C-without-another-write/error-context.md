# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: private-current-adoption.spec.ts >> bus: adopting comparison reads actual newer C without another write
- Location: .story124-tests\private-current-adoption.spec.ts:31:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: 0

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Test source

```ts
  1  | import { test, expect, openedPlan, API, post, randomUUID, setup, beforeUnload } from './private-activity-helpers';
  2  | import type { Page, BrowserContext } from '@playwright/test';
  3  | 
  4  | setup();
  5  | test.use({ actionTimeout: 15000 });
  6  | type Resource = 'bus' | 'selection';
  7  | async function conflicted(page: Page, context: BrowserContext, resource: Resource) {
  8  |   const { plan, activities } = await openedPlan(page, context);
  9  |   const path = '/workdays/' + plan.id + (resource === 'bus' ? '/physical-bus' : '/selection');
  10 |   const scope = page.getByRole('region', { name: resource === 'bus' ? 'Fysisk buss' : 'Aktivitetsvalg', exact: true });
  11 |   const load = scope.getByRole('button', { name: resource === 'bus' ? 'Last inn lagret buss' : 'Last inn lagret aktivitetsvalg', exact: true });
  12 |   const command = (revision: number, third: boolean) => ({ operation_id: randomUUID(), expected_revision: revision, ...(resource === 'bus' ? { physical_bus: third ? 'Synthetic current C' : 'Synthetic comparison B' } : { activity_id: activities[third ? 2 : 0].id }) });
  13 |   if (resource === 'bus') await scope.getByLabel('Fysisk buss', { exact: true }).fill('Synthetic local proposal A');
  14 |   await post(context, path, command(0, false));
  15 |   await page.getByRole('button', { name: resource === 'bus' ? 'Lagre fysisk buss' : 'Velg aktivitet 2', exact: true }).click();
  16 |   await expect(load).toBeEnabled();
  17 |   if (resource === 'bus') await expect(scope.getByLabel('Fysisk buss', { exact: true })).toHaveValue('Synthetic local proposal A');
  18 |   else await expect(scope.getByText(/^Lokalt forslag/)).toContainText('24');
  19 |   const c = await post(context, path, command(1, true));
  20 |   let reads = 0, writes = 0;
  21 |   page.on('request', request => { if (request.url() === API + path) { if (request.method() === 'GET') reads++; if (request.method() === 'POST') writes++; } });
  22 |   return { plan, activities, path, scope, load, c: c.result, reads: () => reads, writes: () => writes };
  23 | }
  24 | async function proposalRetained(page: Page, resource: Resource, scope: any) {
  25 |   if (resource === 'bus') await expect(scope.getByLabel('Fysisk buss', { exact: true })).toHaveValue('Synthetic local proposal A');
  26 |   else await expect(scope.getByText(/^Lokalt forslag/)).toContainText('24');
  27 |   expect(await beforeUnload(page)).toBe(true);
  28 | }
  29 | 
  30 | for (const resource of ['bus', 'selection'] as const) {
  31 |   test(`${resource}: adopting comparison reads actual newer C without another write`, async ({ page, context }) => {
  32 |     const state = await conflicted(page, context, resource);
  33 |     await state.load.click();
> 34 |     await expect.poll(state.reads).toBe(1);
     |                                    ^ Error: expect(received).toBe(expected) // Object.is equality
  35 |     if (resource === 'bus') await expect(state.scope.getByLabel('Fysisk buss', { exact: true })).toHaveValue('Synthetic current C');
  36 |     else {
  37 |       await expect(state.scope.getByText(/^Manuelt valgt/)).toContainText('Aktivitet 3');
  38 |       await expect(state.scope.getByText(/^Lokalt forslag/)).toHaveCount(0);
  39 |     }
  40 |     expect(state.writes()).toBe(0);
  41 |     expect(await beforeUnload(page)).toBe(false);
  42 |     expect(await (await context.request.get(API + state.path)).json()).toEqual(state.c);
  43 |   });
  44 | 
  45 |   for (const failure of ['unavailable', 'regressed', 'changed-equal-revision', 'expired-timestamp', 'denied', 'unauthorized'] as const) {
  46 |     test(`${resource}: ${failure} fresh adoption never replaces local proposal with cached comparison`, async ({ page, context }) => {
  47 |       const state = await conflicted(page, context, resource);
  48 |       await page.route('**:18326' + state.path, async route => {
  49 |         if (failure === 'unavailable') return route.fulfill({ status: 503, json: { detail: 'Synthetic unavailable current read' } });
  50 |         if (failure === 'denied') return route.fulfill({ status: 410, json: { detail: 'Tilgangen ble avvist.' } });
  51 |         if (failure === 'unauthorized') return route.fulfill({ status: 401, json: { detail: 'Økten er utløpt.' } });
  52 |         const value = { ...state.c, ...(failure === 'expired-timestamp' ? { expires_at: '2000-01-01T00:00:00+00:00' } : { revision: failure === 'regressed' ? 0 : 1 }) };
  53 |         await route.fulfill({ json: value });
  54 |       });
  55 |       await state.load.click();
  56 |       await expect.poll(state.reads).toBe(1);
  57 |       expect(state.writes()).toBe(0);
  58 |       if (failure === 'unauthorized') {
  59 |         await expect(page.getByRole('heading', { name: 'Logg inn', exact: true })).toBeVisible();
  60 |         await expect(state.scope).toHaveCount(0);
  61 |       } else {
  62 |         await proposalRetained(page, resource, state.scope);
  63 |         // Retry remains reachable even when current authority has been denied.
  64 |         await expect(state.load).toBeEnabled();
  65 |         await page.unroute('**:18326' + state.path);
  66 |         await state.load.click();
  67 |         await expect.poll(state.reads).toBe(2);
  68 |         if (resource === 'bus') await expect(state.scope.getByLabel('Fysisk buss', { exact: true })).toHaveValue('Synthetic current C');
  69 |         else await expect(state.scope.getByText(/^Manuelt valgt/)).toContainText('Aktivitet 3');
  70 |         expect(await beforeUnload(page)).toBe(false);
  71 |         expect(state.writes()).toBe(0);
  72 |       }
  73 |     });
  74 |   }
  75 | }
  76 | 
```