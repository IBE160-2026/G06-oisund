import { test, expect, API, account, setup } from './private-activity-helpers';
import { editor } from './private-screen-helpers';
import { readFileSync } from 'node:fs';
import type { Page, BrowserContext } from '@playwright/test';
setup();
const oracle = JSON.parse(readFileSync('../Eksempelfiler/Fasit-testskift.json', 'utf8').replace(/^\uFEFF/, '')).shifts.find((shift: any) => shift.case === 'A');
const button = (page: Page, name: string) => page.getByRole('button', { name, exact: true });
async function loginAndImport(page: Page) {
  await page.goto('/private');
  await page.getByLabel('Brukernavn', { exact: true }).fill(account.username);
  await page.getByLabel('Passord', { exact: true }).fill(account.password);
  await button(page, 'Logg inn').click();
  await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles('../Eksempelfiler/Testskift-A.pdf');
  await expect(button(page, 'Alt stemmer – lagre og fortsett')).toBeVisible();
}
async function drafts(context: BrowserContext) { const response = await context.request.get(API + '/drafts'); expect(response.ok()).toBe(true); return (await response.json()).drafts; }
async function fullDraft(context: BrowserContext, id: string) { const response = await context.request.get(API + '/drafts/' + id); expect(response.ok()).toBe(true); return response.json(); }
function assertIndependentFacts(content: any) {
  expect(content.service_date).toBe(oracle.date.split('/').reverse().join('-'));
  expect(content.import_metadata.header.shift_id).toBe(oracle.shift_id);
  expect(content.vehicle_duty).toBe(oracle.events.find((event: any) => event.kind === 'vehicle').vehicle);
  const events = oracle.events.filter((event: any) => event.kind !== 'vehicle');
  expect(content.activities).toHaveLength(events.length);
  for (const [index, event] of events.entries()) {
    const row = content.activities[index];
    const start = event.kind === 'movement' ? event.stops[0].local_datetime : event.start_local;
    const end = event.kind === 'movement' ? event.stops.at(-1).local_datetime : event.end_local;
    expect(Date.parse(row.start)).toBe(Date.parse(start + ':00+01:00'));
    expect(Date.parse(row.end)).toBe(Date.parse(end + ':00+01:00'));
    if (event.kind === 'movement') expect([row.trip, row.from_place, row.to_place]).toEqual([event.trip_id, event.stops[0].name, event.stops.at(-1).name]);
  }
}
for (const width of [768, 1440]) test(`correct import saves explicitly and reaches distinct compact approval at ${width}px`, async ({ page, context }, info) => {
  await page.setViewportSize({ width, height: 1000 }); await loginAndImport(page);
  expect(await drafts(context)).toEqual([]);
  await expect(page.getByText('Importsammendrag', { exact: true })).toBeVisible();
  await expect(page.getByRole('region', { name: 'Kildefakta fra PDF', includeHidden: true })).toBeHidden();
  await page.screenshot({ path: info.outputPath('import-summary.png'), fullPage: true });
  await button(page, 'Alt stemmer – lagre og fortsett').click();
  const review = page.getByRole('region', { name: 'Gjennomgått versjon' }); await expect(review).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Rediger utkast', exact: true })).toBeHidden();
  await expect(review.getByText('Vis alle opplysninger i lagret versjon', { exact: true })).toBeVisible();
  const saved = await fullDraft(context, (await drafts(context))[0].id); assertIndependentFacts(saved.draft); expect(saved.revision).toBe(1);
  expect(await review.getByRole('checkbox').count()).toBeGreaterThan(0);
  for (const box of await review.getByRole('checkbox').all()) await expect(box).not.toBeChecked();
  await expect(button(page, 'Bekreft gjennomgått plan')).toBeDisabled();
  await page.screenshot({ path: info.outputPath('compact-approval.png'), fullPage: true });
  await review.getByText('Vis alle opplysninger i lagret versjon', { exact: true }).click();
  await expect(review).toContainText(oracle.start_place);
  for (const select of await review.getByRole('combobox').all()) await select.selectOption('manual');
  for (const box of await review.getByRole('checkbox').all()) await box.check();
  await button(page, 'Bekreft gjennomgått plan').click();
  await expect(page.getByRole('region', { name: 'Dagsoversikt', exact: true })).toBeVisible();
  await expect(button(page, 'Start skift')).toBeVisible();
  const bus = page.getByRole('region', { name: 'Fysisk buss', exact: true });
  await bus.getByLabel('Fysisk buss', { exact: true }).fill('SYN-ONLY-BUS');
  await bus.getByRole('button', { name: 'Lagre fysisk buss', exact: true }).click();
  await expect(bus.getByRole('status', { name: 'Bussstatus' })).toHaveText('Fysisk buss er lagret.');
  expect((await fullDraft(context, saved.id)).draft).toEqual(saved.draft);
});
test('corrections keep save position, bus refuses unrelated proposals, and time save can proceed directly', async ({ page, context }, info) => {
  await loginAndImport(page); await button(page, 'Rett eller legg til opplysninger').click();
  const destination = page.getByLabel('Til sted', { exact: true }).nth(1);
  await destination.fill('Syntetisk rettet endeholdeplass');
  await page.getByLabel('Buss/vogn', { exact: true }).fill('SYN-42');
  await button(page, 'Lagre buss/vogn').click();
  await expect(page.getByLabel('Buss i utkast', { exact: true })).toContainText('Andre opplysninger er også ulagret');
  expect(await drafts(context)).toEqual([]); await expect(destination).toHaveValue('Syntetisk rettet endeholdeplass');
  const save = button(page, 'Lagre utkast'); await save.scrollIntoViewIfNeeded(); await save.focus();
  const before = await page.evaluate(() => scrollY); expect(before).toBeGreaterThan(500);
  await page.keyboard.press('Enter');
  await expect(page.getByRole('status', { name: 'Lagringsstatus' })).toHaveText('Lagret. Versjon 1.');
  expect(Math.abs(await page.evaluate(() => scrollY) - before)).toBeLessThan(100); await expect(save).toBeFocused();
  await page.screenshot({ path: info.outputPath('saved-in-position.png') });
  const saved = await fullDraft(context, (await drafts(context))[0].id);
  expect(saved.draft.activities[1].to_place).toBe('Syntetisk rettet endeholdeplass'); expect(saved.draft.physical_bus).toBe('SYN-42');
  await page.getByLabel('Buss/vogn', { exact: true }).fill('SYN-43'); await button(page, 'Lagre buss/vogn').click();
  await expect(page.getByRole('status', { name: 'Lagringsstatus' })).toHaveText('Lagret. Versjon 2.');
  const busOnly = await fullDraft(context, saved.id); expect(busOnly.draft.activities).toEqual(saved.draft.activities); expect(busOnly.draft.physical_bus).toBe('SYN-43');
  const start = page.getByLabel('Starttid', { exact: true }).first(); await start.fill('06:51');
  await expect(save).toBeEnabled(); await save.click(); await expect(page.getByRole('status', { name: 'Lagringsstatus' })).toHaveText('Lagret. Versjon 3.');
  await button(page, 'Fortsett til godkjenning').click(); await expect(page.getByRole('region', { name: 'Gjennomgått versjon' })).toContainText('Lagret versjon 3');
});
test('failed direct save retains original operation and only explicit recovery advances', async ({ page, context }) => {
  await loginAndImport(page);
  await page.route('**:18326/drafts', route => route.request().method() === 'POST' ? route.abort() : route.continue());
  await button(page, 'Alt stemmer – lagre og fortsett').click();
  await expect(page.getByRole('status', { name: 'Lagringsstatus' })).toContainText('Lagring er uavklart');
  await expect(page.getByRole('heading', { name: 'Gjennomgå og bekreft', exact: true })).toBeHidden(); expect(await drafts(context)).toEqual([]);
  await page.unroute('**:18326/drafts'); await button(page, 'Prøv samme lagringsforsøk igjen').click();
  await expect(page.getByRole('region', { name: 'Gjennomgått versjon' })).toBeVisible(); expect(await drafts(context)).toHaveLength(1);
});
test('new edit invalidates saved review and unfinished time cannot bypass explicit save', async ({ page, context }) => {
  await loginAndImport(page); await button(page, 'Alt stemmer – lagre og fortsett').click();
  await expect(page.getByRole('region', { name: 'Gjennomgått versjon' })).toBeVisible(); await editor(page);
  await page.getByLabel('Startdato', { exact: true }).first().fill('');
  await expect(button(page, 'Lagre utkast')).toBeDisabled(); await expect(button(page, 'Til godkjenning')).toBeDisabled();
  await expect(page.getByRole('region', { name: 'Gjennomgått versjon' })).toHaveCount(0); expect((await fullDraft(context, (await drafts(context))[0].id)).revision).toBe(1);
});
