# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: private-selected-activity.spec.ts >> delayed upload failure leaves edited draft and focus intact
- Location: .story124-tests\private-selected-activity.spec.ts:93:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('region', { name: 'Importer tekst-PDF', exact: true, includeHidden: true })
Expected substring: "PDF-en kunne ikke tolkes"
Received string:    "Gjennomgå en tekst-PDFTjenesten er midlertidig utilgjengelig. Prøv opplastingen igjen senere.Velg tekst-PDF"
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByRole('region', { name: 'Importer tekst-PDF', exact: true, includeHidden: true }) with timeout 5000ms
  - waiting for getByRole('region', { name: 'Importer tekst-PDF', exact: true, includeHidden: true })
    14 × locator resolved to <section aria-label="Importer tekst-PDF">…</section>
       - unexpected value "Gjennomgå en tekst-PDFTjenesten er midlertidig utilgjengelig. Prøv opplastingen igjen senere.Velg tekst-PDF"

```

```yaml
- main:
  - button "Nattmodus"
  - text: "Visning: Dag"
  - paragraph: Privat tilgang
  - heading "Privat arbeidsrom" [level=1]
  - status "Tilgangsstatus": Du er logget inn.
  - region "Privat arbeidsrom":
    - region "Private utkast":
      - navigation "Plan og forberedelse":
        - button "Forberedelse og planlister"
        - button "Kontroller og rediger utkast"
        - button "Til godkjenning" [disabled]
        - button "Til den åpne planen"
      - group:
        - heading "Nytt manuelt utkast" [level=2]
        - button "Gjennomgå lagret utkast" [disabled]
        - group "Dagens opplysninger":
          - text: Dagens opplysninger Tjenestedato
          - textbox "Tjenestedato"
          - text: Vognløp
          - textbox "Vognløp": Behold etter feil
          - paragraph: Vognløp ved starten av dagen. Bytter kan angis ved aktivitetene nedenfor og gjelder fra den aktiviteten til neste bytte. Et vognløpsbytte endrer ikke Buss/vogn.
          - button "Tøm vognløp"
          - paragraph: "Sanntidsverdi: ukjent (avledet fra vognløp)."
          - text: Buss/vogn
          - textbox "Buss/vogn"
          - button "Lagre buss/vogn" [disabled]
          - button "Tøm buss/vogn"
          - paragraph: Utkastet er ikke lagret. Buss kan ikke lagres separat nå. Bruk Lagre hele utkastet med buss for å lagre alle opplysningene uttrykkelig. Ulagrede endringer.
          - button "Lagre hele utkastet med buss"
          - paragraph: Alle klokkeslett bruker Oslo-tid. Velg riktig kalenderdag for nattarbeid. Opprinnelige klokker som 25:10 kan beholdes i kildefeltene. Tomme klokkeslett betyr ukjent.
          - paragraph: "Gjeldende ukjent opplysning: tjenestedato."
          - paragraph: Ingen aktiviteter. Utkastet er uferdig og ikke bekreftet.
          - button "Legg til aktivitet"
        - button "Lagre utkast"
        - status "Lagringsstatus": Ulagrede endringer.
        - button "Fortsett til godkjenning" [disabled]
        - button "Tilbakestill utkast"
    - region "Bekreft plan":
      - status "Bekreftelsesstatus": Bekreftet plan åpnet. Fristen er uendret.
      - button "Manuelt vedlikeholdte avvik"
    - paragraph: Økten utløper 11.11.2026, 15:51.
    - button "Logg ut"
  - paragraph: Tilgang opprettes av den som drifter løsningen. Bruk arbeidsrommet mens du står stille.
  - link "Åpne fiktiv demo":
    - /url: /
```

# Test source

```ts
  1   | import { test, expect, API, setup, openedPlan, selected, activityStatus, dayScreen, activityScreen, account, python, post, randomUUID, beforeUnload } from './private-activity-helpers';
  2   | import { writeFileSync } from 'node:fs';
  3   | 
  4   | setup();
  5   | const fact = (page: Parameters<typeof selected>[0], name: string) => selected(page).locator('.selected-facts > div').filter({ has: page.getByText(name + ':', { exact: true }) }).locator('dd');
  6   | 
  7   | test('literal Oslo offset transition and passenger unknown rows remain independent', async ({ page, context }) => {
  8   |   await openedPlan(page, context, true, undefined, undefined, false, content => {
  9   |     content.service_date = '2026-10-25'; Object.assign(content.activities[0], { start: '2026-10-25T02:55+02:00', end: '2026-10-25T02:05+01:00', line: null, trip: null, direction: ' ' });
  10  |   });
  11  |   await page.getByRole('button', { name: 'Velg aktivitet 1', exact: true }).click();
  12  |   await expect(fact(page, 'Planlagt start')).toHaveText('25.10.2026, 02:55');
  13  |   await expect(fact(page, 'Planlagt slutt')).toHaveText('25.10.2026, 02:05');
  14  |   for (const field of ['Linje', 'Turnummer', 'Retning']) await expect(fact(page, field)).toHaveText('Ukjent');
  15  | });
  16  | 
  17  | test('Back cancels held next auto-open while preserving the acknowledged selection', async ({ page, context }) => {
  18  |   const { plan, activities } = await openedPlan(page, context);
  19  |   await page.getByRole('button', { name: 'Velg aktivitet 1', exact: true }).click(); await expect(selected(page)).toBeVisible();
  20  |   let release!: () => void, entered!: () => void; const held = new Promise<void>(r => release = r), received = new Promise<void>(r => entered = r);
  21  |   await page.route('**:18326/workdays/' + plan.id + '/selection', async route => { if (route.request().method() === 'GET') return route.continue(); const response = await route.fetch(); entered(); await held; await route.fulfill({ response }); });
  22  |   try {
  23  |     await page.getByRole('button', { name: 'Neste aktivitet', exact: true }).click(); await received;
  24  |     await page.getByRole('button', { name: 'Tilbake til dagen', exact: true }).click();
  25  |     await expect(page.getByRole('button', { name: 'Åpne aktivitet 1', exact: true })).toBeFocused(); release();
  26  |     await expect(activityStatus(page)).toHaveText('Aktivitetsvalget er lagret.'); await expect(selected(page)).toHaveCount(0);
  27  |     expect((await (await context.request.get(API + '/workdays/' + plan.id + '/selection')).json()).activity_id).toBe(activities[1].id);
  28  |     await page.getByRole('button', { name: 'Åpne aktivitet 2', exact: true }).click(); await expect(selected(page)).toHaveAttribute('data-selected-activity-id', activities[1].id);
  29  |   } finally { release(); }
  30  | });
  31  | 
  32  | test('loading and failed next choice preserve focused Back and recovery controls', async ({ page, context }) => {
  33  |   const { plan } = await openedPlan(page, context); await page.getByRole('button', { name: 'Velg aktivitet 1', exact: true }).click(); await expect(selected(page)).toBeVisible();
  34  |   let release!: () => void, entered!: () => void; const held = new Promise<void>(r => release = r), received = new Promise<void>(r => entered = r);
  35  |   await page.route('**:18326/workdays/' + plan.id + '/selection', async route => { if (route.request().method() === 'GET') return route.continue(); entered(); await held; await route.fulfill({ status: 503, json: { detail: 'synthetic unavailable' } }); });
  36  |   try {
  37  |     await page.getByRole('button', { name: 'Neste aktivitet', exact: true }).click(); await received;
  38  |     const back = page.getByRole('button', { name: 'Tilbake til dagen', exact: true }); await back.focus(); release();
  39  |     await expect(activityStatus(page)).toHaveText('Forsøket er uavklart. Kontroller eller prøv samme forsøk.'); await expect(back).toBeFocused();
  40  |     const retry = page.getByRole('button', { name: 'Kontroller aktivitetsvalget', exact: true }); await retry.focus(); await expect(retry).toBeFocused();
  41  |   } finally { release(); }
  42  | });
  43  | 
  44  | test('long day grouped pause Back restores selected Open and consultation writes nothing', async ({ page, context }) => {
  45  |   const { plan } = await openedPlan(page, context, false, undefined, undefined, false, content => { content.activities[0].from_place = 'Lang syntetisk forklaring '.repeat(10); });
  46  |   await page.getByRole('button', { name: 'Velg aktivitet 2', exact: true }).click(); await expect(selected(page)).toBeVisible();
  47  |   await page.getByRole('button', { name: 'Neste aktivitet', exact: true }).click(); await expect(selected(page)).toContainText('Kaffepause');
  48  |   await page.getByRole('button', { name: 'Neste aktivitet', exact: true }).click(); await expect(selected(page)).toContainText('Matpause');
  49  |   let writes = 0; page.on('request', request => { if (request.method() === 'POST' && request.url().includes('/workdays/')) writes++; });
  50  |   await dayScreen(page); const open = page.getByRole('button', { name: 'Åpne aktivitet 4', exact: true }); await expect(open).toBeFocused(); await expect(open).toBeInViewport();
  51  |   await expect(page.getByRole('button', { name: 'Velg aktivitet 4', exact: true })).toBeDisabled(); await open.click(); await expect(selected(page)).toContainText('Matpause');
  52  |   await dayScreen(page); await expect(open).toBeFocused(); expect(writes).toBe(0);
  53  |   expect((await (await context.request.get(API + '/workdays/' + plan.id + '/selection')).json()).activity_id).toBe(plan.draft.activities[3].id);
  54  | });
  55  | 
  56  | test('different pending confirmation survives retained old plan expiry and resolves its original operation', async ({ page, context }) => {
  57  |   await page.clock.install(); const { plan } = await openedPlan(page, context, true, -604795);
  58  |   await page.clock.setSystemTime(new Date(Date.parse(plan.expires_at) - 15000));
  59  |   await page.getByRole('button', { name: 'Lukk planen', exact: true }).click();
  60  |   await page.getByRole('button', { name: `Åpne plan ${plan.draft.service_date} · versjon 1`, exact: true }).click(); await expect(page.getByText('Ikke startet', { exact: true })).toBeVisible();
  61  |   const source = await post(context, '/drafts', { operation_id: (await post(context, '/draft-operations', {})).operation_id, expected_revision: 0, draft: { service_date: '2031-01-02', activities: [{ id: randomUUID(), type: 'manual', start: '2031-01-02T12:00+01:00', end: '2031-01-02T13:00+01:00' }] } });
  62  |   await page.getByRole('button', { name: 'Forberedelse og planlister', exact: true }).click(); await page.getByRole('button', { name: 'Oppdater listen', exact: true }).click();
  63  |   await page.getByRole('button', { name: 'Åpne 2031-01-02 · versjon 1', exact: true }).click(); await page.getByRole('button', { name: 'Gjennomgå lagret utkast', exact: true }).click();
  64  |   await expect(page.getByRole('button', { name: 'Bekreft gjennomgått plan', exact: true })).toBeEnabled();
  65  |   let operation = '', accepted: any;
  66  |   await page.route('**:18326/drafts/' + source.id + '/confirm', async route => { operation = route.request().postDataJSON().operation_id; accepted = await (await route.fetch()).json(); await route.abort(); });
  67  |     await page.getByRole('button', { name: 'Bekreft gjennomgått plan', exact: true }).click();
  68  |     await expect(page.getByRole('button', { name: 'Kontroller bekreftelsen', exact: true })).toBeEnabled();
  69  |     await page.clock.fastForward(20000);
  70  |     await expect(page.getByRole('button', { name: 'Kontroller bekreftelsen', exact: true })).toBeEnabled();
  71  |     expect(await beforeUnload(page)).toBe(true); await expect(page.getByRole('region', { name: 'Gjennomgått versjon', exact: true })).toBeVisible();
  72  |     await page.unroute('**:18326/drafts/' + source.id + '/confirm');
  73  |     const lookup = page.waitForRequest(request => request.url().endsWith('/workday-operations/' + operation));
  74  |     await page.getByRole('button', { name: 'Kontroller bekreftelsen', exact: true }).click(); await lookup;
  75  |     await expect(page.getByRole('region', { name: 'Dagsoversikt', exact: true })).toBeVisible(); expect(accepted.id).not.toBe(plan.id);
  76  |     expect(await (await context.request.get(API + '/workdays/' + accepted.id)).json()).toEqual(accepted);
  77  |     expect(await beforeUnload(page)).toBe(false);
  78  | });
  79  | 
  80  | test('delayed same-plan denial clears orphaned activity mode and exposes preparation', async ({ page, context }) => {
  81  |   const { plan } = await openedPlan(page, context); await page.getByRole('button', { name: 'Velg aktivitet 1', exact: true }).click(); await expect(selected(page)).toBeVisible(); await dayScreen(page);
  82  |   let release!: () => void, entered!: () => void; const held = new Promise<void>(r => release = r), received = new Promise<void>(r => entered = r);
  83  |   await page.route('**:18326/workdays/' + plan.id, async route => { entered(); await held; await route.fulfill({ status: 404, json: { detail: 'synthetic denial' } }); });
  84  |   try {
  85  |     await page.getByRole('button', { name: 'Forberedelse og planlister', exact: true }).click(); await page.getByRole('button', { name: 'Åpne plan 2031-01-02 · versjon 1', exact: true }).click(); await received;
  86  |     await page.getByRole('button', { name: 'Til den åpne planen', exact: true }).click(); await activityScreen(page); release();
  87  |     await expect(selected(page)).toHaveCount(0); await expect(page.getByRole('heading', { name: 'Mine utkast', exact: true })).toBeVisible();
  88  |     await expect(page.getByRole('button', { name: 'Kontroller og rediger utkast', exact: true })).toBeEnabled();
  89  |     await expect(page.getByRole('status', { name: 'Bekreftelsesstatus', exact: true })).toContainText('Tilgangen ble avvist');
  90  |   } finally { release(); }
  91  | });
  92  | 
  93  | test('delayed upload failure leaves edited draft and focus intact', async ({ page, context }) => {
  94  |   await openedPlan(page, context); let release!: () => void, entered!: () => void;
  95  |   const held = new Promise<void>(r => release = r), received = new Promise<void>(r => entered = r);
  96  |   await page.route('**:18326/imports/pdf', async route => { entered(); await held; await route.fulfill({ status: 503, json: { detail: 'synthetic unavailable' } }); });
  97  |   try {
  98  |     await page.getByRole('button', { name: 'Forberedelse og planlister', exact: true }).click(); await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles({ name: 'synthetic.pdf', mimeType: 'application/pdf', buffer: Buffer.from('%PDF-synthetic') }); await received;
  99  |     await page.getByRole('button', { name: 'Kontroller og rediger utkast', exact: true }).click(); const input = page.getByLabel('Vognløp', { exact: true }); await input.fill('Behold etter feil'); release();
> 100 |     await expect(page.getByRole('region', { name: 'Importer tekst-PDF', exact: true, includeHidden: true })).toContainText('PDF-en kunne ikke tolkes');
      |                                                                                                              ^ Error: expect(locator).toContainText(expected) failed
  101 |     await expect(input).toBeFocused(); await expect(input).toHaveValue('Behold etter feil');
  102 |     await page.getByRole('button', { name: 'Forberedelse og planlister', exact: true }).click(); await expect(page.getByText('PDF-en kunne ikke tolkes.', { exact: false })).toBeVisible();
  103 |   } finally { release(); }
  104 | });
  105 | test('exact acknowledged member dates, opposite directions, identical members and pause members survive consultation', async ({ page, context }) => {
  106 |   const { plan } = await openedPlan(page, context, false, undefined, undefined, false, content => {
  107 |     content.activities[1].line = '20';
  108 |     content.activities[4].source_start = '24:00'; content.activities[4].source_end = '24:10';
  109 |   });
  110 |   let writes = 0;
  111 |   page.on('request', req => { if (req.method() === 'POST' && /\/workdays\//.test(req.url())) writes++; });
  112 |   const before = await Promise.all(['', '/selection', '/lifecycle', '/physical-bus'].map(async path => { const response = await context.request.get(API + '/workdays/' + plan.id + path); expect(response.status()).toBe(200); return response.json(); }));
  113 |   await page.getByRole('button', { name: 'Velg aktivitet 1', exact: true }).click();
  114 |   for (let i = 0; i < plan.draft.activities.length; i++) {
  115 |     const activity = plan.draft.activities[i];
  116 |     await expect(selected(page)).toHaveAttribute('data-selected-activity-id', activity.id);
  117 |     await expect(selected(page)).toContainText(`Manuelt valgt · Aktivitet ${i + 1} av 5`);
  118 |     await expect(fact(page, 'Planlagt start')).toHaveText(['02.01.2031, 23:00', '02.01.2031, 23:00', '02.01.2031, 23:10', '02.01.2031, 23:20', '03.01.2031, 00:00'][i]);
  119 |     await expect(fact(page, 'Planlagt slutt')).toHaveText(['02.01.2031, 23:10', '02.01.2031, 23:10', '02.01.2031, 23:20', '02.01.2031, 23:30', '03.01.2031, 00:10'][i]);
  120 |     await expect(page.getByRole('region', { name: 'Dagsoversikt', exact: true })).toBeHidden();
  121 |     await expect(page.getByRole('region', { name: 'Fysisk buss', exact: true })).toBeHidden();
  122 |     await expect(page.getByLabel('Velg tekst-PDF', { exact: true })).toBeHidden();
  123 |     await expect(page.getByText('Stoppdata er ikke tilgjengelig i denne visningen.', { exact: true })).toBeVisible();
  124 |     if (i === 0) { await expect(fact(page, 'Retning')).toHaveText('Nord'); await expect(page.getByRole('button', { name: 'Ingen forrige aktivitet', exact: true })).toBeDisabled(); }
  125 |     if (i === 1) await expect(fact(page, 'Retning')).toHaveText('Sør');
  126 |     if (i < 4) await page.getByRole('button', { name: 'Neste aktivitet', exact: true }).click();
  127 |   }
  128 |   await expect(page.getByRole('button', { name: 'Ingen neste aktivitet', exact: true })).toBeDisabled();
  129 |   const savedSelection = await (await context.request.get(API + '/workdays/' + plan.id + '/selection')).json();
  130 |   const count = writes;
  131 |   await dayScreen(page); await expect(page.getByRole('button', { name: 'Åpne aktivitet 5', exact: true })).toBeFocused();
  132 |   await activityScreen(page); await expect(activityStatus(page)).toBeFocused();
  133 |   await dayScreen(page);
  134 |   await page.getByRole('button', { name: 'Forberedelse og planlister', exact: true }).click();
  135 |   await page.getByRole('button', { name: 'Til den åpne planen', exact: true }).click(); await activityScreen(page);
  136 |   expect(writes).toBe(count);
  137 |   const after = await Promise.all(['', '/selection', '/lifecycle', '/physical-bus'].map(async path => { const response = await context.request.get(API + '/workdays/' + plan.id + path); expect(response.status()).toBe(200); return response.json(); }));
  138 |   expect(after).toEqual([before[0], savedSelection, before[2], before[3]]);
  139 |   await page.reload(); await page.getByRole('button', { name: 'Åpne plan 2031-01-02 · versjon 1', exact: true }).click(); await activityScreen(page);
  140 |   await expect(selected(page)).toHaveAttribute('data-selected-activity-id', plan.draft.activities[4].id);
  141 | });
  142 | 
  143 | test('identical facts retain member ordinal and saved identity', async ({ page, context }) => {
  144 |   const { activities } = await openedPlan(page, context, false, undefined, undefined, true);
  145 |   for (const i of [0, 1]) {
  146 |     await dayScreen(page); await page.getByRole('button', { name: `Velg aktivitet ${i + 1}`, exact: true }).click();
  147 |     await expect(selected(page)).toHaveAttribute('data-selected-activity-id', activities[i].id);
  148 |     await expect(selected(page)).toContainText(`Aktivitet ${i + 1} av 5`);
  149 |   }
  150 | });
  151 | 
  152 | for (const kind of ['deadhead', 'CAR', 'Travel to', 'Sign-on']) test(`missing ${kind} places and irrelevant fields remain neutral`, async ({ page, context }) => {
  153 |   await openedPlan(page, context, true, undefined, kind, false, content => { Object.assign(content.activities[0], { from_place: '  ', to_place: null, trip: null, uncertainty: 'Kontroller sted med kilden' }); });
  154 |   await page.getByRole('button', { name: 'Velg aktivitet 1', exact: true }).click();
  155 |   await expect(fact(page, 'Fra')).toHaveText('Ukjent'); await expect(fact(page, 'Til')).toHaveText('Ukjent');
  156 |   await expect(selected(page).getByText('Linje:', { exact: true })).toHaveCount(0); await expect(selected(page).getByText('Retning:', { exact: true })).toHaveCount(0);
  157 |   if (['deadhead', 'CAR'].includes(kind)) await expect(fact(page, 'Turnummer')).toHaveText('Ukjent');
  158 |   else await expect(selected(page).getByText('Turnummer:', { exact: true })).toHaveCount(0);
  159 |   if (kind === 'Travel to') { await expect(fact(page, 'Aktivitetstype')).toHaveText('Reise til'); await expect(selected(page)).not.toContainText('CAR'); }
  160 |   await expect(selected(page)).toContainText('Gjeldende usikkerhet: Kontroller sted med kilden');
  161 |   await expect(page.getByRole('button', { name: 'Ingen forrige aktivitet', exact: true })).toBeDisabled();
  162 |   await expect(page.getByRole('button', { name: 'Ingen neste aktivitet', exact: true })).toBeDisabled();
  163 | });
  164 | 
  165 | test('confirmed classification determines selected labels without new acknowledgement', async ({ page, context }) => {
  166 |   const { plan } = await openedPlan(page, context, true, undefined, undefined, false, content => { content.activities[0].type = 'CUSTOM'; }, { '0': 'Travel to' });
  167 |   await page.getByRole('button', { name: 'Velg aktivitet 1', exact: true }).click();
  168 |   await expect(fact(page, 'Aktivitetstype')).toHaveText('Reise til');
  169 |   await expect(selected(page)).toContainText('Valgt aktivitet'); await expect(fact(page, 'Linje')).toHaveText('20');
  170 |   expect(await (await context.request.get(API + '/workdays/' + plan.id)).json()).toEqual(plan);
  171 | });
  172 | 
  173 | test('current uncertainty and located neutral markers stay separate from historical and unlocated source issues', async ({ page, context }) => {
  174 |   const imported = JSON.parse(python('import sys\nsys.path.insert(0,"/app/tests")\nfrom test_pdf_import import synthetic_text_pdf\nfrom app.pdf_import import parse_document\nfrom app.private_import import interpret\nprint(interpret(parse_document(synthetic_text_pdf())).model_dump_json())\n'));
  175 |   await openedPlan(page, context, true, undefined, undefined, false, content => {
  176 |     const metadata = imported.import_metadata;
  177 |     const source = metadata.activities[0]; source.activity_id = content.activities[0].id;
  178 |     for (const points of Object.values(source.provenance)) if (Array.isArray(points)) for (const point of points) Object.assign(point, { page: 1, column: 1, line: 1 });
  179 |     metadata.annotations = [{ value: 'A', meaning: null, provenance: { page: 1, column: 1, line: 1 } }, { value: 'U', meaning: null, provenance: { page: 1, column: null, line: null } }];
  180 |     metadata.unresolved = [{ code: 'missing_endpoint', activity: source.source_order, field: 'destination', provenance: { page: 1, column: 1, line: 1 } }];
  181 |     content.import_metadata = metadata;
  182 |     content.activities[0].uncertainty = 'Gjeldende notat. Kildemerket A har ukjent betydning (side 1). Kildemerket U har ukjent betydning (side 1).';
  183 |     content.activities[0].to_place = 'Rettet bekreftet sted';
  184 |   });
  185 |   await page.getByRole('button', { name: 'Velg aktivitet 1', exact: true }).click();
  186 |   await expect(selected(page)).toContainText('Gjeldende usikkerhet: Gjeldende notat.');
  187 |   await expect(selected(page)).toContainText('Kildemerke: A (side 1).');
  188 |   await expect(selected(page)).not.toContainText('Kildemerke: U');
  189 |   await expect(selected(page)).not.toContainText('Endested mangler');
  190 |   await expect(fact(page, 'Til')).toHaveText('Rettet bekreftet sted');
  191 |   await dayScreen(page);
  192 |   await expect(page.getByRole('region', { name: 'Dagsoversikt', exact: true })).toContainText('Opprinnelig kildeusikkerhet');
  193 |   await expect(page.getByRole('region', { name: 'Dagsoversikt', exact: true })).toContainText('Endested mangler');
  194 |   await expect(page.getByRole('region', { name: 'Dagsoversikt', exact: true })).toContainText('Kildemerke: U (side 1).');
  195 | });
  196 | 
  197 | test('uploaded synthetic document passes separate interpretation editor confirmation day and activity screens', async ({ page, context }) => {
  198 |   const pdf = Buffer.from(python('import sys, base64\nsys.path.insert(0,"/app/tests")\nfrom test_pdf_import import synthetic_text_pdf\nprint(base64.b64encode(synthetic_text_pdf()).decode())\n').trim(), 'base64');
  199 |   await page.goto('/private'); await page.getByLabel('Brukernavn', { exact: true }).fill(account.username); await page.getByLabel('Passord', { exact: true }).fill(account.password); await page.getByRole('button', { name: 'Logg inn', exact: true }).click();
  200 |   await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles({ name: 'synthetic-11-2.pdf', mimeType: 'application/pdf', buffer: pdf });
```