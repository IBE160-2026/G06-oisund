# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: private-selected-activity.spec.ts >> activity facts keyboard and enlargement 768 Day
- Location: .story124-tests\private-selected-activity.spec.ts:341:75

# Error details

```
Error: expect(received).toBeLessThan(expected)

Expected: < 450
Received:   480.5625
```

# Test source

```ts
  273 |   await page.getByRole('button', { name: 'Forberedelse og planlister', exact: true }).click();
  274 |   await page.getByRole('button', { name: 'Nytt utkast', exact: true }).click();
  275 |   await expect(page.getByRole('button', { name: 'Lagre utkast', exact: true })).toBeEnabled();
  276 |   await expect(page.getByLabel('Starttid', { exact: true })).toHaveCount(0);
  277 |   await page.getByRole('button', { name: 'Til den åpne planen', exact: true }).click();
  278 |   await expect(page.getByRole('region', { name: 'Dagsoversikt', exact: true })).toBeVisible();
  279 |   expect(await (await context.request.get(API + '/workdays/' + plan.id)).json()).toEqual(plan);
  280 | });
  281 | 
  282 | test('held selection acknowledgement cannot hide a bus proposal created while saving', async ({ page, context }) => {
  283 |   const { plan } = await openedPlan(page, context);
  284 |   let release!: () => void, entered!: () => void;
  285 |   const held = new Promise<void>(resolve => release = resolve), received = new Promise<void>(resolve => entered = resolve);
  286 |   await page.route('**:18326/workdays/' + plan.id + '/selection', async route => {
  287 |     if (route.request().method() === 'GET') return route.continue();
  288 |     const response = await route.fetch(); entered(); await held; await route.fulfill({ response });
  289 |   });
  290 |   try {
  291 |     await page.getByRole('button', { name: 'Velg aktivitet 1', exact: true }).click(); await received;
  292 |     const bus = page.getByRole('region', { name: 'Fysisk buss', exact: true }).getByLabel('Fysisk buss', { exact: true });
  293 |     await bus.fill('Behold bussforslaget'); await expect(bus).toBeFocused(); release();
  294 |     await expect(activityStatus(page)).toHaveText('Aktivitetsvalget er lagret.');
  295 |     await expect(selected(page)).toHaveCount(0); await expect(bus).toBeVisible(); await expect(bus).toHaveValue('Behold bussforslaget'); await expect(bus).toBeFocused();
  296 |     await expect(page.getByRole('button', { name: 'Åpne valgt aktivitet', exact: true })).toBeDisabled();
  297 |     await page.getByRole('button', { name: 'Avbryt bussendring', exact: true }).click();
  298 |     await activityScreen(page); await expect(selected(page)).toHaveAttribute('data-selected-activity-id', plan.draft.activities[0].id);
  299 |   } finally { release(); }
  300 | });
  301 | 
  302 | test('held upload completion retains edited draft and offers an explicit return to interpretation', async ({ page, context }) => {
  303 |   await openedPlan(page, context);
  304 |   const pdf = Buffer.from(python('import sys, base64\nsys.path.insert(0,"/app/tests")\nfrom test_pdf_import import synthetic_text_pdf\nprint(base64.b64encode(synthetic_text_pdf()).decode())\n').trim(), 'base64');
  305 |   let release!: () => void, entered!: () => void;
  306 |   const held = new Promise<void>(resolve => release = resolve), received = new Promise<void>(resolve => entered = resolve);
  307 |   await page.route('**:18326/imports/pdf', async route => { const response = await route.fetch(); entered(); await held; await route.fulfill({ response }); });
  308 |   try {
  309 |     await page.getByRole('button', { name: 'Forberedelse og planlister', exact: true }).click();
  310 |     await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles({ name: 'held-synthetic.pdf', mimeType: 'application/pdf', buffer: pdf }); await received;
  311 |     await page.getByRole('button', { name: 'Kontroller og rediger utkast', exact: true }).click();
  312 |     await page.getByLabel('Vognløp', { exact: true }).fill('Behold dette forslaget');
  313 |     release(); await expect(page.getByRole('button', { name: 'Fortsett importgjennomgang', exact: true, includeHidden: true })).toHaveCount(1);
  314 |     await expect(page.getByRole('heading', { name: 'Nytt manuelt utkast', exact: true })).toBeVisible();
  315 |     await expect(page.getByLabel('Vognløp', { exact: true })).toHaveValue('Behold dette forslaget');
  316 |     await page.getByRole('button', { name: 'Forberedelse og planlister', exact: true }).click();
  317 |     await page.getByRole('button', { name: 'Fortsett importgjennomgang', exact: true }).click();
  318 |     await expect(page.getByRole('button', { name: 'Rett eller legg til opplysninger', exact: true })).toBeVisible();
  319 |     await page.getByRole('button', { name: 'Kontroller og rediger utkast', exact: true }).click();
  320 |     await expect(page.getByLabel('Vognløp', { exact: true })).toHaveValue('Behold dette forslaget');
  321 |   } finally { release(); }
  322 | });
  323 | 
  324 | test('held parent plan read cannot pull the user away from an edited draft', async ({ page, context }) => {
  325 |   const { plan } = await openedPlan(page, context);
  326 |   let release!: () => void, entered!: () => void;
  327 |   const held = new Promise<void>(resolve => release = resolve), received = new Promise<void>(resolve => entered = resolve);
  328 |   await page.route('**:18326/workdays/' + plan.id, async route => { const response = await route.fetch(); entered(); await held; await route.fulfill({ response }); });
  329 |   try {
  330 |     await page.getByRole('button', { name: 'Forberedelse og planlister', exact: true }).click();
  331 |     await page.getByRole('button', { name: 'Åpne plan 2031-01-02 · versjon 1', exact: true }).click(); await received;
  332 |     await page.getByRole('button', { name: 'Kontroller og rediger utkast', exact: true }).click();
  333 |     await page.getByLabel('Vognløp', { exact: true }).fill('Ikke flytt dette utkastet'); release();
  334 |     await expect(page.locator('.private-confirmation')).toHaveAttribute('aria-busy', 'false');
  335 |     await expect(page.getByRole('heading', { name: 'Nytt manuelt utkast', exact: true })).toBeVisible();
  336 |     await expect(page.getByLabel('Vognløp', { exact: true })).toHaveValue('Ikke flytt dette utkastet');
  337 |     await expect(page.getByRole('region', { name: 'Dagsoversikt', exact: true })).toBeHidden();
  338 |   } finally { release(); }
  339 | });
  340 | 
  341 | for (const width of [768, 1024, 1440]) for (const night of [false, true]) test(`activity facts keyboard and enlargement ${width} ${night ? 'Night' : 'Day'}`, async ({ page, context }) => {
  342 |   await page.setViewportSize({ width, height: width === 1024 ? 768 : 1100 }); await openedPlan(page, context);
  343 |   if (night) await page.getByRole('button', { name: 'Nattmodus', exact: true }).click();
  344 |   await page.evaluate(() => { document.documentElement.style.fontSize = '200%'; });
  345 |   await page.getByRole('button', { name: 'Velg aktivitet 1', exact: true }).focus(); await page.keyboard.press('Enter');
  346 |   await expect(selected(page)).toBeVisible(); await expect(activityStatus(page)).toBeFocused();
  347 |   await expect(fact(page, 'Til')).toContainText('Fiktivt langt destinasjonsnavn');
  348 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  349 |   const measurements: object[] = [];
  350 |   for (const name of ['Neste aktivitet', 'Tilbake til dagen']) {
  351 |     const button = page.getByRole('button', { name, exact: true }); await button.focus(); await expect(button).toBeFocused();
  352 |     expect(await button.evaluate(el => el.getBoundingClientRect().height)).toBeGreaterThanOrEqual(58);
  353 |     const measured = await button.evaluate(el => {
  354 |       const light = (v: string) => (v.match(/[\d.]+/g) ?? []).slice(0, 3).map(Number).map(c => { c /= 255; return c <= .04045 ? c / 12.92 : ((c + .055) / 1.055) ** 2.4; }).reduce((sum, c, i) => sum + c * [.2126, .7152, .0722][i], 0);
  355 |       const ratio = (a: string, b: string) => (Math.max(light(a), light(b)) + .05) / (Math.min(light(a), light(b)) + .05);
  356 |       const bg = (node: Element): string => { const c = getComputedStyle(node).backgroundColor; return c === 'rgba(0, 0, 0, 0)' || c === 'transparent' ? node.parentElement ? bg(node.parentElement) : 'rgb(255,255,255)' : c; };
  357 |       const style = getComputedStyle(el);
  358 |       const detail = document.querySelector('.selected-activity')!;
  359 |       const text = [...detail.querySelectorAll('h3,p,dt,dd')].map(node => ratio(getComputedStyle(node).color, bg(node)));
  360 |       return { text: Math.min(...text), boundary: ratio(getComputedStyle(detail).borderInlineStartColor, bg(detail.parentElement!)), focus: ratio(style.outlineColor, bg(el.parentElement!)), focusWidth: parseFloat(style.outlineWidth) };
  361 |     });
  362 |     expect(measured.text).toBeGreaterThanOrEqual(4.5); expect(measured.boundary).toBeGreaterThanOrEqual(3);
  363 |     expect(measured.focus).toBeGreaterThanOrEqual(3); expect(measured.focusWidth).toBeGreaterThanOrEqual(2);
  364 |     measurements.push({ control: name, ...measured });
  365 |     await test.info().attach(`11-2-${width}-${night ? 'night' : 'day'}-${name}`, { body: JSON.stringify(measured), contentType: 'application/json' });
  366 |   }
  367 |   await page.getByRole('region', { name: 'Bekreftet plan', exact: true }).screenshot({ path: `../tmp/story124/20261028T141845088376Z-a0cfe7e7/captures/11-2-activity-${width}-${night ? 'night' : 'day'}.png` });
  368 |   for (const control of [fact(page, 'Planlagt slutt'), fact(page, 'Til'), page.getByRole('button', { name: 'Kontroller plantilgang og aktivitetsvalg', exact: true }), page.getByRole('button', { name: 'Tilbake til dagen', exact: true })]) { await control.scrollIntoViewIfNeeded(); await expect(control).toBeInViewport(); }
  369 |   await page.evaluate(() => window.scrollTo(0, 0));
  370 |   await page.screenshot({ path: `../tmp/story124/20261028T141845088376Z-a0cfe7e7/captures/11-2-activity-viewport-enlarged-${width}-${night ? 'night' : 'day'}.png` });
  371 |   await page.setViewportSize({ width, height: width === 1024 ? 768 : 1100 });
  372 |   await page.evaluate(() => { document.documentElement.style.fontSize = ''; window.scrollTo(0, 0); });
> 373 |   expect(await fact(page, 'Planlagt start').evaluate(el => el.getBoundingClientRect().top)).toBeLessThan(450);
      |                                                                                             ^ Error: expect(received).toBeLessThan(expected)
  374 |   if (width === 1024) for (const endpoint of ['Fra', 'Til']) expect(await fact(page, endpoint).evaluate(el => el.getBoundingClientRect().bottom)).toBeLessThanOrEqual(768);
  375 |   await page.screenshot({ path: `../tmp/story124/20261028T141845088376Z-a0cfe7e7/captures/11-2-activity-viewport-${width}-${night ? 'night' : 'day'}.png` });
  376 |   writeFileSync(`../tmp/story124/20261028T141845088376Z-a0cfe7e7/captures/11-2-contrast-${width}-${night ? 'night' : 'day'}.json`, JSON.stringify(measurements, null, 2) + '\n');
  377 | });
  378 | 
```