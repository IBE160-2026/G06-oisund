# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: private-import.spec.ts >> keyboard review separate adoption save recovery reopen at 1440px
- Location: .story124-tests\private-import.spec.ts:225:34

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Lagring er uavklart.')
Expected: visible
Error: strict mode violation: getByText('Lagring er uavklart.') resolved to 2 elements:
    1) <p aria-live="polite" aria-label="Buss i utkast">Utkastet er ikke lagret. Buss kan ikke lagres sep…</p> aka getByLabel('Buss i utkast')
    2) <p role="status" aria-label="Lagringsstatus">Lagring er uavklart. Behold siden åpen. Kontrolle…</p> aka getByRole('status', { name: 'Lagringsstatus' })

Call log:
  - Expect "toBeVisible" getByText('Lagring er uavklart.') with timeout 5000ms
  - waiting for getByText('Lagring er uavklart.')

```

# Test source

```ts
  149 |       await expect(control).toBeFocused();
  150 |       await expect(control).toHaveCSS('outline-width', '3px');
  151 |       const lightPanel = await control.evaluate(element => !!element.closest('.import-warning, .current-unknown'));
  152 |       await expect(control).toHaveCSS('outline-color', night && !lightPanel ? 'rgb(255, 227, 155)' : 'rgb(0, 0, 0)');
  153 |     }
  154 |   }
  155 |   if (width === 1440) await page.getByRole('button', { name: 'Nattmodus' }).click();
  156 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  157 |   await row().locator('summary').focus(); await page.keyboard.press('Tab'); await page.keyboard.press('Shift+Tab');
  158 |   await expect(row().locator('summary')).toBeFocused();
  159 |   await row().scrollIntoViewIfNeeded();
  160 |   await page.screenshot({ path: `../tmp/story124/20261028T141845088376Z-a0cfe7e7/captures/11-2-regression-10-2-${width}.png` });
  161 |   expect(await page.evaluate(async () => [{ ...localStorage }, sessionStorage.length, (await indexedDB.databases()).length])).toEqual([{ 'ibe160-theme': width === 1440 ? 'day' : 'night' }, 0, 0]);
  162 |   page.once('dialog', d => d.accept()); await row().getByRole('button', { name: 'Fjern aktivitet 1', exact: true }).click();
  163 |   await editor(page); await page.getByRole('button', { name: 'Lagre utkast', exact: true }).click();
  164 |   await expect(page.getByText('Lagret. Versjon 2.', { exact: true })).toBeVisible();
  165 |   const removed = await (await page.request.get('http://127.0.0.1:18326/drafts/' + saved.id)).json();
  166 |   expect(removed.draft.import_metadata).toEqual(source);
  167 |   expect(removed.draft.vehicle_duty_changes).toEqual([]);
  168 | });
  169 | 
  170 | for (const number of [8, 9]) test(`approved example ${number} preserves work and vehicle changes through save and reopen`, async ({ page }) => {
  171 |   await login(page);
  172 |   let facts: any;
  173 |   // Read genuine API bodies in the pass-through handler. Edge can evict the
  174 |   // inspector response cache after a real PDF upload, before Response.json().
  175 |   await page.route('**:18326/imports/pdf', async route => {
  176 |     const response = await route.fetch(); facts = await response.json(); await route.fulfill({ response });
  177 |   });
  178 |   await preparation(page); await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles(resolve(`../Eksempelfiler/Eksempel-${number}-anonymisert.pdf`));
  179 |   await expect(page.getByRole('button', { name: 'Rett eller legg til opplysninger' })).toBeVisible();
  180 |   const count = number === 8 ? 23 : 8;
  181 |   expect(facts.activities).toHaveLength(count);
  182 |   expect(facts.import_metadata.unresolved).toEqual([]);
  183 |   await page.getByText('Vis alle kildefakta fra PDF', { exact: true }).click();
  184 |   const source = page.getByRole('region', { name: 'Kildefakta fra PDF' });
  185 |   if (number === 8) {
  186 |     await expect(source).toContainText('CAR - 1');
  187 |     await expect(source).toContainText('Tomkjøring med CAR');
  188 |     await expect(source).not.toContainText('deadhead_car');
  189 |     expect(facts.vehicle_duty_changes.map((c: any) => [c.vehicle_duty, c.realtime_duty])).toEqual([['960176', '176'], ['CAR - 1', null]]);
  190 |   } else {
  191 |     await expect(source).toContainText('Fadder'); await expect(source).toContainText('Instruktør');
  192 |     expect(facts.activities.map((a: any) => a.type)).toEqual(['Sign-on', 'Fadder', 'Coffee', 'Fadder', 'Coffee', 'Fadder', 'Coffee', 'Instruktør']);
  193 |   }
  194 |   await page.getByRole('button', { name: 'Rett eller legg til opplysninger' }).click();
  195 |   const checkEditor = async () => {
  196 |     await expect(page.locator('.correction-marker')).toHaveCount(0);
  197 |     await expect(page.getByLabel('Aktivitetstype', { exact: true })).toHaveCount(count);
  198 |     await expect(page.locator('details.source-disclosure')).not.toHaveAttribute('open');
  199 |     await expect(page.getByLabel('Buss/vogn', { exact: true })).toHaveValue('');
  200 |     if (number === 8) {
  201 |       await expect(page.getByLabel('Vognløp fra aktivitet 14', { exact: true })).toHaveValue('960176');
  202 |       await expect(page.getByLabel('Vognløp fra aktivitet 21', { exact: true })).toHaveValue('CAR - 1');
  203 |       await expect(page.getByLabel('Aktivitetstype', { exact: true }).nth(20)).toHaveValue('CAR');
  204 |       await expect(page.getByLabel('Aktivitetstype', { exact: true }).nth(21)).toHaveValue('Tomkjøring med CAR');
  205 |     } else {
  206 |       await expect(page.getByLabel('Aktivitetstype', { exact: true }).nth(1)).toHaveValue('Fadder');
  207 |       await expect(page.getByLabel('Aktivitetstype', { exact: true }).nth(7)).toHaveValue('Instruktør');
  208 |     }
  209 |   };
  210 |   await checkEditor();
  211 |   let saved: any;
  212 |   await page.route('**:18326/drafts', async route => {
  213 |     if (route.request().method() !== 'POST') return route.continue();
  214 |     const response = await route.fetch(); saved = await response.json(); await route.fulfill({ response });
  215 |   });
  216 |   await editor(page); await page.getByRole('button', { name: 'Lagre utkast', exact: true }).click();
  217 |   await expect(page.getByText('Lagret. Versjon 1.', { exact: true })).toBeVisible();
  218 |   expect(saved.draft).toEqual(facts);
  219 |   await page.reload();
  220 |   await page.getByRole('button', { name: new RegExp(`Åpne 2030-01-${number === 8 ? '10' : '14'}`) }).first().click();
  221 |   await checkEditor();
  222 |   expect(await (await page.request.get('http://127.0.0.1:18326/drafts/' + saved.id)).json()).toEqual(saved);
  223 |   await page.getByRole('group', { name: `Aktivitet ${number === 8 ? 22 : 2}`, exact: true }).screenshot({ path: `../tmp/story124/20261028T141845088376Z-a0cfe7e7/captures/11-2-regression-10-1-example-${number}-activity.png` });
  224 | });
  225 | for (const width of [768, 1440]) test(`keyboard review separate adoption save recovery reopen at ${width}px`, async ({ page }) => {
  226 |   await page.setViewportSize({ width, height: 1100 });
  227 |   await login(page); await upload(page);
  228 |   const disclosure = page.getByText('Vis alle kildefakta fra PDF', { exact: true }); if (await disclosure.isVisible()) await disclosure.click();
  229 |   const facts = page.getByRole('region', { name: 'Kildefakta fra PDF' });
  230 |   await expect(facts).toContainText('Kildestart');
  231 |   await expect(facts).toContainText('N (side 1, kolonne 1, linje 3)');
  232 |   await expect(facts).toContainText('side 1, overskrift, felt Tjenestedato');
  233 |   await expect(facts).toContainText('Avledningsgrunnlag per kalenderfelt');
  234 |   await expect(facts).toContainText('aktivitet 1: Startklokke, overskrift: Tjenestedato');
  235 |   await expect(facts).toContainText('entydig tidspunkt innenfor oppgitt skiftintervall');
  236 |   await expect(facts).not.toContainText('Synthetic Driver');
  237 |   expect(await page.getByLabel('Velg tekst-PDF', { exact: true }).inputValue()).toBe('');
  238 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  239 |   await page.screenshot({ path: `../tmp/story124/20261028T141845088376Z-a0cfe7e7/captures/11-2-regression-10-1-${width}.png`, fullPage: true });
  240 |   await page.getByRole('button', { name: 'Rett eller legg til opplysninger' }).focus(); await page.keyboard.press('Enter');
  241 |   await expect(page.getByRole('heading', { name: 'Nytt manuelt utkast' })).toBeFocused();
  242 |   await expect(page.getByLabel('Buss/vogn', { exact: true })).toHaveValue('');
  243 |   let accepted: any;
  244 |   await page.route('**:18326/drafts', async route => {
  245 |     if (route.request().method() !== 'POST') return route.continue();
  246 |     accepted = await (await route.fetch()).json(); await route.abort();
  247 |   });
  248 |   await editor(page); await page.getByRole('button', { name: 'Lagre utkast', exact: true }).click();
> 249 |   await expect(page.getByText('Lagring er uavklart.', { exact: false })).toBeVisible();
      |                                                                          ^ Error: expect(locator).toBeVisible() failed
  250 |   await page.unroute('**:18326/drafts');
  251 |   await page.getByRole('button', { name: 'Kontroller lagringsforsøket' }).click();
  252 |   await expect(page.getByText('Lagret. Versjon 1.', { exact: true })).toBeVisible();
  253 |   await page.getByLabel('Vognløp', { exact: true }).fill('0007');
  254 |   page.once('dialog', d => d.accept()); await editor(page); await page.getByRole('button', { name: 'Forkast endringer' }).click();
  255 |   await expect(page.getByLabel('Vognløp', { exact: true })).toHaveValue('');
  256 |   await page.reload();
  257 |   await preparation(page); await page.getByRole('button', { name: /Åpne 2030-01-01/ }).first().click();
  258 |   expect(await (await page.request.get('http://127.0.0.1:18326/drafts/' + accepted.id)).json()).toEqual(accepted);
  259 |   await expect(page.locator('details.source-disclosure')).not.toHaveAttribute('open');
  260 |   await page.getByText('Vis kildefakta fra PDF', { exact: true }).click();
  261 |   await expect(page.getByRole('region', { name: 'Kildefakta fra PDF' })).toContainText('Kildestart');
  262 |   expect(await page.evaluate(async () => [localStorage.length, sessionStorage.length, (await indexedDB.databases()).length])).toEqual([0, 0, 0]);
  263 | });
  264 | 
  265 | test('failed review keeps editor and edit protection guards separate adoption', async ({ page }) => {
  266 |   await login(page);
  267 |   await editor(page); await page.getByLabel('Buss/vogn', { exact: true }).fill('Earlier-001');
  268 |   await preparation(page); await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles({ name: 'broken.pdf', mimeType: 'application/pdf', buffer: Buffer.from('%PDF-corrupt') });
  269 |   await expect(page.getByText('PDF-en kunne ikke tolkes.', { exact: false })).toBeVisible();
  270 |   await expect(page.getByLabel('Buss/vogn', { exact: true })).toHaveValue('Earlier-001');
  271 |   await page.screenshot({ path: '../tmp/story124/20261028T141845088376Z-a0cfe7e7/captures/11-2-regression-10-1-error.png', fullPage: true });
  272 |   await upload(page);
  273 |   page.once('dialog', d => d.dismiss()); await page.getByRole('button', { name: 'Rett eller legg til opplysninger' }).click();
  274 |   await expect(page.getByLabel('Buss/vogn', { exact: true })).toHaveValue('Earlier-001');
  275 |   await expect(page.getByRole('button', { name: 'Rett eller legg til opplysninger' })).toBeVisible();
  276 |   page.once('dialog', d => d.accept()); await page.getByRole('button', { name: 'Rett eller legg til opplysninger' }).click();
  277 |   await expect(page.getByLabel('Buss/vogn', { exact: true })).toHaveValue('');
  278 | });
  279 | 
  280 | test('cancel and logout discard late replies and raw selection', async ({ page }) => {
  281 |   await login(page);
  282 |   await editor(page); await page.getByLabel('Buss/vogn', { exact: true }).fill('Earlier');
  283 |   let release!: () => void;
  284 |   const gate = new Promise<void>(resolve => { release = resolve; });
  285 |   await page.route('**:18326/imports/pdf', async route => { const response = await route.fetch(); await gate; await route.fulfill({ response }).catch(() => {}); });
  286 |   await preparation(page); await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles({ name: 'synthetic.pdf', mimeType: 'application/pdf', buffer: pdf });
  287 |   await page.getByRole('button', { name: 'Avbryt import' }).click(); release();
  288 |   await expect(page.getByRole('button', { name: 'Rett eller legg til opplysninger' })).toHaveCount(0);
  289 |   await expect(page.getByLabel('Buss/vogn', { exact: true })).toHaveValue('Earlier');
  290 |   await page.unroute('**:18326/imports/pdf'); await upload(page);
  291 |   page.once('dialog', d => d.accept()); await page.getByRole('button', { name: 'Logg ut', exact: true }).click();
  292 |   await expect(page.getByRole('region', { name: 'Kildefakta fra PDF' })).toHaveCount(0);
  293 |   await expect(page.getByLabel('Velg tekst-PDF', { exact: true })).toHaveCount(0);
  294 | });
  295 | 
  296 | test('invalid metadata or HTML cannot become a review', async ({ page, context }) => {
  297 |   await login(page);
  298 |   let saves = 0;
  299 |   page.on('request', request => { if (request.method() === 'POST' && request.url() === 'http://127.0.0.1:18326/drafts') saves++; });
  300 |   async function responseRejected() {
  301 |     await expect(page.getByText('Serveren returnerte et svar som ikke kunne brukes.', { exact: false })).toBeVisible();
  302 |     await expect(page.getByText('PDF-en kunne ikke tolkes.', { exact: false })).toHaveCount(0);
  303 |     await expect(page.getByRole('button', { name: 'Rett eller legg til opplysninger' })).toHaveCount(0);
  304 |     expect(saves).toBe(0);
  305 |     const drafts = await context.request.get('http://127.0.0.1:18326/drafts');
  306 |     expect(drafts.status()).toBe(200); expect((await drafts.json()).drafts).toEqual([]);
  307 |   }
  308 |   await page.route('**:18326/imports/pdf', route => route.fulfill({ contentType: 'text/html', body: '<html>login</html>' }));
  309 |   await preparation(page); await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles({ name: 'synthetic.pdf', mimeType: 'application/pdf', buffer: pdf });
  310 |   await responseRejected();
  311 |   await page.unroute('**:18326/imports/pdf');
  312 |   await page.route('**:18326/imports/pdf', async route => { const value = await (await route.fetch()).json(); value.import_metadata.header.driver = 'forbidden'; await route.fulfill({ json: value }); });
  313 |   await preparation(page); await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles({ name: 'synthetic.pdf', mimeType: 'application/pdf', buffer: pdf });
  314 |   await responseRejected();
  315 | });
  316 | 
  317 | test('unknown uncertainty references keep code field column and line', async ({ page }) => {
  318 |   await login(page);
  319 |   await page.route('**:18326/imports/pdf', async route => {
  320 |     const value = await (await route.fetch()).json();
  321 |     value.import_metadata.unresolved.push({ code: 'future_source_issue', field: 'unknown_field', activity: 2, provenance: { page: 1, column: 2, line: 9, region: null, field: null } });
  322 |     await route.fulfill({ json: value });
  323 |   });
  324 |   await upload(page);
  325 |   await page.getByText('Vis alle kildefakta fra PDF', { exact: true }).click();
  326 |   await expect(page.getByRole('region', { name: 'Kildefakta fra PDF' })).toContainText('Aktivitet 2: Ukjent kildeusikkerhet (future_source_issue) (unknown_field) · side 1, kolonne 2, linje 9');
  327 | });
  328 | 
  329 | for (const state of ['hidden', 'expired']) test(`delayed import is discarded after ${state} access revalidation`, async ({ page }) => {
  330 |   await login(page);
  331 |   await editor(page); await page.getByLabel('Buss/vogn', { exact: true }).fill('Earlier-private');
  332 |   let release!: () => void, started!: () => void;
  333 |   const gate = new Promise<void>(resolve => { release = resolve; });
  334 |   const accepted = new Promise<void>(resolve => { started = resolve; });
  335 |   await page.route('**:18326/imports/pdf', async route => { const response = await route.fetch(); started(); await gate; await route.fulfill({ response }).catch(() => {}); });
  336 |   await preparation(page); await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles({ name: 'synthetic.pdf', mimeType: 'application/pdf', buffer: pdf });
  337 |   await accepted;
  338 |   if (state === 'expired') python(`with database() as conn:\n conn.execute("UPDATE sessions SET created_at=statement_timestamp()-interval '14 days',expires_at=statement_timestamp() WHERE owner IN (SELECT id FROM accounts WHERE username=%s)", (${JSON.stringify(username)},))\n`);
  339 |   else await page.route('**:18326/auth/session', route => route.abort());
  340 |   await page.evaluate(() => {
  341 |     Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'hidden' }); document.dispatchEvent(new Event('visibilitychange'));
  342 |     Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'visible' }); document.dispatchEvent(new Event('visibilitychange'));
  343 |   });
  344 |   if (state === 'expired') await expect(page.getByLabel('Brukernavn', { exact: true })).toBeVisible();
  345 |   else await expect(page.getByRole('button', { name: 'Kontroller tilgang igjen' })).toBeEnabled();
  346 |   release();
  347 |   await expect(page.getByRole('button', { name: 'Rett eller legg til opplysninger' })).toHaveCount(0);
  348 |   await expect(page.getByRole('region', { name: 'Kildefakta fra PDF' })).toHaveCount(0);
  349 |   if (state === 'expired') await expect(page.getByLabel('Buss/vogn', { exact: true })).toHaveCount(0);
```