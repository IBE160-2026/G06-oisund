# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: shift-preparation.spec.ts >> disappearing occurrence selector restores focus to an input in the same saved time field
- Location: .story124-tests\shift-preparation.spec.ts:263:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "2030-10-27T02:30:00+02:00"
Received: "2030-10-27T02:30+02:00"
```

# Test source

```ts
  177 | });
  178 | test('tablet first save retains open source details, viewport and replacement time-input keyboard focus', async ({ page, context }, info) => {
  179 |   await page.setViewportSize({ width: 768, height: 1000 }); await loginAndImport(page); await button(page, 'Rett eller legg til opplysninger').click();
  180 |   const details = page.locator('details.source-disclosure'); await details.locator('summary').click();
  181 |   const time = page.getByLabel('Starttid', { exact: true }).first(); await time.fill('06:51');
  182 |   await expect(button(page, 'Lagre utkast')).toBeEnabled(); await time.focus();
  183 |   const position = await page.evaluate(() => scrollY); expect(position).toBeGreaterThan(1000);
  184 |   await page.keyboard.press('Enter');
  185 |   await expect(page.getByRole('status', { name: 'Lagringsstatus' })).toHaveText('Lagret. Versjon 1.');
  186 |   await expect(details).toHaveAttribute('open', ''); await expect(time).toBeFocused();
  187 |   expect(Math.abs(await page.evaluate(() => scrollY) - position)).toBeLessThan(100);
  188 |   await expect(time).toHaveValue(/^06:51(:00)?$/);
  189 |   const saved = await fullDraft(context, (await drafts(context))[0].id); expect(saved.draft.activities[0].start).toContain('T06:51');
  190 |   await page.screenshot({ path: info.outputPath('tablet-time-focus-after-first-save.png') });
  191 | });
  192 | for (const stage of ['review', 'confirmation']) test(`competing revision before ${stage} is rejected and current revision remains reachable`, async ({ page, context }) => {
  193 |   await loginAndImport(page); await button(page, 'Rett eller legg til opplysninger').click(); await button(page, 'Lagre utkast').click();
  194 |   await expect(page.getByRole('status', { name: 'Lagringsstatus' })).toHaveText('Lagret. Versjon 1.');
  195 |   const saved = await fullDraft(context, (await drafts(context))[0].id);
  196 |   if (stage === 'confirmation') { await button(page, 'Gjennomgå lagret utkast').click(); await expect(page.getByRole('region', { name: 'Gjennomgått versjon' })).toBeVisible(); }
  197 |   const operation = await post(context, '/draft-operations', { draft_id: saved.id });
  198 |   const latest = await post(context, '/drafts/' + saved.id, { operation_id: operation.operation_id, expected_revision: 1, draft: { ...saved.draft, physical_bus: 'SYN-COMPETING' } }); expect(latest.revision).toBe(2);
  199 |   if (stage === 'review') await button(page, 'Gjennomgå lagret utkast').click();
  200 |   else {
  201 |     const review = page.getByRole('region', { name: 'Gjennomgått versjon' });
  202 |     for (const select of await review.getByRole('combobox').all()) await select.selectOption('manual');
  203 |     for (const box of await review.getByRole('checkbox').all()) await box.check();
  204 |     await button(page, 'Bekreft gjennomgått plan').click();
  205 |   }
  206 |   await expect(page.getByRole('status', { name: 'Bekreftelsesstatus' })).toContainText('Utkastet er endret');
  207 |   await expect(page.getByRole('region', { name: 'Gjennomgått versjon' })).toHaveCount(0);
  208 |   expect((await (await context.request.get(API + '/workdays')).json()).workdays).toHaveLength(0);
  209 |   await preparation(page); await button(page, 'Oppdater listen').click(); await button(page, `Åpne ${saved.draft.service_date} · versjon 2`).click();
  210 |   await expect(page.getByLabel('Buss/vogn', { exact: true })).toHaveValue('SYN-COMPETING'); await button(page, 'Gjennomgå lagret utkast').click();
  211 |   await expect(page.getByRole('region', { name: 'Gjennomgått versjon' })).toContainText('Lagret versjon 2');
  212 | });
  213 | test('approval navigation returns from a clean notice registry to visible saved decisions', async ({ page }) => {
  214 |   await loginAndImport(page); await button(page, 'Alt stemmer – lagre og fortsett').click();
  215 |   await expect(page.getByRole('region', { name: 'Gjennomgått versjon' })).toBeVisible();
  216 |   await button(page, 'Manuelt vedlikeholdte avvik').click();
  217 |   await expect(page.getByRole('heading', { name: 'Gjennomgå og bekreft', exact: true })).toBeHidden();
  218 |   await button(page, 'Til godkjenning').click();
  219 |   await expect(page.getByRole('heading', { name: 'Gjennomgå og bekreft', exact: true })).toBeVisible();
  220 |   await expect(page.getByRole('region', { name: 'Gjennomgått versjon' })).toBeVisible();
  221 |   await expect(button(page, 'Prøv gjennomgang på nytt')).toHaveCount(0);
  222 | });
  223 | 
  224 | test('held review is deduplicated while leaving and returning to approval', async ({ page }) => {
  225 |   await loginAndImport(page); await button(page, 'Rett eller legg til opplysninger').click(); await button(page, 'Lagre utkast').click();
  226 |   await expect(page.getByRole('status', { name: 'Lagringsstatus' })).toHaveText('Lagret. Versjon 1.');
  227 |   let release!: () => void, entered!: () => void, reviews = 0;
  228 |   const held = new Promise<void>(resolve => { release = resolve; }), started = new Promise<void>(resolve => { entered = resolve; });
  229 |   await page.route('**:18326/workday-reviews', async route => { reviews++; const response = await route.fetch(); entered(); await held; await route.fulfill({ response }); });
  230 |   try {
  231 |     await button(page, 'Gjennomgå lagret utkast').click(); await started;
  232 |     await editor(page); await button(page, 'Gjennomgå lagret utkast').click();
  233 |     expect(reviews).toBe(1); release();
  234 |     await expect(page.getByRole('region', { name: 'Gjennomgått versjon' })).toBeVisible(); await page.waitForLoadState('networkidle');
  235 |     expect(reviews).toBe(1); await expect(button(page, 'Bekreft gjennomgått plan')).toBeDisabled();
  236 |   } finally { release(); }
  237 | });
  238 | test('classification decision exposes its source code dates times and places while full facts stay collapsed', async ({ page, context }) => {
  239 |   await loginAndImport(page);
  240 |   const operation = await post(context, '/draft-operations', {});
  241 |   const saved = await post(context, '/drafts', { operation_id: operation.operation_id, expected_revision: 0, draft: { service_date: '2030-02-08', physical_bus: null, activities: [{ id: crypto.randomUUID(), type: 'SYN-UNKNOWN', raw_code: 'SYN-CODE-REQUIRED', start: '2030-02-08T23:50:00+01:00', end: '2030-02-09T00:10:00+01:00', from_place: 'Syntetisk startsted', to_place: 'Syntetisk endested' }] } });
  242 |   await preparation(page); await button(page, 'Oppdater listen').click(); await button(page, `Åpne ${saved.draft.service_date} · versjon 1`).click(); await button(page, 'Gjennomgå lagret utkast').click();
  243 |   const decision = page.locator('.classification-decision'); await expect(decision).toBeVisible();
  244 |   for (const text of ['SYN-CODE-REQUIRED', 'SYN-UNKNOWN', '08.02.2030', '23:50', '09.02.2030', '00:10', 'Syntetisk startsted', 'Syntetisk endested']) await expect(decision).toContainText(text);
  245 |   await expect(decision.getByRole('combobox')).toHaveValue(''); await expect(decision.getByRole('combobox')).toHaveAttribute('aria-describedby', /classification-context-/);
  246 |   await expect(page.getByText('Vis alle opplysninger i lagret versjon', { exact: true }).locator('..')).not.toHaveAttribute('open');
  247 |   await expect(button(page, 'Bekreft gjennomgått plan')).toBeDisabled();
  248 | });
  249 | test('fresh direct terminal failure with prior selection retains imported proposals and prior saved facts', async ({ page, context }) => {
  250 |   await loginAndImport(page); await button(page, 'Alt stemmer – lagre og fortsett').click();
  251 |   await expect(page.getByRole('region', { name: 'Gjennomgått versjon' })).toBeVisible();
  252 |   const original = await fullDraft(context, (await drafts(context))[0].id); await preparation(page);
  253 |   await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles('../Eksempelfiler/Testskift-C.pdf'); await expect(button(page, 'Alt stemmer – lagre og fortsett')).toBeVisible();
  254 |   await page.route('**:18326/drafts', route => route.request().method() === 'POST' ? route.fulfill({ status: 410, json: { detail: 'Lagringsforsøket er utløpt.' } }) : route.continue());
  255 |   await button(page, 'Alt stemmer – lagre og fortsett').click();
  256 |   await expect(page.getByRole('status', { name: 'Direkte lagringsstatus' })).toContainText('Lokale inndata er beholdt');
  257 |   await expect(page.getByRole('status', { name: 'Direkte lagringsstatus' })).not.toContainText('Private felt fra det utløpte utkastet er fjernet');
  258 |   await expect(page.locator('.draft-form')).toBeHidden(); await button(page, 'Rett eller legg til opplysninger').click();
  259 |   await expect(page.getByLabel('Tjenestedato', { exact: true })).toHaveValue('2030-02-08');
  260 |   await expect(page.getByLabel('Starttid', { exact: true }).first()).toHaveValue(/^22:10(:00)?$/);
  261 |   await expect(button(page, 'Lagre utkast')).toBeDisabled(); expect(await drafts(context)).toHaveLength(1); expect(await fullDraft(context, original.id)).toEqual(original);
  262 | });
  263 | test('disappearing occurrence selector restores focus to an input in the same saved time field', async ({ page, context }) => {
  264 |   await loginAndImport(page);
  265 |   const saved = await post(context, '/drafts', { operation_id: (await post(context, '/draft-operations', {})).operation_id, expected_revision: 0, draft: { service_date: '2030-10-27', physical_bus: null, activities: [{ id: crypto.randomUUID(), type: 'manual', start: '2030-10-27T01:30:00+02:00', end: '2030-10-27T03:30:00+01:00' }] } });
  266 |   await preparation(page); await button(page, 'Oppdater listen').click(); await button(page, `Åpne ${saved.draft.service_date} · versjon 1`).click();
  267 |   await page.getByLabel('Starttid', { exact: true }).fill('02:30');
  268 |   const occurrence = page.getByRole('combobox', { name: 'Start: forekomst', exact: true }); await occurrence.selectOption({ label: 'Første forekomst' });
  269 |   await expect(button(page, 'Lagre utkast')).toBeEnabled(); await occurrence.focus(); const position = await page.evaluate(() => scrollY);
  270 |   // Submit the actual form while the occurrence control owns focus. The saved
  271 |   // replacement deliberately has no occurrence selector to restore by index.
  272 |   await occurrence.evaluate((control: HTMLSelectElement) => control.form!.requestSubmit());
  273 |   await expect(page.getByRole('status', { name: 'Lagringsstatus' })).toHaveText('Lagret. Versjon 2.');
  274 |   await expect(occurrence).toHaveCount(0);
  275 |   await expect(page.locator(`[data-draft-time="${saved.draft.activities[0].id}:start"] input`).first()).toBeFocused();
  276 |   expect(Math.abs(await page.evaluate(() => scrollY) - position)).toBeLessThan(100);
> 277 |   expect((await fullDraft(context, saved.id)).draft.activities[0].start).toBe('2030-10-27T02:30:00+02:00');
      |                                                                          ^ Error: expect(received).toBe(expected) // Object.is equality
  278 | });
  279 | test('direct admission failure retains compact import before a command exists and retries explicitly once', async ({ page, context }) => {
  280 |   await loginAndImport(page); let posts = 0;
  281 |   page.on('request', request => { if (request.method() === 'POST' && request.url() === API + '/drafts') posts++; });
  282 |   await page.route('**:18326/draft-operations', route => route.abort()); await button(page, 'Alt stemmer – lagre og fortsett').click();
  283 |   await expect(page.getByRole('status', { name: 'Direkte lagringsstatus' })).toContainText('Inndata er beholdt');
  284 |   await expect(page.locator('.draft-form')).toBeHidden(); await expect(button(page, 'Kontroller lagringsforsøket')).toHaveCount(0);
  285 |   expect(await drafts(context)).toEqual([]); expect(posts).toBe(0);
  286 |   await page.unroute('**:18326/draft-operations'); await button(page, 'Lagre import og prøv igjen').click();
  287 |   await expect(page.getByRole('region', { name: 'Gjennomgått versjon' })).toBeVisible();
  288 |   expect(await drafts(context)).toHaveLength(1); expect(posts).toBe(1); assertIndependentFacts((await fullDraft(context, (await drafts(context))[0].id)).draft);
  289 | });
  290 | 
```