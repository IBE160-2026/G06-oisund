# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: complete-user-flow.spec.ts >> real two-document journey A: explicit correction notice tab restore and ended recap
- Location: .story124-tests\complete-user-flow.spec.ts:66:3

# Error details

```
Test timeout of 240000ms exceeded.
```