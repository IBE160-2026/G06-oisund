import { test, expect, openedPlan, API, post, randomUUID, setup, beforeUnload } from './private-activity-helpers';
import type { Page, BrowserContext } from '@playwright/test';

setup();
test.use({ actionTimeout: 15000 });
type Resource = 'bus' | 'selection';
async function conflicted(page: Page, context: BrowserContext, resource: Resource) {
  const { plan, activities } = await openedPlan(page, context);
  const path = '/workdays/' + plan.id + (resource === 'bus' ? '/physical-bus' : '/selection');
  const scope = page.getByRole('region', { name: resource === 'bus' ? 'Fysisk buss' : 'Aktivitetsvalg', exact: true });
  const load = scope.getByRole('button', { name: resource === 'bus' ? 'Last inn lagret buss' : 'Last inn lagret aktivitetsvalg', exact: true });
  const command = (revision: number, third: boolean) => ({ operation_id: randomUUID(), expected_revision: revision, ...(resource === 'bus' ? { physical_bus: third ? 'Synthetic current C' : 'Synthetic comparison B' } : { activity_id: activities[third ? 2 : 0].id }) });
  if (resource === 'bus') await scope.getByLabel('Fysisk buss', { exact: true }).fill('Synthetic local proposal A');
  await post(context, path, command(0, false));
  await page.getByRole('button', { name: resource === 'bus' ? 'Lagre fysisk buss' : 'Velg aktivitet 2', exact: true }).click();
  await expect(load).toBeEnabled();
  if (resource === 'bus') await expect(scope.getByLabel('Fysisk buss', { exact: true })).toHaveValue('Synthetic local proposal A');
  else await expect(scope.getByText(/^Lokalt forslag/)).toContainText('24');
  const c = await post(context, path, command(1, true));
  let reads = 0, writes = 0;
  page.on('request', request => { if (request.url() === API + path) { if (request.method() === 'GET') reads++; if (request.method() === 'POST') writes++; } });
  return { plan, activities, path, scope, load, c: c.result, reads: () => reads, writes: () => writes };
}
async function proposalRetained(page: Page, resource: Resource, scope: any) {
  if (resource === 'bus') await expect(scope.getByLabel('Fysisk buss', { exact: true })).toHaveValue('Synthetic local proposal A');
  else await expect(scope.getByText(/^Lokalt forslag/)).toContainText('24');
  expect(await beforeUnload(page)).toBe(true);
}

for (const resource of ['bus', 'selection'] as const) {
  test(`${resource}: adopting comparison reads actual newer C without another write`, async ({ page, context }) => {
    const state = await conflicted(page, context, resource);
    await state.load.click();
    await expect.poll(state.reads).toBe(1);
    if (resource === 'bus') await expect(state.scope.getByLabel('Fysisk buss', { exact: true })).toHaveValue('Synthetic current C');
    else {
      await expect(state.scope.getByText(/^Manuelt valgt/)).toContainText('Aktivitet 3');
      await expect(state.scope.getByText(/^Lokalt forslag/)).toHaveCount(0);
    }
    expect(state.writes()).toBe(0);
    expect(await beforeUnload(page)).toBe(false);
    expect(await (await context.request.get(API + state.path)).json()).toEqual(state.c);
  });

  for (const failure of ['unavailable', 'regressed', 'changed-equal-revision', 'expired-timestamp', 'denied', 'unauthorized'] as const) {
    test(`${resource}: ${failure} fresh adoption never replaces local proposal with cached comparison`, async ({ page, context }) => {
      const state = await conflicted(page, context, resource);
      await page.route('**:18326' + state.path, async route => {
        if (failure === 'unavailable') return route.fulfill({ status: 503, json: { detail: 'Synthetic unavailable current read' } });
        if (failure === 'denied') return route.fulfill({ status: 410, json: { detail: 'Tilgangen ble avvist.' } });
        if (failure === 'unauthorized') return route.fulfill({ status: 401, json: { detail: 'Økten er utløpt.' } });
        const value = { ...state.c, ...(failure === 'expired-timestamp' ? { expires_at: '2000-01-01T00:00:00+00:00' } : { revision: failure === 'regressed' ? 0 : 1 }) };
        await route.fulfill({ json: value });
      });
      await state.load.click();
      await expect.poll(state.reads).toBe(1);
      expect(state.writes()).toBe(0);
      if (failure === 'unauthorized') {
        await expect(page.getByRole('heading', { name: 'Logg inn', exact: true })).toBeVisible();
        await expect(state.scope).toHaveCount(0);
      } else {
        await proposalRetained(page, resource, state.scope);
        // Retry remains reachable even when current authority has been denied.
        await expect(state.load).toBeEnabled();
        await page.unroute('**:18326' + state.path);
        await state.load.click();
        await expect.poll(state.reads).toBe(2);
        if (resource === 'bus') await expect(state.scope.getByLabel('Fysisk buss', { exact: true })).toHaveValue('Synthetic current C');
        else await expect(state.scope.getByText(/^Manuelt valgt/)).toContainText('Aktivitet 3');
        expect(await beforeUnload(page)).toBe(false);
        expect(state.writes()).toBe(0);
      }
    });
  }
}
