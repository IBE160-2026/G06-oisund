# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: private-selected-activity.spec.ts >> activity facts keyboard and enlargement 768 Day
- Location: .story124-tests\private-selected-activity.spec.ts:346:75

# Error details

```
Error: expect(received).toBeLessThan(expected)

Expected: < 450
Received:   480.5625
```

# Test source

```ts
  278 |   await page.getByRole('button', { name: 'Forberedelse og planlister', exact: true }).click();
  279 |   await page.getByRole('button', { name: 'Nytt utkast', exact: true }).click();
  280 |   await expect(page.getByRole('button', { name: 'Lagre utkast', exact: true })).toBeEnabled();
  281 |   await expect(page.getByLabel('Starttid', { exact: true })).toHaveCount(0);
  282 |   await page.getByRole('button', { name: 'Til den åpne planen', exact: true }).click();
  283 |   await expect(page.getByRole('region', { name: 'Dagsoversikt', exact: true })).toBeVisible();
  284 |   expect(await (await context.request.get(API + '/workdays/' + plan.id)).json()).toEqual(plan);
  285 | });
  286 | 
  287 | test('held selection acknowledgement cannot hide a bus proposal created while saving', async ({ page, context }) => {
  288 |   const { plan } = await openedPlan(page, context);
  289 |   let release!: () => void, entered!: () => void;
  290 |   const held = new Promise<void>(resolve => release = resolve), received = new Promise<void>(resolve => entered = resolve);
  291 |   await page.route('**:18326/workdays/' + plan.id + '/selection', async route => {
  292 |     if (route.request().method() === 'GET') return route.continue();
  293 |     const response = await route.fetch(); entered(); await held; await route.fulfill({ response });
  294 |   });
  295 |   try {
  296 |     await page.getByRole('button', { name: 'Velg aktivitet 1', exact: true }).click(); await received;
  297 |     const bus = page.getByRole('region', { name: 'Fysisk buss', exact: true }).getByLabel('Fysisk buss', { exact: true });
  298 |     await bus.fill('Behold bussforslaget'); await expect(bus).toBeFocused(); release();
  299 |     await expect(activityStatus(page)).toHaveText('Aktivitetsvalget er lagret.');
  300 |     await expect(selected(page)).toHaveCount(0); await expect(bus).toBeVisible(); await expect(bus).toHaveValue('Behold bussforslaget'); await expect(bus).toBeFocused();
  301 |     await expect(page.getByRole('button', { name: 'Åpne valgt aktivitet', exact: true })).toBeDisabled();
  302 |     await page.getByRole('button', { name: 'Avbryt bussendring', exact: true }).click();
  303 |     await activityScreen(page); await expect(selected(page)).toHaveAttribute('data-selected-activity-id', plan.draft.activities[0].id);
  304 |   } finally { release(); }
  305 | });
  306 | 
  307 | test('held upload completion retains edited draft and offers an explicit return to interpretation', async ({ page, context }) => {
  308 |   await openedPlan(page, context);
  309 |   const pdf = Buffer.from(python('import sys, base64\nsys.path.insert(0,"/app/tests")\nfrom test_pdf_import import synthetic_text_pdf\nprint(base64.b64encode(synthetic_text_pdf()).decode())\n').trim(), 'base64');
  310 |   let release!: () => void, entered!: () => void;
  311 |   const held = new Promise<void>(resolve => release = resolve), received = new Promise<void>(resolve => entered = resolve);
  312 |   await page.route('**:18326/imports/pdf', async route => { const response = await route.fetch(); entered(); await held; await route.fulfill({ response }); });
  313 |   try {
  314 |     await page.getByRole('button', { name: 'Forberedelse og planlister', exact: true }).click();
  315 |     await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles({ name: 'held-synthetic.pdf', mimeType: 'application/pdf', buffer: pdf }); await received;
  316 |     await page.getByRole('button', { name: 'Kontroller og rediger utkast', exact: true }).click();
  317 |     await page.getByLabel('Vognløp', { exact: true }).fill('Behold dette forslaget');
  318 |     release(); await expect(page.getByRole('button', { name: 'Fortsett importgjennomgang', exact: true, includeHidden: true })).toHaveCount(1);
  319 |     await expect(page.getByRole('heading', { name: 'Nytt manuelt utkast', exact: true })).toBeVisible();
  320 |     await expect(page.getByLabel('Vognløp', { exact: true })).toHaveValue('Behold dette forslaget');
  321 |     await page.getByRole('button', { name: 'Forberedelse og planlister', exact: true }).click();
  322 |     await page.getByRole('button', { name: 'Fortsett importgjennomgang', exact: true }).click();
  323 |     await expect(page.getByRole('button', { name: 'Rett eller legg til opplysninger', exact: true })).toBeVisible();
  324 |     await page.getByRole('button', { name: 'Kontroller og rediger utkast', exact: true }).click();
  325 |     await expect(page.getByLabel('Vognløp', { exact: true })).toHaveValue('Behold dette forslaget');
  326 |   } finally { release(); }
  327 | });
  328 | 
  329 | test('held parent plan read cannot pull the user away from an edited draft', async ({ page, context }) => {
  330 |   const { plan } = await openedPlan(page, context);
  331 |   let release!: () => void, entered!: () => void;
  332 |   const held = new Promise<void>(resolve => release = resolve), received = new Promise<void>(resolve => entered = resolve);
  333 |   await page.route('**:18326/workdays/' + plan.id, async route => { const response = await route.fetch(); entered(); await held; await route.fulfill({ response }); });
  334 |   try {
  335 |     await page.getByRole('button', { name: 'Forberedelse og planlister', exact: true }).click();
  336 |     await page.getByRole('button', { name: 'Åpne plan 2031-01-02 · versjon 1', exact: true }).click(); await received;
  337 |     await page.getByRole('button', { name: 'Kontroller og rediger utkast', exact: true }).click();
  338 |     await page.getByLabel('Vognløp', { exact: true }).fill('Ikke flytt dette utkastet'); release();
  339 |     await expect(page.locator('.private-confirmation')).toHaveAttribute('aria-busy', 'false');
  340 |     await expect(page.getByRole('heading', { name: 'Nytt manuelt utkast', exact: true })).toBeVisible();
  341 |     await expect(page.getByLabel('Vognløp', { exact: true })).toHaveValue('Ikke flytt dette utkastet');
  342 |     await expect(page.getByRole('region', { name: 'Dagsoversikt', exact: true })).toBeHidden();
  343 |   } finally { release(); }
  344 | });
  345 | 
  346 | for (const width of [768, 1024, 1440]) for (const night of [false, true]) test(`activity facts keyboard and enlargement ${width} ${night ? 'Night' : 'Day'}`, async ({ page, context }) => {
  347 |   await page.setViewportSize({ width, height: width === 1024 ? 768 : 1100 }); await openedPlan(page, context);
  348 |   if (night) await page.getByRole('button', { name: 'Nattmodus', exact: true }).click();
  349 |   await page.evaluate(() => { document.documentElement.style.fontSize = '200%'; });
  350 |   await page.getByRole('button', { name: 'Velg aktivitet 1', exact: true }).focus(); await page.keyboard.press('Enter');
  351 |   await expect(selected(page)).toBeVisible(); await expect(activityStatus(page)).toBeFocused();
  352 |   await expect(fact(page, 'Til')).toContainText('Fiktivt langt destinasjonsnavn');
  353 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  354 |   const measurements: object[] = [];
  355 |   for (const name of ['Neste aktivitet', 'Tilbake til dagen']) {
  356 |     const button = page.getByRole('button', { name, exact: true }); await button.focus(); await expect(button).toBeFocused();
  357 |     expect(await button.evaluate(el => el.getBoundingClientRect().height)).toBeGreaterThanOrEqual(58);
  358 |     const measured = await button.evaluate(el => {
  359 |       const light = (v: string) => (v.match(/[\d.]+/g) ?? []).slice(0, 3).map(Number).map(c => { c /= 255; return c <= .04045 ? c / 12.92 : ((c + .055) / 1.055) ** 2.4; }).reduce((sum, c, i) => sum + c * [.2126, .7152, .0722][i], 0);
  360 |       const ratio = (a: string, b: string) => (Math.max(light(a), light(b)) + .05) / (Math.min(light(a), light(b)) + .05);
  361 |       const bg = (node: Element): string => { const c = getComputedStyle(node).backgroundColor; return c === 'rgba(0, 0, 0, 0)' || c === 'transparent' ? node.parentElement ? bg(node.parentElement) : 'rgb(255,255,255)' : c; };
  362 |       const style = getComputedStyle(el);
  363 |       const detail = document.querySelector('.selected-activity')!;
  364 |       const text = [...detail.querySelectorAll('h3,p,dt,dd')].map(node => ratio(getComputedStyle(node).color, bg(node)));
  365 |       return { text: Math.min(...text), boundary: ratio(getComputedStyle(detail).borderInlineStartColor, bg(detail.parentElement!)), focus: ratio(style.outlineColor, bg(el.parentElement!)), focusWidth: parseFloat(style.outlineWidth) };
  366 |     });
  367 |     expect(measured.text).toBeGreaterThanOrEqual(4.5); expect(measured.boundary).toBeGreaterThanOrEqual(3);
  368 |     expect(measured.focus).toBeGreaterThanOrEqual(3); expect(measured.focusWidth).toBeGreaterThanOrEqual(2);
  369 |     measurements.push({ control: name, ...measured });
  370 |     await test.info().attach(`11-2-${width}-${night ? 'night' : 'day'}-${name}`, { body: JSON.stringify(measured), contentType: 'application/json' });
  371 |   }
  372 |   await page.getByRole('region', { name: 'Bekreftet plan', exact: true }).screenshot({ path: `../tmp/story124/20261028T145858001741Z-047aa4e1/captures/11-2-activity-${width}-${night ? 'night' : 'day'}.png` });
  373 |   for (const control of [fact(page, 'Planlagt slutt'), fact(page, 'Til'), page.getByRole('button', { name: 'Kontroller plantilgang og aktivitetsvalg', exact: true }), page.getByRole('button', { name: 'Tilbake til dagen', exact: true })]) { await control.scrollIntoViewIfNeeded(); await expect(control).toBeInViewport(); }
  374 |   await page.evaluate(() => window.scrollTo(0, 0));
  375 |   await page.screenshot({ path: `../tmp/story124/20261028T145858001741Z-047aa4e1/captures/11-2-activity-viewport-enlarged-${width}-${night ? 'night' : 'day'}.png` });
  376 |   await page.setViewportSize({ width, height: width === 1024 ? 768 : 1100 });
  377 |   await page.evaluate(() => { document.documentElement.style.fontSize = ''; window.scrollTo(0, 0); });
> 378 |   expect(await fact(page, 'Planlagt start').evaluate(el => el.getBoundingClientRect().top)).toBeLessThan(450);
      |                                                                                             ^ Error: expect(received).toBeLessThan(expected)
  379 |   if (width === 1024) for (const endpoint of ['Fra', 'Til']) expect(await fact(page, endpoint).evaluate(el => el.getBoundingClientRect().bottom)).toBeLessThanOrEqual(768);
  380 |   await page.screenshot({ path: `../tmp/story124/20261028T145858001741Z-047aa4e1/captures/11-2-activity-viewport-${width}-${night ? 'night' : 'day'}.png` });
  381 |   writeFileSync(`../tmp/story124/20261028T145858001741Z-047aa4e1/captures/11-2-contrast-${width}-${night ? 'night' : 'day'}.json`, JSON.stringify(measurements, null, 2) + '\n');
  382 | });
  383 | 
```