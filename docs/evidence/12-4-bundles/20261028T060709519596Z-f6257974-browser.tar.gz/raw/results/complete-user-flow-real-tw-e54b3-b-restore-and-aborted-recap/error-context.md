# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: complete-user-flow.spec.ts >> real two-document journey C: explicit correction notice tab restore and aborted recap
- Location: .story124-tests\complete-user-flow.spec.ts:63:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "hidden"
Received: "visible"

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Test source

```ts
  5   | 
  6   | setup();
  7   | // Headed desktop automation is required for real background-tab visibility.
  8   | // Headless Chromium keeps all pages visible even when another target is focused.
  9   | test.use({ headless: false });
  10  | // Authored independently of the parser. Never regenerate these facts from an import.
  11  | const oracle = JSON.parse(readFileSync('../Eksempelfiler/Fasit-testskift.json', 'utf8').replace(/^\uFEFF/, '')).shifts;
  12  | const button = (page: Page, name: string) => page.getByRole('button', { name, exact: true });
  13  | async function json(context: BrowserContext, path: string) {
  14  |   const response = await context.request.get(API + path); expect(response.status()).toBe(200); return response.json();
  15  | }
  16  | async function login(page: Page) {
  17  |   await page.goto('/private');
  18  |   await page.getByLabel('Brukernavn', { exact: true }).fill(account.username);
  19  |   await page.getByLabel('Passord', { exact: true }).fill(account.password);
  20  |   await button(page, 'Logg inn').click();
  21  |   await expect(page.getByRole('heading', { name: 'Mine utkast', exact: true })).toBeVisible();
  22  | }
  23  | async function importAndSave(page: Page, context: BrowserContext, name: string) {
  24  |   const expected = oracle.find((value: any) => value.case === name);
  25  |   const events = expected.events.filter((value: any) => value.kind !== 'vehicle');
  26  |   const response = page.waitForResponse(r => r.url() === API + '/imports/pdf' && r.request().method() === 'POST');
  27  |   await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles('../Eksempelfiler/Testskift-' + name + '.pdf');
  28  |   const result = await response; expect(result.status()).toBe(200); const imported = await result.json();
  29  |   await expect(button(page, 'Bruk som separat nytt utkast')).toBeVisible();
  30  |   expect((await json(context, '/drafts')).drafts).toHaveLength(name === 'A' ? 0 : 1);
  31  |   expect(imported.activities).toHaveLength(events.length);
  32  |   for (let i = 0; i < events.length; i++) {
  33  |     const row = imported.activities[i], event = events[i];
  34  |     if (event.kind === 'movement') {
  35  |       expect([row.trip, row.line, row.from_place, row.to_place]).toEqual([event.trip_id, ['tom', 'CAR'].includes(event.line) ? null : event.line, event.stops[0].name, event.stops.at(-1).name]);
  36  |       expect(row.start.slice(0, 16)).toBe(event.stops[0].local_datetime);
  37  |       expect(row.end.slice(0, 16)).toBe(event.stops.at(-1).local_datetime);
  38  |     } else {
  39  |       expect(row.raw_code).toBe(event.label);
  40  |       expect(row.start?.slice(0, 16) ?? null).toBe(event.start_local);
  41  |       expect(row.end?.slice(0, 16) ?? null).toBe(event.end_local);
  42  |     }
  43  |   }
  44  |   expect(imported.vehicle_duty).toBe(expected.events.find((event: any) => event.kind === 'vehicle').vehicle);
  45  |   expect(imported.physical_bus).toBeNull();
  46  |   await button(page, 'Bruk som separat nytt utkast').click();
  47  |   const tripIndex = events.findIndex((event: any) => event.passenger_service);
  48  |   const trip = page.locator('#activity-' + imported.activities[tripIndex].id);
  49  |   await trip.getByLabel('Til sted', { exact: true }).fill('Syntetisk manuelt korrigert endeholdeplass');
  50  |   await trip.getByLabel('Kilde / manuell rettelse', { exact: true }).fill('Manuelt kontrollert mot syntetisk oppgave');
  51  |   await page.getByLabel('Buss/vogn', { exact: true }).fill('SYN-124');
  52  |   const savedReply = page.waitForResponse(r => r.url() === API + '/drafts' && r.request().method() === 'POST');
  53  |   await button(page, 'Lagre utkast').click();
  54  |   const savedResponse = await savedReply; expect(savedResponse.status()).toBe(200); const saved = await savedResponse.json();
  55  |   expect(saved.draft.activities[tripIndex].to_place).toBe('Syntetisk manuelt korrigert endeholdeplass');
  56  |   expect(saved.draft.activities[tripIndex].direction).toBeNull();
  57  |   expect(saved.draft.import_metadata).toEqual(imported.import_metadata);
  58  |   expect(saved.draft.physical_bus).toBe('SYN-124');
  59  |   return { saved, imported, expected, tripIndex };
  60  | }
  61  | 
  62  | for (const [name, action] of [['A', 'ended'], ['C', 'aborted']] as const) {
  63  |   test(`real two-document journey ${name}: explicit correction notice tab restore and ${action} recap`, async ({ page, context }) => {
  64  |     test.setTimeout(240000);
  65  |     await login(page);
  66  |     const a = await importAndSave(page, context, 'A');
  67  |     await button(page, 'Forberedelse og planlister').click();
  68  |     const c = await importAndSave(page, context, 'C');
  69  |     expect(c.saved.id).not.toBe(a.saved.id);
  70  |     expect(c.imported.activities.some((row: any) => row.end?.startsWith('2030-02-09'))).toBe(true);
  71  |     expect((await json(context, '/drafts')).drafts).toHaveLength(2);
  72  |     const chosen = name === 'A' ? a : c;
  73  |     await page.reload();
  74  |     await button(page, `Åpne ${chosen.saved.draft.service_date} · versjon 1`).click();
  75  |     const reopened = await json(context, '/drafts/' + chosen.saved.id); expect(reopened).toEqual(chosen.saved);
  76  |     await page.getByText('Vis kildefakta fra PDF', { exact: true }).click();
  77  |     await expect(page.getByRole('region', { name: 'Kildefakta fra PDF', exact: true })).toContainText(chosen.expected.shift_id);
  78  |     await button(page, 'Gjennomgå lagret utkast').click();
  79  |     const review = page.getByRole('region', { name: 'Gjennomgått versjon', exact: true });
  80  |     await expect(review).toBeVisible();
  81  |     await expect(button(page, 'Bekreft gjennomgått plan')).toBeDisabled();
  82  |     for (const checkbox of await review.getByRole('checkbox').all()) await checkbox.check();
  83  |     const confirmation = page.waitForResponse(r => r.url().endsWith('/confirm') && r.request().method() === 'POST');
  84  |     await button(page, 'Bekreft gjennomgått plan').click();
  85  |     const confirmedResponse = await confirmation; expect(confirmedResponse.status()).toBe(200); const plan = await confirmedResponse.json();
  86  |     expect(plan.source_draft_id).toBe(chosen.saved.id);
  87  |     expect(plan.draft.import_metadata).toEqual(chosen.imported.import_metadata);
  88  |     expect(plan.unknowns.some((unknown: any) => unknown.id.endsWith(':direction'))).toBe(true);
  89  |     await expect(page.getByText('Ingen aktivitet valgt', { exact: true })).toBeVisible();
  90  |     await expect(page.getByText('Ikke startet', { exact: true })).toBeVisible();
  91  | 
  92  |     await button(page, 'Manuelt vedlikeholdte avvik').click();
  93  |     await expect(button(page, 'Registrer avvik')).toBeEnabled(); await button(page, 'Registrer avvik').click();
  94  |     const title = 'Syntetisk flerlinjeavvik 12.4 ' + name;
  95  |     const description = 'Første tidsvindu: omkjøring ved Måneglimt.\nAndre tidsvindu: bruk midlertidig holdeplass.';
  96  |     await page.getByLabel('Tittel', { exact: true }).fill(title);
  97  |     await page.getByLabel('Detaljert forklaring', { exact: true }).fill(description);
  98  |     await page.getByLabel('Linjer fra kilden (kommaseparert)', { exact: true }).fill('731, 81');
  99  |     await page.getByLabel('Gyldig tildato', { exact: true }).fill('2030-02-10');
  100 |     await expect(page.getByRole('region', { name: 'Lagringskrav' })).not.toContainText('ufullstendig');
  101 |     // A real second tab receives browser focus. Capture native visibility events,
  102 |     // rather than dispatching a fabricated visibilitychange or mocking auth.
  103 |     await page.evaluate(() => { (window as any).__story124Visibility = []; document.addEventListener('visibilitychange', () => (window as any).__story124Visibility.push(document.visibilityState)); });
  104 |     const other = await context.newPage(); await other.goto('/demo.html'); await other.bringToFront();
> 105 |     await expect.poll(() => page.evaluate(() => document.visibilityState)).toBe('hidden');
      |                                                                            ^ Error: expect(received).toBe(expected) // Object.is equality
  106 |     await page.bringToFront();
  107 |     await expect.poll(() => page.evaluate(() => document.visibilityState)).toBe('visible');
  108 |     await expect(page.getByRole('status', { name: 'Tilgangsstatus', exact: true })).toHaveText('Du er logget inn.');
  109 |     await expect(page.getByLabel('Tittel', { exact: true })).toHaveValue(title);
  110 |     await expect(page.getByLabel('Detaljert forklaring', { exact: true })).toHaveValue(description);
  111 |     const visibility = await page.evaluate(() => (window as any).__story124Visibility);
  112 |     expect(visibility).toContain('hidden'); expect(visibility).toContain('visible');
  113 |     expect((await json(context, '/notices')).notices).toHaveLength(0);
  114 |     await other.close();
  115 |     await button(page, 'Tilbake til avvik').click(); await button(page, 'Tilbake til ulagret avvik').click();
  116 |     await expect(page.getByLabel('Tittel', { exact: true })).toHaveValue(title);
  117 |     await button(page, 'Lagre avvik').click();
  118 |     await expect(page.getByRole('status', { name: 'Avviksstatus', exact: true })).toHaveText('Avviket er lagret.');
  119 |     const notices = (await json(context, '/notices')).notices;
  120 |     expect(notices).toHaveLength(1);
  121 |     expect(notices[0]).toMatchObject({ title, description, line_tags: ['731', '81'], valid_from: null, source_updated_at: null, checked_at: null, valid_until: '2030-02-10T23:59:59+01:00' });
  122 |     await button(page, 'Tilbake til dagen').click();
  123 |     await button(page, 'Les avvik for linjer og datoer').click();
  124 |     const reader = page.getByRole('region', { name: 'Avvik for linjer og datoer', exact: true });
  125 |     await reader.getByLabel('Bekreftet linje', { exact: true }).selectOption(name === 'A' ? '731' : '81');
  126 |     await reader.getByLabel('Planlagt kalenderdato (Oslo)', { exact: true }).selectOption(chosen.saved.draft.service_date);
  127 |     await expect(reader.locator('.notice-list summary')).toContainText(title);
  128 |     await reader.locator('.notice-list summary').click();
  129 |     await expect(reader).toContainText('Delvis kjent gyldighet');
  130 |     await expect(reader).toContainText('Kildens oppdateringstid er ukjent');
  131 |     await expect(reader).toContainText('Ikke kontrollert');
  132 |     await reader.getByRole('button', { name: 'Tilbake til dagen', exact: true }).click();
  133 |     await button(page, 'Velg aktivitet ' + (chosen.tripIndex + 1)).click(); await activityScreen(page);
  134 |     await expect(selected(page)).toContainText('Syntetisk manuelt korrigert endeholdeplass');
  135 |     await dayScreen(page); await button(page, 'Start skift').click(); await button(page, 'Bekreft skiftstart').click();
  136 |     await expect(shiftStatus(page)).toHaveText('Skiftstart er lagret.');
  137 |     await activityScreen(page);
  138 |     await page.getByLabel('Manuell aktivitetsstatus', { exact: true }).selectOption(action === 'ended' ? 'completed' : 'interrupted');
  139 |     await button(page, 'Lagre aktivitetsstatus').click();
  140 |     await expect(page.getByRole('status', { name: 'Aktivitetsstatus og avslutningsstatus' })).toHaveText('Aktivitetsstatusen er lagret.');
  141 |     await dayScreen(page); await button(page, action === 'ended' ? 'Avslutt skift' : 'Avbryt skift').click();
  142 |     await button(page, action === 'ended' ? 'Bekreft avslutning' : 'Bekreft avbrudd').click();
  143 |     await expect(page.getByRole('heading', { name: action === 'ended' ? 'Skift avsluttet' : 'Skift avbrutt', exact: true })).toBeVisible();
  144 |     const recap = await json(context, '/workdays/' + plan.id + '/recap');
  145 |     expect(recap.lifecycle.state).toBe(action);
  146 |     expect(recap.outcomes.outcomes.map((row: any) => row.outcome)).toEqual(chosen.saved.draft.activities.map((_: any, i: number) => i === chosen.tripIndex ? action === 'ended' ? 'completed' : 'interrupted' : 'unregistered'));
  147 |     expect(recap.bus.physical_bus).toBe('SYN-124');
  148 |     if (name === 'A') {
  149 |       if (process.env.COMPOSE_PROJECT_NAME !== 'ibe160-story124-tests') throw Error('Disposable project selection required');
  150 |       execFileSync('docker', ['compose', '-p', 'ibe160-story124-tests', '-f', 'compose.story124.yaml', 'restart', '--wait', 'private-db', 'private-api'], { cwd: '..', timeout: 90000 });
  151 |       expect(await json(context, '/workdays/' + plan.id + '/recap')).toEqual(recap);
  152 |     }
  153 |     await page.reload(); await button(page, `Åpne plan ${chosen.saved.draft.service_date} · versjon 1`).click();
  154 |     await expect(page.getByRole('heading', { name: action === 'ended' ? 'Skift avsluttet' : 'Skift avbrutt', exact: true })).toBeVisible();
  155 |     expect(await json(context, '/workdays/' + plan.id + '/recap')).toEqual(recap);
  156 |     expect((await json(context, '/notices')).notices).toEqual(notices);
  157 |     const storage = await page.evaluate(async () => ({ local: Object.keys(localStorage), session: Object.keys(sessionStorage), databases: (await indexedDB.databases()).length, caches: (await caches.keys()).length, workers: (await navigator.serviceWorker.getRegistrations()).length }));
  158 |     expect(storage.local.filter(key => key !== 'ibe160-theme')).toEqual([]);
  159 |     expect(storage).toMatchObject({ session: [], databases: 0, caches: 0, workers: 0 });
  160 |     await page.screenshot({ path: `../tmp/story124/20261028T060709519596Z-f6257974/captures/12-4-journey-${name}.png`, fullPage: true });
  161 |     writeFileSync(`../tmp/story124/20261028T060709519596Z-f6257974/captures/12-4-journey-${name}.json`, JSON.stringify({ synthetic: true, mockedApi: false, case: name, action, databaseAndApiRestart: name === 'A', nativeVisibilityEvents: visibility, draftIds: [a.saved.id, c.saved.id], planId: plan.id, recap, notices }, null, 2));
  162 |   });
  163 | }
  164 | 
```