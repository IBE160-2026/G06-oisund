# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: shift-preparation.spec.ts >> correct import saves explicitly and reaches distinct compact approval at 768px
- Location: .story124-tests\shift-preparation.spec.ts:33:34

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('region', { name: 'Gjennomgått versjon' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('region', { name: 'Gjennomgått versjon' }) with timeout 5000ms
  - waiting for getByRole('region', { name: 'Gjennomgått versjon' })

```

```yaml
- main:
  - button "Nattmodus"
  - text: "Visning: Dag"
  - paragraph: Privat tilgang
  - heading "Privat arbeidsrom" [level=1]
  - status "Tilgangsstatus": Du er logget inn.
  - region "Privat arbeidsrom":
    - region "Private utkast":
      - navigation "Plan og forberedelse":
        - button "Forberedelse og planlister"
        - button "Kontroller og rediger utkast"
        - button "Til godkjenning"
      - group
    - region "Bekreft plan":
      - status "Bekreftelsesstatus": Planlisten er oppdatert.
      - heading "Gjennomgå og bekreft" [level=2]
      - paragraph: Bekreftelse lagrer en egen plan. Planen utløper sju dager etter siste aktivitetsslutt. Gjennomgang gjelder bare den lagrede versjonen.
      - paragraph: Et utkast som allerede er brukt til bekreftelse krever et nytt, separat utkast for en ny plan.
      - button "Gjennomgå lagret utkast"
      - button "Manuelt vedlikeholdte avvik"
    - paragraph: Økten utløper 11.11.2026, 14:46.
    - button "Logg ut"
  - paragraph: Tilgang opprettes av den som drifter løsningen. Bruk arbeidsrommet mens du står stille.
  - link "Åpne fiktiv demo":
    - /url: /
```

# Test source

```ts
  1   | import { test, expect, API, account, setup } from './private-activity-helpers';
  2   | import { editor } from './private-screen-helpers';
  3   | import { readFileSync } from 'node:fs';
  4   | import type { Page, BrowserContext } from '@playwright/test';
  5   | setup();
  6   | const oracle = JSON.parse(readFileSync('../Eksempelfiler/Fasit-testskift.json', 'utf8').replace(/^\uFEFF/, '')).shifts.find((shift: any) => shift.case === 'A');
  7   | const button = (page: Page, name: string) => page.getByRole('button', { name, exact: true });
  8   | async function loginAndImport(page: Page) {
  9   |   await page.goto('/private');
  10  |   await page.getByLabel('Brukernavn', { exact: true }).fill(account.username);
  11  |   await page.getByLabel('Passord', { exact: true }).fill(account.password);
  12  |   await button(page, 'Logg inn').click();
  13  |   await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles('../Eksempelfiler/Testskift-A.pdf');
  14  |   await expect(button(page, 'Alt stemmer – lagre og fortsett')).toBeVisible();
  15  | }
  16  | async function drafts(context: BrowserContext) { const response = await context.request.get(API + '/drafts'); expect(response.ok()).toBe(true); return (await response.json()).drafts; }
  17  | async function fullDraft(context: BrowserContext, id: string) { const response = await context.request.get(API + '/drafts/' + id); expect(response.ok()).toBe(true); return response.json(); }
  18  | function assertIndependentFacts(content: any) {
  19  |   expect(content.service_date).toBe(oracle.date.split('/').reverse().join('-'));
  20  |   expect(content.import_metadata.header.shift_id).toBe(oracle.shift_id);
  21  |   expect(content.vehicle_duty).toBe(oracle.events.find((event: any) => event.kind === 'vehicle').vehicle);
  22  |   const events = oracle.events.filter((event: any) => event.kind !== 'vehicle');
  23  |   expect(content.activities).toHaveLength(events.length);
  24  |   for (const [index, event] of events.entries()) {
  25  |     const row = content.activities[index];
  26  |     const start = event.kind === 'movement' ? event.stops[0].local_datetime : event.start_local;
  27  |     const end = event.kind === 'movement' ? event.stops.at(-1).local_datetime : event.end_local;
  28  |     expect(Date.parse(row.start)).toBe(Date.parse(start + ':00+01:00'));
  29  |     expect(Date.parse(row.end)).toBe(Date.parse(end + ':00+01:00'));
  30  |     if (event.kind === 'movement') expect([row.trip, row.from_place, row.to_place]).toEqual([event.trip_id, event.stops[0].name, event.stops.at(-1).name]);
  31  |   }
  32  | }
  33  | for (const width of [768, 1440]) test(`correct import saves explicitly and reaches distinct compact approval at ${width}px`, async ({ page, context }, info) => {
  34  |   await page.setViewportSize({ width, height: 1000 }); await loginAndImport(page);
  35  |   expect(await drafts(context)).toEqual([]);
  36  |   await expect(page.getByText('Importsammendrag', { exact: true })).toBeVisible();
  37  |   await expect(page.getByRole('region', { name: 'Kildefakta fra PDF', includeHidden: true })).toBeHidden();
  38  |   await page.screenshot({ path: info.outputPath('import-summary.png'), fullPage: true });
  39  |   await button(page, 'Alt stemmer – lagre og fortsett').click();
> 40  |   const review = page.getByRole('region', { name: 'Gjennomgått versjon' }); await expect(review).toBeVisible();
      |                                                                                                  ^ Error: expect(locator).toBeVisible() failed
  41  |   await expect(page.getByRole('heading', { name: 'Rediger utkast', exact: true })).toBeHidden();
  42  |   await expect(review.getByText('Vis alle opplysninger i lagret versjon', { exact: true })).toBeVisible();
  43  |   const saved = await fullDraft(context, (await drafts(context))[0].id); assertIndependentFacts(saved.draft); expect(saved.revision).toBe(1);
  44  |   expect(await review.getByRole('checkbox').count()).toBeGreaterThan(0);
  45  |   for (const box of await review.getByRole('checkbox').all()) await expect(box).not.toBeChecked();
  46  |   await expect(button(page, 'Bekreft gjennomgått plan')).toBeDisabled();
  47  |   await page.screenshot({ path: info.outputPath('compact-approval.png'), fullPage: true });
  48  |   await review.getByText('Vis alle opplysninger i lagret versjon', { exact: true }).click();
  49  |   await expect(review).toContainText(oracle.start_place);
  50  |   for (const select of await review.getByRole('combobox').all()) await select.selectOption('manual');
  51  |   for (const box of await review.getByRole('checkbox').all()) await box.check();
  52  |   await button(page, 'Bekreft gjennomgått plan').click();
  53  |   await expect(page.getByRole('region', { name: 'Dagsoversikt', exact: true })).toBeVisible();
  54  |   await expect(button(page, 'Start skift')).toBeVisible();
  55  |   const bus = page.getByRole('region', { name: 'Fysisk buss', exact: true });
  56  |   await bus.getByLabel('Fysisk buss', { exact: true }).fill('SYN-ONLY-BUS');
  57  |   await bus.getByRole('button', { name: 'Lagre fysisk buss', exact: true }).click();
  58  |   await expect(bus.getByRole('status', { name: 'Bussstatus' })).toHaveText('Fysisk buss er lagret.');
  59  |   expect((await fullDraft(context, saved.id)).draft).toEqual(saved.draft);
  60  | });
  61  | test('corrections keep save position, bus refuses unrelated proposals, and time save can proceed directly', async ({ page, context }, info) => {
  62  |   await loginAndImport(page); await button(page, 'Rett eller legg til opplysninger').click();
  63  |   const destination = page.getByLabel('Til sted', { exact: true }).nth(1);
  64  |   await destination.fill('Syntetisk rettet endeholdeplass');
  65  |   await page.getByLabel('Buss/vogn', { exact: true }).fill('SYN-42');
  66  |   await button(page, 'Lagre buss/vogn').click();
  67  |   await expect(page.getByLabel('Buss i utkast', { exact: true })).toContainText('Andre opplysninger er også ulagret');
  68  |   expect(await drafts(context)).toEqual([]); await expect(destination).toHaveValue('Syntetisk rettet endeholdeplass');
  69  |   const save = button(page, 'Lagre utkast'); await save.scrollIntoViewIfNeeded(); await save.focus();
  70  |   const before = await page.evaluate(() => scrollY); expect(before).toBeGreaterThan(500);
  71  |   await page.keyboard.press('Enter');
  72  |   await expect(page.getByRole('status', { name: 'Lagringsstatus' })).toHaveText('Lagret. Versjon 1.');
  73  |   expect(Math.abs(await page.evaluate(() => scrollY) - before)).toBeLessThan(100); await expect(save).toBeFocused();
  74  |   await page.screenshot({ path: info.outputPath('saved-in-position.png') });
  75  |   const saved = await fullDraft(context, (await drafts(context))[0].id);
  76  |   expect(saved.draft.activities[1].to_place).toBe('Syntetisk rettet endeholdeplass'); expect(saved.draft.physical_bus).toBe('SYN-42');
  77  |   await page.getByLabel('Buss/vogn', { exact: true }).fill('SYN-43'); await button(page, 'Lagre buss/vogn').click();
  78  |   await expect(page.getByRole('status', { name: 'Lagringsstatus' })).toHaveText('Lagret. Versjon 2.');
  79  |   const busOnly = await fullDraft(context, saved.id); expect(busOnly.draft.activities).toEqual(saved.draft.activities); expect(busOnly.draft.physical_bus).toBe('SYN-43');
  80  |   const start = page.getByLabel('Starttid', { exact: true }).first(); await start.fill('06:51');
  81  |   await expect(save).toBeEnabled(); await save.click(); await expect(page.getByRole('status', { name: 'Lagringsstatus' })).toHaveText('Lagret. Versjon 3.');
  82  |   await button(page, 'Fortsett til godkjenning').click(); await expect(page.getByRole('region', { name: 'Gjennomgått versjon' })).toContainText('Lagret versjon 3');
  83  | });
  84  | test('failed direct save retains original operation and only explicit recovery advances', async ({ page, context }) => {
  85  |   await loginAndImport(page);
  86  |   await page.route('**:18326/drafts', route => route.request().method() === 'POST' ? route.abort() : route.continue());
  87  |   await button(page, 'Alt stemmer – lagre og fortsett').click();
  88  |   await expect(page.getByRole('status', { name: 'Lagringsstatus' })).toContainText('Lagring er uavklart');
  89  |   await expect(page.getByRole('heading', { name: 'Gjennomgå og bekreft', exact: true })).toBeHidden(); expect(await drafts(context)).toEqual([]);
  90  |   await page.unroute('**:18326/drafts'); await button(page, 'Prøv samme lagringsforsøk igjen').click();
  91  |   await expect(page.getByRole('region', { name: 'Gjennomgått versjon' })).toBeVisible(); expect(await drafts(context)).toHaveLength(1);
  92  | });
  93  | test('new edit invalidates saved review and unfinished time cannot bypass explicit save', async ({ page, context }) => {
  94  |   await loginAndImport(page); await button(page, 'Alt stemmer – lagre og fortsett').click();
  95  |   await expect(page.getByRole('region', { name: 'Gjennomgått versjon' })).toBeVisible(); await editor(page);
  96  |   await page.getByLabel('Startdato', { exact: true }).first().fill('');
  97  |   await expect(button(page, 'Lagre utkast')).toBeDisabled(); await expect(button(page, 'Til godkjenning')).toBeDisabled();
  98  |   await expect(page.getByRole('region', { name: 'Gjennomgått versjon' })).toHaveCount(0); expect((await fullDraft(context, (await drafts(context))[0].id)).revision).toBe(1);
  99  | });
  100 | 
```