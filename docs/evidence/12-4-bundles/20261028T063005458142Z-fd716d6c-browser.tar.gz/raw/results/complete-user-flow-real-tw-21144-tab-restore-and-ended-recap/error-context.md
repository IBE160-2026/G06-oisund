# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: complete-user-flow.spec.ts >> real two-document journey A: explicit correction notice tab restore and ended recap
- Location: .story124-tests\complete-user-flow.spec.ts:70:3

# Error details

```
Error: Command failed: docker compose -p ibe160-story124-tests -f compose.story124.yaml restart --wait private-db private-api
unknown flag: --wait

```

# Test source

```ts
  113 |       (window as any).__story124Visibility = [];
  114 |       (window as any).__story124Focus = [];
  115 |       document.addEventListener('visibilitychange', () => (window as any).__story124Visibility.push(document.visibilityState));
  116 |       window.addEventListener('blur', () => (window as any).__story124Focus.push('blur'));
  117 |       window.addEventListener('focus', () => (window as any).__story124Focus.push('focus'));
  118 |     });
  119 |     const other = await context.newPage(); await other.goto('/demo.html');
  120 |     const otherFocusSession = await context.newCDPSession(other);
  121 |     await otherFocusSession.send('Emulation.setFocusEmulationEnabled', { enabled: false });
  122 |     await test.step('Switch actual browser tabs and observe native focus', async () => {
  123 |       await other.bringToFront();
  124 |       await expect.poll(() => page.evaluate(() => document.hasFocus())).toBe(false);
  125 |       await page.bringToFront();
  126 |       await expect.poll(() => page.evaluate(() => document.hasFocus())).toBe(true);
  127 |     });
  128 |     const visibility = await page.evaluate(() => (window as any).__story124Visibility);
  129 |     const focus = await page.evaluate(() => (window as any).__story124Focus);
  130 |     expect(focus).toContain('blur'); expect(focus).toContain('focus');
  131 |     await expect(page.getByLabel('Tittel', { exact: true })).toHaveValue(title);
  132 |     await expect(page.getByLabel('Detaljert forklaring', { exact: true })).toHaveValue(description);
  133 |     // Separate lifecycle fault injection: tab switching above does not emit
  134 |     // hidden/visible in this runtime. Session restoration still uses the real API.
  135 |     if (name === 'C') {
  136 |       const originalSession = await json(context, '/auth/session');
  137 |       await test.step('Inject hidden lifecycle while preserving the dirty editor', async () => {
  138 |         await page.evaluate(() => {
  139 |           const descriptor = Object.getOwnPropertyDescriptor(document, 'visibilityState');
  140 |           (window as any).__story124RestoreVisibility = () => {
  141 |             if (descriptor) Object.defineProperty(document, 'visibilityState', descriptor);
  142 |             else delete (document as any).visibilityState;
  143 |             document.dispatchEvent(new Event('visibilitychange'));
  144 |           };
  145 |           Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'hidden' });
  146 |           document.dispatchEvent(new Event('visibilitychange'));
  147 |         });
  148 |         await expect(page.getByLabel('Tittel', { exact: true })).toBeHidden();
  149 |       });
  150 |       await test.step('Restore original authorization without saving the proposal', async () => {
  151 |         const restored = page.waitForResponse(r => r.url() === API + '/auth/session');
  152 |         await page.evaluate(() => (window as any).__story124RestoreVisibility());
  153 |         const restoredResponse = await restored; expect(restoredResponse.status()).toBe(200);
  154 |         expect(await restoredResponse.json()).toEqual(originalSession);
  155 |         await expect(page.getByRole('status', { name: 'Tilgangsstatus', exact: true })).toHaveText('Du er logget inn.');
  156 |         await expect(page.getByLabel('Tittel', { exact: true })).toHaveValue(title);
  157 |         await expect(page.getByLabel('Detaljert forklaring', { exact: true })).toHaveValue(description);
  158 |         expect((await json(context, '/notices')).notices).toHaveLength(0);
  159 |       });
  160 |     }
  161 |     expect((await json(context, '/notices')).notices).toHaveLength(0);
  162 |     await other.close();
  163 |     await button(page, 'Tilbake til avvik').click(); await button(page, 'Tilbake til ulagret avvik').click();
  164 |     await expect(page.getByLabel('Tittel', { exact: true })).toHaveValue(title);
  165 |     await button(page, 'Lagre avvik').click();
  166 |     await expect(page.getByRole('status', { name: 'Avviksstatus', exact: true })).toHaveText('Avviket er lagret.');
  167 |     const notices = (await json(context, '/notices')).notices;
  168 |     expect(notices).toHaveLength(1);
  169 |     expect(notices[0]).toMatchObject({ title, description, line_tags: ['731', '81'], valid_from: null, source_updated_at: null, checked_at: null, valid_until: '2030-02-10T23:59:59+01:00' });
  170 |     await button(page, 'Tilbake til dagen').click();
  171 |     // The injected hide can interrupt the focus-triggered current read. Recover
  172 |     // authority through the offered explicit read before opening dependent views.
  173 |     if (name === 'C') await test.step('Recover current day authority after lifecycle interruption', async () => {
  174 |       await button(page, 'Hent skift og aktivitetsstatus igjen').click();
  175 |       await expect(page.getByRole('status', { name: 'Aktivitetsstatus og avslutningsstatus' })).toHaveText('Lagret skift og aktivitetsstatus er hentet.');
  176 |     });
  177 |     await button(page, 'Les avvik for linjer og datoer').click();
  178 |     const reader = page.getByRole('region', { name: 'Avvik for linjer og datoer', exact: true });
  179 |     await reader.getByLabel('Bekreftet linje', { exact: true }).selectOption(name === 'A' ? '731' : '81');
  180 |     await reader.getByLabel('Planlagt kalenderdato (Oslo)', { exact: true }).selectOption(chosen.saved.draft.service_date);
  181 |     await expect(reader.locator('.notice-list summary')).toContainText(title);
  182 |     await reader.locator('.notice-list summary').click();
  183 |     await expect(reader).toContainText('Delvis kjent gyldighet');
  184 |     await expect(reader).toContainText('Kildens oppdateringstid er ukjent');
  185 |     await expect(reader).toContainText('Ikke kontrollert');
  186 |     await reader.getByRole('button', { name: 'Tilbake til dagen', exact: true }).click();
  187 |     await button(page, 'Velg aktivitet ' + (chosen.tripIndex + 1)).click(); await activityScreen(page);
  188 |     await expect(selected(page)).toContainText('Syntetisk manuelt korrigert endeholdeplass');
  189 |     const selection = await json(context, '/workdays/' + plan.id + '/selection');
  190 |     expect(selection.activity_id).toBe(chosen.saved.draft.activities[chosen.tripIndex].id);
  191 |     expect(selection.revision).toBe(1);
  192 |     await dayScreen(page); await button(page, 'Start skift').click(); await button(page, 'Bekreft skiftstart').click();
  193 |     await expect(shiftStatus(page)).toHaveText('Skiftstart er lagret.');
  194 |     await activityScreen(page);
  195 |     await page.getByLabel('Manuell aktivitetsstatus', { exact: true }).selectOption(action === 'ended' ? 'completed' : 'interrupted');
  196 |     await button(page, 'Lagre aktivitetsstatus').click();
  197 |     await expect(page.getByRole('status', { name: 'Aktivitetsstatus og avslutningsstatus' })).toHaveText('Aktivitetsstatusen er lagret.');
  198 |     await dayScreen(page); await button(page, action === 'ended' ? 'Avslutt skift' : 'Avbryt skift').click();
  199 |     await button(page, action === 'ended' ? 'Bekreft avslutning' : 'Bekreft avbrudd').click();
  200 |     await expect(page.getByRole('heading', { name: action === 'ended' ? 'Skift avsluttet' : 'Skift avbrutt', exact: true })).toBeVisible();
  201 |     const recapUI = page.getByRole('region', { name: 'Oppsummering av skift', exact: true });
  202 |     await expect(recapUI.locator('dt:text-is("Ikke registrert") + dd')).toHaveText(String(chosen.saved.draft.activities.length - 1));
  203 |     await expect(recapUI.locator(`dt:text-is("${action === 'ended' ? 'Fullført manuelt' : 'Avbrutt'}") + dd`)).toHaveText('1');
  204 |     const recap = await json(context, '/workdays/' + plan.id + '/recap');
  205 |     expect(recap.lifecycle.state).toBe(action);
  206 |     expect(recap.plan.source_draft_id).toBe(chosen.saved.id);
  207 |     expect(recap.plan.draft).toEqual(chosen.saved.draft);
  208 |     expect(recap.outcomes.outcomes.map((row: any) => row.outcome)).toEqual(chosen.saved.draft.activities.map((_: any, i: number) => i === chosen.tripIndex ? action === 'ended' ? 'completed' : 'interrupted' : 'unregistered'));
  209 |     expect(recap.bus.physical_bus).toBe('SYN-124');
  210 |     if (name === 'A') {
  211 |       if (process.env.COMPOSE_PROJECT_NAME !== 'ibe160-story124-tests') throw Error('Disposable project selection required');
  212 |       await test.step('Restart actual database and API and verify fixed records', async () => {
> 213 |         execFileSync('docker', ['compose', '-p', 'ibe160-story124-tests', '-f', 'compose.story124.yaml', 'restart', '--wait', 'private-db', 'private-api'], { cwd: '..', timeout: 90000 });
      |         ^ Error: Command failed: docker compose -p ibe160-story124-tests -f compose.story124.yaml restart --wait private-db private-api
  214 |         expect(await json(context, '/workdays/' + plan.id + '/recap')).toEqual(recap);
  215 |         expect(await json(context, '/workdays/' + plan.id + '/selection')).toEqual(selection);
  216 |       });
  217 |     }
  218 |     await page.reload(); await button(page, `Åpne plan ${chosen.saved.draft.service_date} · versjon 1`).click();
  219 |     await expect(page.getByRole('heading', { name: action === 'ended' ? 'Skift avsluttet' : 'Skift avbrutt', exact: true })).toBeVisible();
  220 |     await expect(button(page, 'Start skift')).toBeHidden();
  221 |     await expect(button(page, 'Bekreft skiftstart')).toBeHidden();
  222 |     expect(await json(context, '/workdays/' + plan.id + '/recap')).toEqual(recap);
  223 |     expect(await json(context, '/workdays/' + plan.id + '/selection')).toEqual(selection);
  224 |     expect((await json(context, '/notices')).notices).toEqual(notices);
  225 |     const storage = await page.evaluate(async () => ({ local: Object.keys(localStorage), session: Object.keys(sessionStorage), databases: (await indexedDB.databases()).length, caches: (await caches.keys()).length, workers: (await navigator.serviceWorker.getRegistrations()).length }));
  226 |     expect(storage.local.filter(key => key !== 'ibe160-theme')).toEqual([]);
  227 |     expect(storage).toMatchObject({ session: [], databases: 0, caches: 0, workers: 0 });
  228 |     await page.screenshot({ path: `../tmp/story124/20261028T063005458142Z-fd716d6c/captures/12-4-journey-${name}.png`, fullPage: true });
  229 |     writeFileSync(`../tmp/story124/20261028T063005458142Z-fd716d6c/captures/12-4-journey-${name}.json`, JSON.stringify({ synthetic: true, mockedApi: false, case: name, action, databaseAndApiRestart: name === 'A', nativeVisibilityEvents: visibility, nativeFocusEvents: focus, lifecycleEmulation: name === 'C', exactUploadedBytes: [a.uploadedBytes, c.uploadedBytes], draftIds: [a.saved.id, c.saved.id], planId: plan.id, selection, recap, notices }, null, 2));
  230 |   });
  231 | }
  232 | 
```