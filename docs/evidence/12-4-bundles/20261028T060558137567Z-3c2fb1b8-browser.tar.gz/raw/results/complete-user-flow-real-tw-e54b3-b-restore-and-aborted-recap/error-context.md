# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: complete-user-flow.spec.ts >> real two-document journey C: explicit correction notice tab restore and aborted recap
- Location: .story124-tests\complete-user-flow.spec.ts:60:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "hidden"
Received: "visible"

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Test source

```ts
  2   | import { readFileSync, writeFileSync } from 'node:fs';
  3   | import { execFileSync } from 'node:child_process';
  4   | import type { Page, BrowserContext } from '@playwright/test';
  5   | 
  6   | setup();
  7   | // Authored independently of the parser. Never regenerate these facts from an import.
  8   | const oracle = JSON.parse(readFileSync('../Eksempelfiler/Fasit-testskift.json', 'utf8').replace(/^\uFEFF/, '')).shifts;
  9   | const button = (page: Page, name: string) => page.getByRole('button', { name, exact: true });
  10  | async function json(context: BrowserContext, path: string) {
  11  |   const response = await context.request.get(API + path); expect(response.status()).toBe(200); return response.json();
  12  | }
  13  | async function login(page: Page) {
  14  |   await page.goto('/private');
  15  |   await page.getByLabel('Brukernavn', { exact: true }).fill(account.username);
  16  |   await page.getByLabel('Passord', { exact: true }).fill(account.password);
  17  |   await button(page, 'Logg inn').click();
  18  |   await expect(page.getByRole('heading', { name: 'Mine utkast', exact: true })).toBeVisible();
  19  | }
  20  | async function importAndSave(page: Page, context: BrowserContext, name: string) {
  21  |   const expected = oracle.find((value: any) => value.case === name);
  22  |   const events = expected.events.filter((value: any) => value.kind !== 'vehicle');
  23  |   const response = page.waitForResponse(r => r.url() === API + '/imports/pdf' && r.request().method() === 'POST');
  24  |   await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles('../Eksempelfiler/Testskift-' + name + '.pdf');
  25  |   const result = await response; expect(result.status()).toBe(200); const imported = await result.json();
  26  |   await expect(button(page, 'Bruk som separat nytt utkast')).toBeVisible();
  27  |   expect((await json(context, '/drafts')).drafts).toHaveLength(name === 'A' ? 0 : 1);
  28  |   expect(imported.activities).toHaveLength(events.length);
  29  |   for (let i = 0; i < events.length; i++) {
  30  |     const row = imported.activities[i], event = events[i];
  31  |     if (event.kind === 'movement') {
  32  |       expect([row.trip, row.line, row.from_place, row.to_place]).toEqual([event.trip_id, ['tom', 'CAR'].includes(event.line) ? null : event.line, event.stops[0].name, event.stops.at(-1).name]);
  33  |       expect(row.start.slice(0, 16)).toBe(event.stops[0].local_datetime);
  34  |       expect(row.end.slice(0, 16)).toBe(event.stops.at(-1).local_datetime);
  35  |     } else {
  36  |       expect(row.raw_code).toBe(event.label);
  37  |       expect(row.start?.slice(0, 16) ?? null).toBe(event.start_local);
  38  |       expect(row.end?.slice(0, 16) ?? null).toBe(event.end_local);
  39  |     }
  40  |   }
  41  |   expect(imported.vehicle_duty).toBe(expected.events.find((event: any) => event.kind === 'vehicle').vehicle);
  42  |   expect(imported.physical_bus).toBeNull();
  43  |   await button(page, 'Bruk som separat nytt utkast').click();
  44  |   const tripIndex = events.findIndex((event: any) => event.passenger_service);
  45  |   const trip = page.locator('#activity-' + imported.activities[tripIndex].id);
  46  |   await trip.getByLabel('Til sted', { exact: true }).fill('Syntetisk manuelt korrigert endeholdeplass');
  47  |   await trip.getByLabel('Kilde / manuell rettelse', { exact: true }).fill('Manuelt kontrollert mot syntetisk oppgave');
  48  |   await page.getByLabel('Buss/vogn', { exact: true }).fill('SYN-124');
  49  |   const savedReply = page.waitForResponse(r => r.url() === API + '/drafts' && r.request().method() === 'POST');
  50  |   await button(page, 'Lagre utkast').click();
  51  |   const savedResponse = await savedReply; expect(savedResponse.status()).toBe(200); const saved = await savedResponse.json();
  52  |   expect(saved.draft.activities[tripIndex].to_place).toBe('Syntetisk manuelt korrigert endeholdeplass');
  53  |   expect(saved.draft.activities[tripIndex].direction).toBeNull();
  54  |   expect(saved.draft.import_metadata).toEqual(imported.import_metadata);
  55  |   expect(saved.draft.physical_bus).toBe('SYN-124');
  56  |   return { saved, imported, expected, tripIndex };
  57  | }
  58  | 
  59  | for (const [name, action] of [['A', 'ended'], ['C', 'aborted']] as const) {
  60  |   test(`real two-document journey ${name}: explicit correction notice tab restore and ${action} recap`, async ({ page, context }) => {
  61  |     test.setTimeout(240000);
  62  |     await login(page);
  63  |     const a = await importAndSave(page, context, 'A');
  64  |     await button(page, 'Forberedelse og planlister').click();
  65  |     const c = await importAndSave(page, context, 'C');
  66  |     expect(c.saved.id).not.toBe(a.saved.id);
  67  |     expect(c.imported.activities.some((row: any) => row.end?.startsWith('2030-02-09'))).toBe(true);
  68  |     expect((await json(context, '/drafts')).drafts).toHaveLength(2);
  69  |     const chosen = name === 'A' ? a : c;
  70  |     await page.reload();
  71  |     await button(page, `Åpne ${chosen.saved.draft.service_date} · versjon 1`).click();
  72  |     const reopened = await json(context, '/drafts/' + chosen.saved.id); expect(reopened).toEqual(chosen.saved);
  73  |     await page.getByText('Vis kildefakta fra PDF', { exact: true }).click();
  74  |     await expect(page.getByRole('region', { name: 'Kildefakta fra PDF', exact: true })).toContainText(chosen.expected.shift_id);
  75  |     await button(page, 'Gjennomgå lagret utkast').click();
  76  |     const review = page.getByRole('region', { name: 'Gjennomgått versjon', exact: true });
  77  |     await expect(review).toBeVisible();
  78  |     await expect(button(page, 'Bekreft gjennomgått plan')).toBeDisabled();
  79  |     for (const checkbox of await review.getByRole('checkbox').all()) await checkbox.check();
  80  |     const confirmation = page.waitForResponse(r => r.url().endsWith('/confirm') && r.request().method() === 'POST');
  81  |     await button(page, 'Bekreft gjennomgått plan').click();
  82  |     const confirmedResponse = await confirmation; expect(confirmedResponse.status()).toBe(200); const plan = await confirmedResponse.json();
  83  |     expect(plan.source_draft_id).toBe(chosen.saved.id);
  84  |     expect(plan.draft.import_metadata).toEqual(chosen.imported.import_metadata);
  85  |     expect(plan.unknowns.some((unknown: any) => unknown.id.endsWith(':direction'))).toBe(true);
  86  |     await expect(page.getByText('Ingen aktivitet valgt', { exact: true })).toBeVisible();
  87  |     await expect(page.getByText('Ikke startet', { exact: true })).toBeVisible();
  88  | 
  89  |     await button(page, 'Manuelt vedlikeholdte avvik').click();
  90  |     await expect(button(page, 'Registrer avvik')).toBeEnabled(); await button(page, 'Registrer avvik').click();
  91  |     const title = 'Syntetisk flerlinjeavvik 12.4 ' + name;
  92  |     const description = 'Første tidsvindu: omkjøring ved Måneglimt.\nAndre tidsvindu: bruk midlertidig holdeplass.';
  93  |     await page.getByLabel('Tittel', { exact: true }).fill(title);
  94  |     await page.getByLabel('Detaljert forklaring', { exact: true }).fill(description);
  95  |     await page.getByLabel('Linjer fra kilden (kommaseparert)', { exact: true }).fill('731, 81');
  96  |     await page.getByLabel('Gyldig tildato', { exact: true }).fill('2030-02-10');
  97  |     await expect(page.getByRole('region', { name: 'Lagringskrav' })).not.toContainText('ufullstendig');
  98  |     // A real second tab receives browser focus. Capture native visibility events,
  99  |     // rather than dispatching a fabricated visibilitychange or mocking auth.
  100 |     await page.evaluate(() => { (window as any).__story124Visibility = []; document.addEventListener('visibilitychange', () => (window as any).__story124Visibility.push(document.visibilityState)); });
  101 |     const other = await context.newPage(); await other.goto('/demo.html'); await other.bringToFront();
> 102 |     await expect.poll(() => page.evaluate(() => document.visibilityState)).toBe('hidden');
      |                                                                            ^ Error: expect(received).toBe(expected) // Object.is equality
  103 |     await page.bringToFront();
  104 |     await expect.poll(() => page.evaluate(() => document.visibilityState)).toBe('visible');
  105 |     await expect(page.getByRole('status', { name: 'Tilgangsstatus', exact: true })).toHaveText('Du er logget inn.');
  106 |     await expect(page.getByLabel('Tittel', { exact: true })).toHaveValue(title);
  107 |     await expect(page.getByLabel('Detaljert forklaring', { exact: true })).toHaveValue(description);
  108 |     const visibility = await page.evaluate(() => (window as any).__story124Visibility);
  109 |     expect(visibility).toContain('hidden'); expect(visibility).toContain('visible');
  110 |     expect((await json(context, '/notices')).notices).toHaveLength(0);
  111 |     await other.close();
  112 |     await button(page, 'Tilbake til avvik').click(); await button(page, 'Tilbake til ulagret avvik').click();
  113 |     await expect(page.getByLabel('Tittel', { exact: true })).toHaveValue(title);
  114 |     await button(page, 'Lagre avvik').click();
  115 |     await expect(page.getByRole('status', { name: 'Avviksstatus', exact: true })).toHaveText('Avviket er lagret.');
  116 |     const notices = (await json(context, '/notices')).notices;
  117 |     expect(notices).toHaveLength(1);
  118 |     expect(notices[0]).toMatchObject({ title, description, line_tags: ['731', '81'], valid_from: null, source_updated_at: null, checked_at: null, valid_until: '2030-02-10T23:59:59+01:00' });
  119 |     await button(page, 'Tilbake til dagen').click();
  120 |     await button(page, 'Les avvik for linjer og datoer').click();
  121 |     const reader = page.getByRole('region', { name: 'Avvik for linjer og datoer', exact: true });
  122 |     await reader.getByLabel('Bekreftet linje', { exact: true }).selectOption(name === 'A' ? '731' : '81');
  123 |     await reader.getByLabel('Planlagt kalenderdato (Oslo)', { exact: true }).selectOption(chosen.saved.draft.service_date);
  124 |     await expect(reader.locator('.notice-list summary')).toContainText(title);
  125 |     await reader.locator('.notice-list summary').click();
  126 |     await expect(reader).toContainText('Delvis kjent gyldighet');
  127 |     await expect(reader).toContainText('Kildens oppdateringstid er ukjent');
  128 |     await expect(reader).toContainText('Ikke kontrollert');
  129 |     await reader.getByRole('button', { name: 'Tilbake til dagen', exact: true }).click();
  130 |     await button(page, 'Velg aktivitet ' + (chosen.tripIndex + 1)).click(); await activityScreen(page);
  131 |     await expect(selected(page)).toContainText('Syntetisk manuelt korrigert endeholdeplass');
  132 |     await dayScreen(page); await button(page, 'Start skift').click(); await button(page, 'Bekreft skiftstart').click();
  133 |     await expect(shiftStatus(page)).toHaveText('Skiftstart er lagret.');
  134 |     await activityScreen(page);
  135 |     await page.getByLabel('Manuell aktivitetsstatus', { exact: true }).selectOption(action === 'ended' ? 'completed' : 'interrupted');
  136 |     await button(page, 'Lagre aktivitetsstatus').click();
  137 |     await expect(page.getByRole('status', { name: 'Aktivitetsstatus og avslutningsstatus' })).toHaveText('Aktivitetsstatusen er lagret.');
  138 |     await dayScreen(page); await button(page, action === 'ended' ? 'Avslutt skift' : 'Avbryt skift').click();
  139 |     await button(page, action === 'ended' ? 'Bekreft avslutning' : 'Bekreft avbrudd').click();
  140 |     await expect(page.getByRole('heading', { name: action === 'ended' ? 'Skift avsluttet' : 'Skift avbrutt', exact: true })).toBeVisible();
  141 |     const recap = await json(context, '/workdays/' + plan.id + '/recap');
  142 |     expect(recap.lifecycle.state).toBe(action);
  143 |     expect(recap.outcomes.outcomes.map((row: any) => row.outcome)).toEqual(chosen.saved.draft.activities.map((_: any, i: number) => i === chosen.tripIndex ? action === 'ended' ? 'completed' : 'interrupted' : 'unregistered'));
  144 |     expect(recap.bus.physical_bus).toBe('SYN-124');
  145 |     if (name === 'A') {
  146 |       if (process.env.COMPOSE_PROJECT_NAME !== 'ibe160-story124-tests') throw Error('Disposable project selection required');
  147 |       execFileSync('docker', ['compose', '-p', 'ibe160-story124-tests', '-f', 'compose.story124.yaml', 'restart', '--wait', 'private-db', 'private-api'], { cwd: '..', timeout: 90000 });
  148 |       expect(await json(context, '/workdays/' + plan.id + '/recap')).toEqual(recap);
  149 |     }
  150 |     await page.reload(); await button(page, `Åpne plan ${chosen.saved.draft.service_date} · versjon 1`).click();
  151 |     await expect(page.getByRole('heading', { name: action === 'ended' ? 'Skift avsluttet' : 'Skift avbrutt', exact: true })).toBeVisible();
  152 |     expect(await json(context, '/workdays/' + plan.id + '/recap')).toEqual(recap);
  153 |     expect((await json(context, '/notices')).notices).toEqual(notices);
  154 |     const storage = await page.evaluate(async () => ({ local: Object.keys(localStorage), session: Object.keys(sessionStorage), databases: (await indexedDB.databases()).length, caches: (await caches.keys()).length, workers: (await navigator.serviceWorker.getRegistrations()).length }));
  155 |     expect(storage.local.filter(key => key !== 'theme')).toEqual([]);
  156 |     expect(storage).toMatchObject({ session: [], databases: 0, caches: 0, workers: 0 });
  157 |     await page.screenshot({ path: `../tmp/story124/20261028T060558137567Z-3c2fb1b8/captures/12-4-journey-${name}.png`, fullPage: true });
  158 |     writeFileSync(`../tmp/story124/20261028T060558137567Z-3c2fb1b8/captures/12-4-journey-${name}.json`, JSON.stringify({ synthetic: true, mockedApi: false, case: name, action, databaseAndApiRestart: name === 'A', nativeVisibilityEvents: visibility, draftIds: [a.saved.id, c.saved.id], planId: plan.id, recap, notices }, null, 2));
  159 |   });
  160 | }
  161 | 
```