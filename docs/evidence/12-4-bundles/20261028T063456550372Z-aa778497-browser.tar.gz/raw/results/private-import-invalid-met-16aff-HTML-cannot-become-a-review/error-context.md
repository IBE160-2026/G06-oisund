# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: private-import.spec.ts >> invalid metadata or HTML cannot become a review
- Location: .story124-tests\private-import.spec.ts:294:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('PDF-en kunne ikke tolkes.')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('PDF-en kunne ikke tolkes.') with timeout 5000ms
  - waiting for getByText('PDF-en kunne ikke tolkes.')

```

```yaml
- main:
  - button "Nattmodus"
  - text: "Visning: Dag"
  - paragraph: Privat tilgang
  - heading "Privat arbeidsrom" [level=1]
  - status "Tilgangsstatus": Du er logget inn.
  - region "Privat arbeidsrom":
    - region "Private utkast":
      - navigation "Plan og forberedelse":
        - button "Forberedelse og planlister"
        - button "Kontroller og rediger utkast"
      - heading "Mine utkast" [level=2]
      - status: Nytt utkast. Ikke lagret.
      - group:
        - region "Importer tekst-PDF":
          - heading "Gjennomgå en tekst-PDF" [level=3]
          - paragraph: Serveren returnerte et svar som ikke kunne brukes. Prøv igjen. PDF-en er ikke lagret.
          - text: Velg tekst-PDF
          - button "Velg tekst-PDF"
        - paragraph: Utkast slettes sju dager etter opprettelse. Ulagrede endringer finnes bare mens denne siden er åpen.
        - button "Nytt utkast"
        - button "Oppdater listen"
        - paragraph: Ingen lagrede utkast.
        - paragraph: Lastet 0 utkast.
    - region "Bekreft plan":
      - status "Bekreftelsesstatus": Planlisten er oppdatert.
      - button "Manuelt vedlikeholdte avvik"
      - heading "Mine bekreftede planer" [level=3]
      - button "Oppdater planlisten"
      - paragraph: Ingen planer er lastet.
      - list
    - paragraph: Økten utløper 11.11.2026, 07:38.
    - button "Logg ut"
  - paragraph: Tilgang opprettes av den som drifter løsningen. Bruk arbeidsrommet mens du står stille.
  - link "Åpne fiktiv demo":
    - /url: /
```

# Test source

```ts
  198 |     await expect(page.getByLabel('Buss/vogn', { exact: true })).toHaveValue('');
  199 |     if (number === 8) {
  200 |       await expect(page.getByLabel('Vognløp fra aktivitet 14', { exact: true })).toHaveValue('960176');
  201 |       await expect(page.getByLabel('Vognløp fra aktivitet 21', { exact: true })).toHaveValue('CAR - 1');
  202 |       await expect(page.getByLabel('Aktivitetstype', { exact: true }).nth(20)).toHaveValue('CAR');
  203 |       await expect(page.getByLabel('Aktivitetstype', { exact: true }).nth(21)).toHaveValue('Tomkjøring med CAR');
  204 |     } else {
  205 |       await expect(page.getByLabel('Aktivitetstype', { exact: true }).nth(1)).toHaveValue('Fadder');
  206 |       await expect(page.getByLabel('Aktivitetstype', { exact: true }).nth(7)).toHaveValue('Instruktør');
  207 |     }
  208 |   };
  209 |   await checkEditor();
  210 |   let saved: any;
  211 |   await page.route('**:18326/drafts', async route => {
  212 |     if (route.request().method() !== 'POST') return route.continue();
  213 |     const response = await route.fetch(); saved = await response.json(); await route.fulfill({ response });
  214 |   });
  215 |   await editor(page); await page.getByRole('button', { name: 'Lagre utkast', exact: true }).click();
  216 |   await expect(page.getByText('Lagret. Versjon 1.', { exact: true })).toBeVisible();
  217 |   expect(saved.draft).toEqual(facts);
  218 |   await page.reload();
  219 |   await page.getByRole('button', { name: new RegExp(`Åpne 2030-01-${number === 8 ? '10' : '14'}`) }).first().click();
  220 |   await checkEditor();
  221 |   expect(await (await page.request.get('http://127.0.0.1:18326/drafts/' + saved.id)).json()).toEqual(saved);
  222 |   await page.getByRole('group', { name: `Aktivitet ${number === 8 ? 22 : 2}`, exact: true }).screenshot({ path: `../tmp/story124/20261028T063456550372Z-aa778497/captures/11-2-regression-10-1-example-${number}-activity.png` });
  223 | });
  224 | for (const width of [768, 1440]) test(`keyboard review separate adoption save recovery reopen at ${width}px`, async ({ page }) => {
  225 |   await page.setViewportSize({ width, height: 1100 });
  226 |   await login(page); await upload(page);
  227 |   const facts = page.getByRole('region', { name: 'Kildefakta fra PDF' });
  228 |   await expect(facts).toContainText('Kildestart');
  229 |   await expect(facts).toContainText('N (side 1, kolonne 1, linje 3)');
  230 |   await expect(facts).toContainText('side 1, overskrift, felt Tjenestedato');
  231 |   await expect(facts).toContainText('Avledningsgrunnlag per kalenderfelt');
  232 |   await expect(facts).toContainText('aktivitet 1: Startklokke, overskrift: Tjenestedato');
  233 |   await expect(facts).toContainText('entydig tidspunkt innenfor oppgitt skiftintervall');
  234 |   await expect(facts).not.toContainText('Synthetic Driver');
  235 |   expect(await page.getByLabel('Velg tekst-PDF', { exact: true }).inputValue()).toBe('');
  236 |   expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  237 |   await page.screenshot({ path: `../tmp/story124/20261028T063456550372Z-aa778497/captures/11-2-regression-10-1-${width}.png`, fullPage: true });
  238 |   await page.getByRole('button', { name: 'Bruk som separat nytt utkast' }).focus(); await page.keyboard.press('Enter');
  239 |   await expect(page.getByRole('heading', { name: 'Nytt manuelt utkast' })).toBeFocused();
  240 |   await expect(page.getByLabel('Buss/vogn', { exact: true })).toHaveValue('');
  241 |   let accepted: any;
  242 |   await page.route('**:18326/drafts', async route => {
  243 |     if (route.request().method() !== 'POST') return route.continue();
  244 |     accepted = await (await route.fetch()).json(); await route.abort();
  245 |   });
  246 |   await editor(page); await page.getByRole('button', { name: 'Lagre utkast', exact: true }).click();
  247 |   await expect(page.getByText('Lagring er uavklart.', { exact: false })).toBeVisible();
  248 |   await page.unroute('**:18326/drafts');
  249 |   await page.getByRole('button', { name: 'Kontroller lagringsforsøket' }).click();
  250 |   await expect(page.getByText('Lagret. Versjon 1.', { exact: true })).toBeVisible();
  251 |   await page.getByLabel('Vognløp', { exact: true }).fill('0007');
  252 |   page.once('dialog', d => d.accept()); await editor(page); await page.getByRole('button', { name: 'Forkast endringer' }).click();
  253 |   await expect(page.getByLabel('Vognløp', { exact: true })).toHaveValue('');
  254 |   await page.reload();
  255 |   await preparation(page); await page.getByRole('button', { name: /Åpne 2030-01-01/ }).first().click();
  256 |   expect(await (await page.request.get('http://127.0.0.1:18326/drafts/' + accepted.id)).json()).toEqual(accepted);
  257 |   await expect(page.locator('details.source-disclosure')).not.toHaveAttribute('open');
  258 |   await page.getByText('Vis kildefakta fra PDF', { exact: true }).click();
  259 |   await expect(page.getByRole('region', { name: 'Kildefakta fra PDF' })).toContainText('Kildestart');
  260 |   expect(await page.evaluate(async () => [localStorage.length, sessionStorage.length, (await indexedDB.databases()).length])).toEqual([0, 0, 0]);
  261 | });
  262 | 
  263 | test('failed review keeps editor and edit protection guards separate adoption', async ({ page }) => {
  264 |   await login(page);
  265 |   await editor(page); await page.getByLabel('Buss/vogn', { exact: true }).fill('Earlier-001');
  266 |   await preparation(page); await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles({ name: 'broken.pdf', mimeType: 'application/pdf', buffer: Buffer.from('%PDF-corrupt') });
  267 |   await expect(page.getByText('PDF-en kunne ikke tolkes.', { exact: false })).toBeVisible();
  268 |   await expect(page.getByLabel('Buss/vogn', { exact: true })).toHaveValue('Earlier-001');
  269 |   await page.screenshot({ path: '../tmp/story124/20261028T063456550372Z-aa778497/captures/11-2-regression-10-1-error.png', fullPage: true });
  270 |   await upload(page);
  271 |   page.once('dialog', d => d.dismiss()); await page.getByRole('button', { name: 'Bruk som separat nytt utkast' }).click();
  272 |   await expect(page.getByLabel('Buss/vogn', { exact: true })).toHaveValue('Earlier-001');
  273 |   await expect(page.getByRole('button', { name: 'Bruk som separat nytt utkast' })).toBeVisible();
  274 |   page.once('dialog', d => d.accept()); await page.getByRole('button', { name: 'Bruk som separat nytt utkast' }).click();
  275 |   await expect(page.getByLabel('Buss/vogn', { exact: true })).toHaveValue('');
  276 | });
  277 | 
  278 | test('cancel and logout discard late replies and raw selection', async ({ page }) => {
  279 |   await login(page);
  280 |   await editor(page); await page.getByLabel('Buss/vogn', { exact: true }).fill('Earlier');
  281 |   let release!: () => void;
  282 |   const gate = new Promise<void>(resolve => { release = resolve; });
  283 |   await page.route('**:18326/imports/pdf', async route => { const response = await route.fetch(); await gate; await route.fulfill({ response }).catch(() => {}); });
  284 |   await preparation(page); await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles({ name: 'synthetic.pdf', mimeType: 'application/pdf', buffer: pdf });
  285 |   await page.getByRole('button', { name: 'Avbryt import' }).click(); release();
  286 |   await expect(page.getByRole('button', { name: 'Bruk som separat nytt utkast' })).toHaveCount(0);
  287 |   await expect(page.getByLabel('Buss/vogn', { exact: true })).toHaveValue('Earlier');
  288 |   await page.unroute('**:18326/imports/pdf'); await upload(page);
  289 |   page.once('dialog', d => d.accept()); await page.getByRole('button', { name: 'Logg ut', exact: true }).click();
  290 |   await expect(page.getByRole('region', { name: 'Kildefakta fra PDF' })).toHaveCount(0);
  291 |   await expect(page.getByLabel('Velg tekst-PDF', { exact: true })).toHaveCount(0);
  292 | });
  293 | 
  294 | test('invalid metadata or HTML cannot become a review', async ({ page }) => {
  295 |   await login(page);
  296 |   await page.route('**:18326/imports/pdf', route => route.fulfill({ contentType: 'text/html', body: '<html>login</html>' }));
  297 |   await preparation(page); await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles({ name: 'synthetic.pdf', mimeType: 'application/pdf', buffer: pdf });
> 298 |   await expect(page.getByText('PDF-en kunne ikke tolkes.', { exact: false })).toBeVisible();
      |                                                                               ^ Error: expect(locator).toBeVisible() failed
  299 |   await page.unroute('**:18326/imports/pdf');
  300 |   await page.route('**:18326/imports/pdf', async route => { const value = await (await route.fetch()).json(); value.import_metadata.header.driver = 'forbidden'; await route.fulfill({ json: value }); });
  301 |   await preparation(page); await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles({ name: 'synthetic.pdf', mimeType: 'application/pdf', buffer: pdf });
  302 |   await expect(page.getByText('PDF-en kunne ikke tolkes.', { exact: false })).toBeVisible();
  303 |   await expect(page.getByRole('button', { name: 'Bruk som separat nytt utkast' })).toHaveCount(0);
  304 | });
  305 | 
  306 | test('unknown uncertainty references keep code field column and line', async ({ page }) => {
  307 |   await login(page);
  308 |   await page.route('**:18326/imports/pdf', async route => {
  309 |     const value = await (await route.fetch()).json();
  310 |     value.import_metadata.unresolved.push({ code: 'future_source_issue', field: 'unknown_field', activity: 2, provenance: { page: 1, column: 2, line: 9, region: null, field: null } });
  311 |     await route.fulfill({ json: value });
  312 |   });
  313 |   await upload(page);
  314 |   await expect(page.getByRole('region', { name: 'Kildefakta fra PDF' })).toContainText('Aktivitet 2: Ukjent kildeusikkerhet (future_source_issue) (unknown_field) · side 1, kolonne 2, linje 9');
  315 | });
  316 | 
  317 | for (const state of ['hidden', 'expired']) test(`delayed import is discarded after ${state} access revalidation`, async ({ page }) => {
  318 |   await login(page);
  319 |   await editor(page); await page.getByLabel('Buss/vogn', { exact: true }).fill('Earlier-private');
  320 |   let release!: () => void, started!: () => void;
  321 |   const gate = new Promise<void>(resolve => { release = resolve; });
  322 |   const accepted = new Promise<void>(resolve => { started = resolve; });
  323 |   await page.route('**:18326/imports/pdf', async route => { const response = await route.fetch(); started(); await gate; await route.fulfill({ response }).catch(() => {}); });
  324 |   await preparation(page); await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles({ name: 'synthetic.pdf', mimeType: 'application/pdf', buffer: pdf });
  325 |   await accepted;
  326 |   if (state === 'expired') python(`with database() as conn:\n conn.execute("UPDATE sessions SET created_at=statement_timestamp()-interval '14 days',expires_at=statement_timestamp() WHERE owner IN (SELECT id FROM accounts WHERE username=%s)", (${JSON.stringify(username)},))\n`);
  327 |   else await page.route('**:18326/auth/session', route => route.abort());
  328 |   await page.evaluate(() => {
  329 |     Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'hidden' }); document.dispatchEvent(new Event('visibilitychange'));
  330 |     Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'visible' }); document.dispatchEvent(new Event('visibilitychange'));
  331 |   });
  332 |   if (state === 'expired') await expect(page.getByLabel('Brukernavn', { exact: true })).toBeVisible();
  333 |   else await expect(page.getByRole('button', { name: 'Kontroller tilgang igjen' })).toBeEnabled();
  334 |   release();
  335 |   await expect(page.getByRole('button', { name: 'Bruk som separat nytt utkast' })).toHaveCount(0);
  336 |   await expect(page.getByRole('region', { name: 'Kildefakta fra PDF' })).toHaveCount(0);
  337 |   if (state === 'expired') await expect(page.getByLabel('Buss/vogn', { exact: true })).toHaveCount(0);
  338 |   else {
  339 |     await expect(page.getByLabel('Buss/vogn', { exact: true })).toBeHidden();
  340 |     await page.unroute('**:18326/auth/session');
  341 |     await page.getByRole('button', { name: 'Kontroller tilgang igjen' }).click();
  342 |     await expect(page.getByLabel('Buss/vogn', { exact: true })).toHaveValue('Earlier-private');
  343 |     await expect(page.getByRole('button', { name: 'Bruk som separat nytt utkast' })).toHaveCount(0);
  344 |   }
  345 | });
  346 | 
  347 | test('partial fictional Travel to preserves known end and unresolved facts through save reopen', async ({ page }) => {
  348 |   await login(page);
  349 |   await preparation(page); await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles({ name: 'partial-fictional.pdf', mimeType: 'application/pdf', buffer: partialPdf });
  350 |   await expect(page.getByRole('button', { name: 'Bruk som separat nytt utkast' })).toBeVisible();
  351 |   async function assertPartial() {
  352 |     const facts = page.getByRole('region', { name: 'Kildefakta fra PDF' });
  353 |     await expect(facts).toContainText('Delvis tolkning');
  354 |     const row = facts.getByRole('listitem').filter({ has: page.getByRole('heading', { name: '2. Travel to · side 1', exact: true }) });
  355 |     await expect(row.locator('dt:text-is("Kildeslutt") + dd')).toContainText('16:00');
  356 |     await expect(row.locator('dt:text-is("Kildestart") + dd')).toContainText('Ukjent / uavklart');
  357 |     await expect(row.locator('dt:text-is("Fra") + dd')).toContainText('Ukjent / uavklart');
  358 |     await expect(row.locator('dt:text-is("Til") + dd')).toContainText('Ukjent / uavklart');
  359 |     await expect(row.locator('dt:text-is("Tolket type") + dd')).toContainText('Ukjent / uavklart');
  360 |     await expect(row).not.toContainText('deadhead');
  361 |   }
  362 |   await assertPartial();
  363 |   await page.getByRole('button', { name: 'Bruk som separat nytt utkast' }).click();
  364 |   await expect(page.getByLabel('Starttid', { exact: true }).nth(1)).toHaveValue('');
  365 |   await expect(page.getByLabel('Sluttid', { exact: true }).nth(1)).toHaveValue('16:00:00');
  366 |   await expect(page.getByLabel('Aktivitetstype', { exact: true }).nth(1)).toHaveValue('');
  367 |   await expect(page.getByLabel('Fra sted', { exact: true }).nth(1)).toHaveValue('');
  368 |   await expect(page.getByLabel('Til sted', { exact: true }).nth(1)).toHaveValue('');
  369 |   const savedResponse = page.waitForResponse(response => response.request().method() === 'POST' && new URL(response.url()).pathname === '/drafts');
  370 |   await editor(page); await page.getByRole('button', { name: 'Lagre utkast', exact: true }).click();
  371 |   const saved = await (await savedResponse).json();
  372 |   expect(saved.draft.activities[1]).toEqual(expect.objectContaining({ raw_code: 'Travel to', source_end: '16:00', start: null, type: null, from_place: null, to_place: null }));
  373 |   await page.reload();
  374 |   await preparation(page); await page.getByRole('button', { name: /Åpne 2030-01-01/ }).first().click();
  375 |   await expect(page.locator('details.source-disclosure')).not.toHaveAttribute('open');
  376 |   await page.getByText('Vis kildefakta fra PDF', { exact: true }).click();
  377 |   await assertPartial();
  378 |   expect(await (await page.request.get('http://127.0.0.1:18326/drafts/' + saved.id)).json()).toEqual(saved);
  379 | });
  380 | 
  381 | test('duty changes, readable uncertainty and collapsed facts survive editing and reopen', async ({ page }) => {
  382 |   await login(page);
  383 |   await preparation(page); await page.getByLabel('Velg tekst-PDF', { exact: true }).setInputFiles({ name: 'fictional-duty-changes.pdf', mimeType: 'application/pdf', buffer: dutyPdf });
  384 |   await expect(page.getByRole('button', { name: 'Bruk som separat nytt utkast' })).toBeVisible();
  385 |   await page.getByRole('button', { name: 'Bruk som separat nytt utkast' }).click();
  386 |   await expect(page.locator('details.source-disclosure')).not.toHaveAttribute('open');
  387 |   await expect(page.getByRole('region', { name: 'Kildefakta fra PDF', includeHidden: true })).toBeHidden();
  388 |   await expect(page.getByLabel('Vognløp', { exact: true })).toHaveValue('960181');
  389 |   await expect(page.getByLabel('Vognløp fra aktivitet 3', { exact: true })).toHaveValue('960176');
  390 |   const third = page.getByRole('group', { name: 'Aktivitet 3', exact: true });
  391 |   const fourth = page.getByRole('group', { name: 'Aktivitet 4', exact: true });
  392 |   await expect(third).toContainText('Gjeldende vognløp: 960176 · sanntidsverdi 176');
  393 |   await expect(fourth).toContainText('Gjeldende vognløp: 960176 · sanntidsverdi 176');
  394 |   await expect(page.getByRole('region', { name: 'Usikkerheter fra importen' })).toContainText('Kontroller start');
  395 |   await expect(page.getByLabel('Usikkerhet / ukjente fakta', { exact: true }).nth(2)).toHaveValue(/Kontroller start.*Travel to/);
  396 |   await page.getByRole('button', { name: 'Se aktivitet 3', exact: true }).first().click();
  397 |   await expect(third).toBeFocused();
  398 |   await editor(page); await page.getByLabel('Buss/vogn', { exact: true }).fill('Bus-42');
```